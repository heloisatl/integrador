<?php

use app\core\Router;

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../app/core/Autoload.php';
require_once __DIR__ . '/../app/config/config.php';

$router = new Router();

// A camada Controller não foi gerada: nenhuma rota foi registrada.
$router->run();
