# Projeto: aasdawsdawsd

Gerado originalmente pelo DevStudio (MVC Creator).
- **Banco de Dados:** oficina_login
- **Data de Criação:** 30/10/2026 17:17:24

## Estrutura do Sistema MVC
- `app/config/`: Configurações de banco e ambiente
- `app/controllers/`: Controladores da aplicação
- `app/core/`: Roteador, Front Controller e Autoload
- `app/database/`: Conexão PDO (ConnectionFactory)
- `app/models/`: Entidades de dados
- `app/repositories/`: Camada de acesso ao banco (DAO)
- `app/services/`: Camada de regras de negócio
- `app/views/`: Telas e formulários da aplicação
- `public/`: Ponto de entrada web (`index.php`)
