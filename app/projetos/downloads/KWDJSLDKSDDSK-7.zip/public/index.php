<?php

/**
 * Ponto de Entrada Único (Front Controller) - Arquitetura MVC
 *
 * No padrão Front Controller, TODAS as requisições HTTP da aplicação passam por este arquivo (index.php):
 * 
 * 1. INICIALIZAÇÃO E AMBIENTE:
 *    - Configura diretivas de tratamento e exibição de erros (error_reporting / display_errors);
 *    - Carrega as definições globais de ambiente e credenciais do banco (config.php).
 *
 * 2. AUTOLOADING (Compatível com PSR-4):
 *    - O Autoload.php registra o carregamento automático via spl_autoload_register,
 *      instanciando Controllers, Models e Repositories sob demanda sem requires manuais.
 *
 * 3. ROTEAMENTO (Router):
 *    - Mapeia URLs e verbos HTTP (GET / POST) para o Controller e Método correspondentes;
 *    - Ao final, $router->run() inspeciona a URL atual e despacha a execução da ação solicitada.
 */

use app\core\Router;

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../app/core/Autoload.php';
require_once __DIR__ . '/../app/config/config.php';

$router = new Router();

// Mapeamento das Rotas RESTful da Aplicação:
$router->get('/', 'TESTEEEEEEEEEEController@index');
$router->get('/testeeeeeeeeees', 'TESTEEEEEEEEEEController@index');
$router->get('/testeeeeeeeeees/cadastrar', 'TESTEEEEEEEEEEController@cadastrar');
$router->post('/testeeeeeeeeees/salvar', 'TESTEEEEEEEEEEController@salvar');
$router->get('/testeeeeeeeeees/editar', 'TESTEEEEEEEEEEController@editar');
$router->post('/testeeeeeeeeees/atualizar', 'TESTEEEEEEEEEEController@atualizar');
$router->get('/testeeeeeeeeees/excluir', 'TESTEEEEEEEEEEController@excluir');

// Despacha a requisição de acordo com o método HTTP e URI solicitada
$router->run();
