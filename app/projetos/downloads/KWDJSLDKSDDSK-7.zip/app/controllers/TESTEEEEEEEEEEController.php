<?php

namespace app\controllers;

use app\core\Controller;
use app\models\TESTEEEEEEEEEE;
use app\services\TESTEEEEEEEEEEService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (TESTEEEEEEEEEEService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class TESTEEEEEEEEEEController extends Controller {
    private TESTEEEEEEEEEEService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (TESTEEEEEEEEEEService).
     */
    public function __construct() {
        $this->repository = new TESTEEEEEEEEEEService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (testeeeeeeeeees/index).
     */
    public function index(): void {
        $data['testeeeeeeeeees'] = $this->repository->listarTodos();
        $this->view('testeeeeeeeeees/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('testeeeeeeeeees/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model TESTEEEEEEEEEE e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $testeeeeeeeeee = new TESTEEEEEEEEEE();
        $testeeeeeeeeee->setNOME($_POST['NOME'] ?? '');

        if ($this->repository->inserir($testeeeeeeeeee)) {
            $this->redirect(URL_BASE . '/testeeeeeeeeees');
        } else {
            $data['erro'] = 'Erro ao cadastrar TESTEEEEEEEEEE.';
            $this->view('testeeeeeeeeees/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['testeeeeeeeeee'] = $this->repository->buscarPorId($id);

        if (!$data['testeeeeeeeeee']) {
            $this->redirect(URL_BASE . '/testeeeeeeeeees');
        }

        $this->view('testeeeeeeeeees/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model TESTEEEEEEEEEE e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/testeeeeeeeeees');
        }

        $id = (int) $_POST['id'];
        $testeeeeeeeeee = new TESTEEEEEEEEEE();
        $testeeeeeeeeee->setNOME($_POST['NOME'] ?? '');

        if ($this->repository->alterar($testeeeeeeeeee, $id)) {
            $this->redirect(URL_BASE . '/testeeeeeeeeees');
        } else {
            $this->redirect(URL_BASE . '/testeeeeeeeeees/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/testeeeeeeeeees');
    }
}