<?php

/**
 * Configuração Geral e Conexão com o Banco de Dados
 *
 * Este arquivo centraliza as diretivas globais e os parâmetros de conexão do sistema:
 * 
 * 1. AMBIENTE DE DESENVOLVIMENTO (DEV_ENVIRONMENT):
 *    - Exibe erros, avisos e notificações diretamente no navegador para agilizar a depuração.
 *
 * 2. PORTABILIDADE DE ROTAS E ASSETS (BASE_PATH e URL_BASE):
 *    - Calcula a URL base dinamicamente, permitindo que o projeto execute em qualquer pasta,
 *      porta ou servidor web (Apache, Nginx, PHP Built-in Server) sem ajustes manuais.
 *
 * 3. PARÂMETROS DE CONEXÃO DO PDO (MySQL):
 *    - DB_HOST: Endereço do servidor MySQL (ex: 'localhost' ou '127.0.0.1');
 *    - DB_PORT: Porta de rede do serviço MySQL (padrão '3306');
 *    - DB_NAME: Nome do banco de dados relacional selecionado;
 *    - DB_USER: Usuário de autenticação do MySQL (ex: 'root');
 *    - DB_PASS: Senha de acesso ao banco (defina conforme as credenciais do seu ambiente).
 */

define('DEV_ENVIRONMENT', true);

if (DEV_ENVIRONMENT == true) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$scriptDir = isset($_SERVER['SCRIPT_NAME']) ? str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])) : '';
$scriptDir = rtrim($scriptDir, '/');
if ($scriptDir === '/' || $scriptDir === '.') {
    $scriptDir = '';
}

define('BASE_PATH', $scriptDir);

$protocolo = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';

define('URL_BASE', $protocolo . '://' . $host . BASE_PATH);

define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'TESTEEEEEEEEEEEE');
define('DB_USER', 'root');
define('DB_PASS', '');
