<?php

namespace app\models;

class TESTEEEEEEEEEE {
    private $id_TESTEEEEEEEEEE;
    private $NOME;

    public function getId_TESTEEEEEEEEEE() {
        return $this->id_TESTEEEEEEEEEE;
    }

    public function setId_TESTEEEEEEEEEE($id_TESTEEEEEEEEEE) {
        $this->id_TESTEEEEEEEEEE = $id_TESTEEEEEEEEEE;
    }

    public function getNOME() {
        return $this->NOME;
    }

    public function setNOME($NOME) {
        $this->NOME = $NOME;
    }

}