

<div class="page-header">
    <h1 class="page-title">Listagem de TESTEEEEEEEEEE</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/testeeeeeeeeees/cadastrar" class="btn btn-primary">
            Novo TESTEEEEEEEEEE
        </a>
    </div>
</div>

<?php if (empty($testeeeeeeeeees)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/testeeeeeeeeees/cadastrar" class="btn btn-primary">
            Criar Primeiro TESTEEEEEEEEEE
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id_TESTEEEEEEEEEE</th>
                    <th>NOME</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($testeeeeeeeeees as $testeeeeeeeeee): ?>
                    <tr>
                        <td><?= htmlspecialchars($testeeeeeeeeee['id_TESTEEEEEEEEEE'] ?? '') ?></td>
                        <td><?= htmlspecialchars($testeeeeeeeeee['NOME'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/testeeeeeeeeees/editar?id=<?= $testeeeeeeeeee['id_TESTEEEEEEEEEE'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/testeeeeeeeeees/excluir?id=<?= $testeeeeeeeeee['id_TESTEEEEEEEEEE'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>