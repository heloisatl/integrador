

<div class="page-header">
    <h1 class="page-title">Editar TESTEEEEEEEEEE</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/testeeeeeeeeees" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/testeeeeeeeeees/atualizar" method="POST">
<?php $obj = $testeeeeeeeeee; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($testeeeeeeeeee['id_TESTEEEEEEEEEE'] ?? '') ?>">
<input type='text' name='NOME' id='NOME' value='<?= $obj?$obj['NOME']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>