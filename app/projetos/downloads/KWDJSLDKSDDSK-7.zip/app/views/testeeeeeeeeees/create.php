

<div class="page-header">
    <h1 class="page-title">Cadastrar TESTEEEEEEEEEE</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/testeeeeeeeeees" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/testeeeeeeeeees/salvar" method="POST">
<?php $obj = null; ?>
<input type='text' name='NOME' id='NOME' value='<?= $obj?$obj['NOME']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>