<?php

namespace app\database;

use PDO;

/**
 * Conexão Segura com Banco de Dados via PDO (Padrão Factory / Singleton)
 *
 * Centraliza a inicialização e o compartilhamento da instância PDO:
 * 1. Padrão Singleton: Reutiliza uma única conexão ativa durante toda a requisição;
 * 2. PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION: Dispara exceções para controle rigoroso de falhas;
 * 3. PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC: Retorna dados mapeados diretamente por nome de coluna;
 * 4. Charset utf8mb4: Compatibilidade universal com acentuação e caracteres especiais.
 */
class ConnectionFactory {
    private static ?PDO $connection = null;

    public static function getConnection(): PDO {
        if (self::$connection === null) {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            self::$connection = new PDO($dsn, DB_USER, DB_PASS);
            self::$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            self::$connection->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        }

        return self::$connection;
    }
}
