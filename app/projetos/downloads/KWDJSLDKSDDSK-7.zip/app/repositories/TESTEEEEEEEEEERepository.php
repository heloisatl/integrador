<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\TESTEEEEEEEEEE;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade TESTEEEEEEEEEE
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'TESTEEEEEEEEEE':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class TESTEEEEEEEEEERepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(TESTEEEEEEEEEE $obj): bool {
        $sql = "INSERT INTO TESTEEEEEEEEEE (NOME) VALUES (?)";
        $stmt = $this->con->prepare($sql);
        $NOME = $obj->getNOME();

        return $stmt->execute([$NOME]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM TESTEEEEEEEEEE";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('id_TESTEEEEEEEEEE').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM TESTEEEEEEEEEE WHERE id_TESTEEEEEEEEEE = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(TESTEEEEEEEEEE $obj, int $id): bool {
        $NOME = $obj->getNOME();

        $sql = "UPDATE TESTEEEEEEEEEE SET NOME = ? WHERE id_TESTEEEEEEEEEE = ?";
        $params = [$NOME, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM TESTEEEEEEEEEE WHERE id_TESTEEEEEEEEEE = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}