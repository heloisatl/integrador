<?php

namespace app\services;

use app\models\TESTEEEEEEEEEE;
use app\repositories\TESTEEEEEEEEEERepository;

class TESTEEEEEEEEEEService {
    private TESTEEEEEEEEEERepository $repository;

    public function __construct() {
        $this->repository = new TESTEEEEEEEEEERepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(TESTEEEEEEEEEE $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(TESTEEEEEEEEEE $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
