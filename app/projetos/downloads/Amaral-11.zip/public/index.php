        <?php
        <?php

        error_reporting(E_ALL);
        ini_set('display_errors', 1);

        require_once __DIR__ . '/../app/core/Autoload.php';
        require_once __DIR__ . '/../app/config/Config.php';

        use app\core\Router;

        $router = new Router();

$router->get('/atributo', 'AtributoController@index');
$router->get('/atributo/cadastrar', 'AtributoController@cadastrar');
$router->post('/atributo/salvar', 'AtributoController@salvar');
$router->get('/atributo/editar/', 'AtributoController@editar');
$router->post('/atributo/atualizar/', 'AtributoController@atualizar');
$router->get('/atributo/excluir/', 'AtributoController@excluir');
$router->run();
$router->get('/banco', 'BancoController@index');
$router->get('/banco/cadastrar', 'BancoController@cadastrar');
$router->post('/banco/salvar', 'BancoController@salvar');
$router->get('/banco/editar/', 'BancoController@editar');
$router->post('/banco/atualizar/', 'BancoController@atualizar');
$router->get('/banco/excluir/', 'BancoController@excluir');
$router->run();
$router->get('/estilo', 'EstiloController@index');
$router->get('/estilo/cadastrar', 'EstiloController@cadastrar');
$router->post('/estilo/salvar', 'EstiloController@salvar');
$router->get('/estilo/editar/', 'EstiloController@editar');
$router->post('/estilo/atualizar/', 'EstiloController@atualizar');
$router->get('/estilo/excluir/', 'EstiloController@excluir');
$router->run();
$router->get('/log', 'LogController@index');
$router->get('/log/cadastrar', 'LogController@cadastrar');
$router->post('/log/salvar', 'LogController@salvar');
$router->get('/log/editar/', 'LogController@editar');
$router->post('/log/atualizar/', 'LogController@atualizar');
$router->get('/log/excluir/', 'LogController@excluir');
$router->run();
$router->get('/projeto', 'ProjetoController@index');
$router->get('/projeto/cadastrar', 'ProjetoController@cadastrar');
$router->post('/projeto/salvar', 'ProjetoController@salvar');
$router->get('/projeto/editar/', 'ProjetoController@editar');
$router->post('/projeto/atualizar/', 'ProjetoController@atualizar');
$router->get('/projeto/excluir/', 'ProjetoController@excluir');
$router->run();
$router->get('/tabela', 'TabelaController@index');
$router->get('/tabela/cadastrar', 'TabelaController@cadastrar');
$router->post('/tabela/salvar', 'TabelaController@salvar');
$router->get('/tabela/editar/', 'TabelaController@editar');
$router->post('/tabela/atualizar/', 'TabelaController@atualizar');
$router->get('/tabela/excluir/', 'TabelaController@excluir');
$router->run();
$router->get('/usuario', 'UsuarioController@index');
$router->get('/usuario/cadastrar', 'UsuarioController@cadastrar');
$router->post('/usuario/salvar', 'UsuarioController@salvar');
$router->get('/usuario/editar/', 'UsuarioController@editar');
$router->post('/usuario/atualizar/', 'UsuarioController@atualizar');
$router->get('/usuario/excluir/', 'UsuarioController@excluir');
$router->run();
