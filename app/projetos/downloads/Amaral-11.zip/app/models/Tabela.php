<?php

namespace app\models;

class Tabela {

}