<?php

namespace app\models;

class Banco {

}