<?php

namespace app\models;

class Atributo {

}