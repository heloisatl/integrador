<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Tabela;
use appepositories\TabelaRepository;

class TabelaController extends Controller {
    private TabelaRepository $repository;

    public function __construct() {
        $this->repository = new TabelaRepository();
    }

    public function index(): void {
        $data['tabelas'] = $this->repository->listarTodos();
        $this->view('tabelas/index', $data);
    }

    public function cadastrar(): void {
        $this->view('tabelas/create');
    }

    public function salvar(): void {
        $tabela = new Tabela();

        if ($this->repository->inserir($tabela)) {
            $this->redirect(URL_BASE . '/tabelas');
        } else {
            $data['erro'] = 'Erro ao cadastrar tabela.';
            $this->view('tabelas/create', $data);
        }
    }

    public function editar(): void {
        if (!$this->repository->buscarPorId($id)) {
            $this->redirect(URL_BASE . '/tabelas');
        }

        $id = (int) $_GET['id'];
        $data['tabela'] = $this->repository->buscarPorId($id);

        if (!$data['tabela']) {
            $this->redirect(URL_BASE . '/tabelas');
        }

        $this->view('tabelas/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/tabelas');
        }

        $id = (int) $_POST['id'];
        $tabela = new Tabela();

        if ($this->repository->alterar($tabela, $id)) {
            $this->redirect(URL_BASE . '/tabelas');
        } else {
            $this->redirect(URL_BASE . '/tabelas/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/tabelas');
    }
}