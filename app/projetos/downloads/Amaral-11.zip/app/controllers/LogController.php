<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Log;
use appepositories\LogRepository;

class LogController extends Controller {
    private LogRepository $repository;

    public function __construct() {
        $this->repository = new LogRepository();
    }

    public function index(): void {
        $data['logs'] = $this->repository->listarTodos();
        $this->view('logs/index', $data);
    }

    public function cadastrar(): void {
        $this->view('logs/create');
    }

    public function salvar(): void {
        $log = new Log();

        if ($this->repository->inserir($log)) {
            $this->redirect(URL_BASE . '/logs');
        } else {
            $data['erro'] = 'Erro ao cadastrar log.';
            $this->view('logs/create', $data);
        }
    }

    public function editar(): void {
        if (!$this->repository->buscarPorId($id)) {
            $this->redirect(URL_BASE . '/logs');
        }

        $id = (int) $_GET['id'];
        $data['log'] = $this->repository->buscarPorId($id);

        if (!$data['log']) {
            $this->redirect(URL_BASE . '/logs');
        }

        $this->view('logs/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/logs');
        }

        $id = (int) $_POST['id'];
        $log = new Log();

        if ($this->repository->alterar($log, $id)) {
            $this->redirect(URL_BASE . '/logs');
        } else {
            $this->redirect(URL_BASE . '/logs/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/logs');
    }
}