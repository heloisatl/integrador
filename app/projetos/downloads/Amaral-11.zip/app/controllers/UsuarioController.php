<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Usuario;
use appepositories\UsuarioRepository;

class UsuarioController extends Controller {
    private UsuarioRepository $repository;

    public function __construct() {
        $this->repository = new UsuarioRepository();
    }

    public function index(): void {
        $data['usuarios'] = $this->repository->listarTodos();
        $this->view('usuarios/index', $data);
    }

    public function cadastrar(): void {
        $this->view('usuarios/create');
    }

    public function salvar(): void {
        $usuario = new Usuario();

        if ($this->repository->inserir($usuario)) {
            $this->redirect(URL_BASE . '/usuarios');
        } else {
            $data['erro'] = 'Erro ao cadastrar usuario.';
            $this->view('usuarios/create', $data);
        }
    }

    public function editar(): void {
        if (!$this->repository->buscarPorId($id)) {
            $this->redirect(URL_BASE . '/usuarios');
        }

        $id = (int) $_GET['id'];
        $data['usuario'] = $this->repository->buscarPorId($id);

        if (!$data['usuario']) {
            $this->redirect(URL_BASE . '/usuarios');
        }

        $this->view('usuarios/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/usuarios');
        }

        $id = (int) $_POST['id'];
        $usuario = new Usuario();

        if ($this->repository->alterar($usuario, $id)) {
            $this->redirect(URL_BASE . '/usuarios');
        } else {
            $this->redirect(URL_BASE . '/usuarios/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/usuarios');
    }
}