<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Banco;
use appepositories\BancoRepository;

class BancoController extends Controller {
    private BancoRepository $repository;

    public function __construct() {
        $this->repository = new BancoRepository();
    }

    public function index(): void {
        $data['bancos'] = $this->repository->listarTodos();
        $this->view('bancos/index', $data);
    }

    public function cadastrar(): void {
        $this->view('bancos/create');
    }

    public function salvar(): void {
        $banco = new Banco();

        if ($this->repository->inserir($banco)) {
            $this->redirect(URL_BASE . '/bancos');
        } else {
            $data['erro'] = 'Erro ao cadastrar banco.';
            $this->view('bancos/create', $data);
        }
    }

    public function editar(): void {
        if (!$this->repository->buscarPorId($id)) {
            $this->redirect(URL_BASE . '/bancos');
        }

        $id = (int) $_GET['id'];
        $data['banco'] = $this->repository->buscarPorId($id);

        if (!$data['banco']) {
            $this->redirect(URL_BASE . '/bancos');
        }

        $this->view('bancos/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/bancos');
        }

        $id = (int) $_POST['id'];
        $banco = new Banco();

        if ($this->repository->alterar($banco, $id)) {
            $this->redirect(URL_BASE . '/bancos');
        } else {
            $this->redirect(URL_BASE . '/bancos/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/bancos');
    }
}