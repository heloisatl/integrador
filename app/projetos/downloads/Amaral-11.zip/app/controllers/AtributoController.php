<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Atributo;
use appepositories\AtributoRepository;

class AtributoController extends Controller {
    private AtributoRepository $repository;

    public function __construct() {
        $this->repository = new AtributoRepository();
    }

    public function index(): void {
        $data['atributos'] = $this->repository->listarTodos();
        $this->view('atributos/index', $data);
    }

    public function cadastrar(): void {
        $this->view('atributos/create');
    }

    public function salvar(): void {
        $atributo = new Atributo();

        if ($this->repository->inserir($atributo)) {
            $this->redirect(URL_BASE . '/atributos');
        } else {
            $data['erro'] = 'Erro ao cadastrar atributo.';
            $this->view('atributos/create', $data);
        }
    }

    public function editar(): void {
        if (!$this->repository->buscarPorId($id)) {
            $this->redirect(URL_BASE . '/atributos');
        }

        $id = (int) $_GET['id'];
        $data['atributo'] = $this->repository->buscarPorId($id);

        if (!$data['atributo']) {
            $this->redirect(URL_BASE . '/atributos');
        }

        $this->view('atributos/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/atributos');
        }

        $id = (int) $_POST['id'];
        $atributo = new Atributo();

        if ($this->repository->alterar($atributo, $id)) {
            $this->redirect(URL_BASE . '/atributos');
        } else {
            $this->redirect(URL_BASE . '/atributos/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/atributos');
    }
}