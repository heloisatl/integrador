<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Estilo;
use appepositories\EstiloRepository;

class EstiloController extends Controller {
    private EstiloRepository $repository;

    public function __construct() {
        $this->repository = new EstiloRepository();
    }

    public function index(): void {
        $data['estilos'] = $this->repository->listarTodos();
        $this->view('estilos/index', $data);
    }

    public function cadastrar(): void {
        $this->view('estilos/create');
    }

    public function salvar(): void {
        $estilo = new Estilo();

        if ($this->repository->inserir($estilo)) {
            $this->redirect(URL_BASE . '/estilos');
        } else {
            $data['erro'] = 'Erro ao cadastrar estilo.';
            $this->view('estilos/create', $data);
        }
    }

    public function editar(): void {
        if (!$this->repository->buscarPorId($id)) {
            $this->redirect(URL_BASE . '/estilos');
        }

        $id = (int) $_GET['id'];
        $data['estilo'] = $this->repository->buscarPorId($id);

        if (!$data['estilo']) {
            $this->redirect(URL_BASE . '/estilos');
        }

        $this->view('estilos/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/estilos');
        }

        $id = (int) $_POST['id'];
        $estilo = new Estilo();

        if ($this->repository->alterar($estilo, $id)) {
            $this->redirect(URL_BASE . '/estilos');
        } else {
            $this->redirect(URL_BASE . '/estilos/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/estilos');
    }
}