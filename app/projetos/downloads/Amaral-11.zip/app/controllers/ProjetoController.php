<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Projeto;
use appepositories\ProjetoRepository;

class ProjetoController extends Controller {
    private ProjetoRepository $repository;

    public function __construct() {
        $this->repository = new ProjetoRepository();
    }

    public function index(): void {
        $data['projetos'] = $this->repository->listarTodos();
        $this->view('projetos/index', $data);
    }

    public function cadastrar(): void {
        $this->view('projetos/create');
    }

    public function salvar(): void {
        $projeto = new Projeto();

        if ($this->repository->inserir($projeto)) {
            $this->redirect(URL_BASE . '/projetos');
        } else {
            $data['erro'] = 'Erro ao cadastrar projeto.';
            $this->view('projetos/create', $data);
        }
    }

    public function editar(): void {
        if (!$this->repository->buscarPorId($id)) {
            $this->redirect(URL_BASE . '/projetos');
        }

        $id = (int) $_GET['id'];
        $data['projeto'] = $this->repository->buscarPorId($id);

        if (!$data['projeto']) {
            $this->redirect(URL_BASE . '/projetos');
        }

        $this->view('projetos/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/projetos');
        }

        $id = (int) $_POST['id'];
        $projeto = new Projeto();

        if ($this->repository->alterar($projeto, $id)) {
            $this->redirect(URL_BASE . '/projetos');
        } else {
            $this->redirect(URL_BASE . '/projetos/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/projetos');
    }
}