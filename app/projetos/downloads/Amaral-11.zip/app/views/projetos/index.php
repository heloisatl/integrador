<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Projeto</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/projetos/cadastrar" class="btn btn-primary">
            Novo Projeto
        </a>
    </div>
</div>

<?php if (empty($projetos)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/projetos/cadastrar" class="btn btn-primary">
            Criar Primeiro Projeto
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($projetos as $projeto): ?>
                    <tr>
                        <td>
                            <a href="<?= URL_BASE ?>/projetos/editar?id=<?= $projeto['id_projeto'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/projetos/excluir?id=<?= $projeto['id_projeto'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>