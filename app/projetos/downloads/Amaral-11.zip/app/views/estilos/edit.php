<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Editar Estilo</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/estilos" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/estilos/atualizar" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($estilo['id_estilo'] ?? '') ?>">

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>