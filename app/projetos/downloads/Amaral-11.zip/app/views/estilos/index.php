<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Estilo</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/estilos/cadastrar" class="btn btn-primary">
            Novo Estilo
        </a>
    </div>
</div>

<?php if (empty($estilos)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/estilos/cadastrar" class="btn btn-primary">
            Criar Primeiro Estilo
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($estilos as $estilo): ?>
                    <tr>
                        <td>
                            <a href="<?= URL_BASE ?>/estilos/editar?id=<?= $estilo['id_estilo'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/estilos/excluir?id=<?= $estilo['id_estilo'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>