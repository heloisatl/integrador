<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Tabela</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/tabelas/cadastrar" class="btn btn-primary">
            Novo Tabela
        </a>
    </div>
</div>

<?php if (empty($tabelas)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/tabelas/cadastrar" class="btn btn-primary">
            Criar Primeiro Tabela
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tabelas as $tabela): ?>
                    <tr>
                        <td>
                            <a href="<?= URL_BASE ?>/tabelas/editar?id=<?= $tabela['id_tabela'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/tabelas/excluir?id=<?= $tabela['id_tabela'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>