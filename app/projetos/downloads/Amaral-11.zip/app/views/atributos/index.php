<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Atributo</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/atributos/cadastrar" class="btn btn-primary">
            Novo Atributo
        </a>
    </div>
</div>

<?php if (empty($atributos)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/atributos/cadastrar" class="btn btn-primary">
            Criar Primeiro Atributo
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($atributos as $atributo): ?>
                    <tr>
                        <td>
                            <a href="<?= URL_BASE ?>/atributos/editar?id=<?= $atributo['id_atributo'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/atributos/excluir?id=<?= $atributo['id_atributo'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>