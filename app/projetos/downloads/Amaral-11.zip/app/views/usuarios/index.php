<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Usuario</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/usuarios/cadastrar" class="btn btn-primary">
            Novo Usuario
        </a>
    </div>
</div>

<?php if (empty($usuarios)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/usuarios/cadastrar" class="btn btn-primary">
            Criar Primeiro Usuario
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $usuario): ?>
                    <tr>
                        <td>
                            <a href="<?= URL_BASE ?>/usuarios/editar?id=<?= $usuario['id_usuario'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/usuarios/excluir?id=<?= $usuario['id_usuario'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>