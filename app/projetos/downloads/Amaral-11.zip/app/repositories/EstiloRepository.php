<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Estilo;
use PDO;

class EstiloRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Estilo $obj): bool {
        $sql = "INSERT INTO estilo (css_customizado, conteudo_principal, cabecalho, links, cor_primaria, cor_secundaria, tamanho_fonte) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $css_customizado = $obj->getCss_customizado();
        $conteudo_principal = $obj->getConteudo_principal();
        $cabecalho = $obj->getCabecalho();
        $links = $obj->getLinks();
        $cor_primaria = $obj->getCor_primaria();
        $cor_secundaria = $obj->getCor_secundaria();
        $tamanho_fonte = $obj->getTamanho_fonte();

        return $stmt->execute([$css_customizado, $conteudo_principal, $cabecalho, $links, $cor_primaria, $cor_secundaria, $tamanho_fonte]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM estilo";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM estilo WHERE id_estilo = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Estilo $obj, int $id): bool {
        $css_customizado = $obj->getCss_customizado();
        $conteudo_principal = $obj->getConteudo_principal();
        $cabecalho = $obj->getCabecalho();
        $links = $obj->getLinks();
        $cor_primaria = $obj->getCor_primaria();
        $cor_secundaria = $obj->getCor_secundaria();
        $tamanho_fonte = $obj->getTamanho_fonte();

        $sql = "UPDATE estilo SET css_customizado = ?, conteudo_principal = ?, cabecalho = ?, links = ?, cor_primaria = ?, cor_secundaria = ?, tamanho_fonte = ? WHERE id_estilo = ?";
        $params = [$css_customizado, $conteudo_principal, $cabecalho, $links, $cor_primaria, $cor_secundaria, $tamanho_fonte, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM estilo WHERE id_estilo = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}