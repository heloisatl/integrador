<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Usuario;
use PDO;

class UsuarioRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Usuario $obj): bool {
        $sql = "INSERT INTO usuario (nome, email, senha_usuario, tipo_perfil) VALUES (?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $nome = $obj->getNome();
        $email = $obj->getEmail();
        $senha_usuario = $obj->getSenha_usuario();
        $tipo_perfil = $obj->getTipo_perfil();

        return $stmt->execute([$nome, $email, $senha_usuario, $tipo_perfil]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM usuario";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM usuario WHERE id_usuario = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Usuario $obj, int $id): bool {
        $nome = $obj->getNome();
        $email = $obj->getEmail();
        $senha_usuario = $obj->getSenha_usuario();
        $tipo_perfil = $obj->getTipo_perfil();

        $sql = "UPDATE usuario SET nome = ?, email = ?, senha_usuario = ?, tipo_perfil = ? WHERE id_usuario = ?";
        $params = [$nome, $email, $senha_usuario, $tipo_perfil, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM usuario WHERE id_usuario = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}