<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Banco;
use PDO;

class BancoRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Banco $obj): bool {
        $sql = "INSERT INTO banco (fk_usuario, nome_banco, usuario_banco, senha_banco, host, porta) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $fk_usuario = $obj->getFk_usuario();
        $nome_banco = $obj->getNome_banco();
        $usuario_banco = $obj->getUsuario_banco();
        $senha_banco = $obj->getSenha_banco();
        $host = $obj->getHost();
        $porta = $obj->getPorta();

        return $stmt->execute([$fk_usuario, $nome_banco, $usuario_banco, $senha_banco, $host, $porta]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM banco";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM banco WHERE id_banco = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Banco $obj, int $id): bool {
        $fk_usuario = $obj->getFk_usuario();
        $nome_banco = $obj->getNome_banco();
        $usuario_banco = $obj->getUsuario_banco();
        $senha_banco = $obj->getSenha_banco();
        $host = $obj->getHost();
        $porta = $obj->getPorta();

        $sql = "UPDATE banco SET fk_usuario = ?, nome_banco = ?, usuario_banco = ?, senha_banco = ?, host = ?, porta = ? WHERE id_banco = ?";
        $params = [$fk_usuario, $nome_banco, $usuario_banco, $senha_banco, $host, $porta, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM banco WHERE id_banco = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}