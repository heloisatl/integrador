<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Projeto;
use PDO;

class ProjetoRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Projeto $obj): bool {
        $sql = "INSERT INTO projeto (id_usuario, fk_banco, fk_estilo, ultimo_download, nome_projeto, data_criacao, prazo_de_vida, caminho_armazenamento, comentarios, views) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $id_usuario = $obj->getId_usuario();
        $fk_banco = $obj->getFk_banco();
        $fk_estilo = $obj->getFk_estilo();
        $ultimo_download = $obj->getUltimo_download();
        $nome_projeto = $obj->getNome_projeto();
        $data_criacao = $obj->getData_criacao();
        $prazo_de_vida = $obj->getPrazo_de_vida();
        $caminho_armazenamento = $obj->getCaminho_armazenamento();
        $comentarios = $obj->getComentarios();
        $views = $obj->getViews();

        return $stmt->execute([$id_usuario, $fk_banco, $fk_estilo, $ultimo_download, $nome_projeto, $data_criacao, $prazo_de_vida, $caminho_armazenamento, $comentarios, $views]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM projeto";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM projeto WHERE id_projeto = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Projeto $obj, int $id): bool {
        $id_usuario = $obj->getId_usuario();
        $fk_banco = $obj->getFk_banco();
        $fk_estilo = $obj->getFk_estilo();
        $ultimo_download = $obj->getUltimo_download();
        $nome_projeto = $obj->getNome_projeto();
        $data_criacao = $obj->getData_criacao();
        $prazo_de_vida = $obj->getPrazo_de_vida();
        $caminho_armazenamento = $obj->getCaminho_armazenamento();
        $comentarios = $obj->getComentarios();
        $views = $obj->getViews();

        $sql = "UPDATE projeto SET id_usuario = ?, fk_banco = ?, fk_estilo = ?, ultimo_download = ?, nome_projeto = ?, data_criacao = ?, prazo_de_vida = ?, caminho_armazenamento = ?, comentarios = ?, views = ? WHERE id_projeto = ?";
        $params = [$id_usuario, $fk_banco, $fk_estilo, $ultimo_download, $nome_projeto, $data_criacao, $prazo_de_vida, $caminho_armazenamento, $comentarios, $views, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM projeto WHERE id_projeto = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}