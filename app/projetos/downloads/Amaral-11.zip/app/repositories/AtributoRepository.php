<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Atributo;
use PDO;

class AtributoRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Atributo $obj): bool {
        $sql = "INSERT INTO atributo (fk_tabela, fk_atributo, nome_atributo, tipo, PK, NN, AI, UQ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $fk_tabela = $obj->getFk_tabela();
        $fk_atributo = $obj->getFk_atributo();
        $nome_atributo = $obj->getNome_atributo();
        $tipo = $obj->getTipo();
        $PK = $obj->getPK();
        $NN = $obj->getNN();
        $AI = $obj->getAI();
        $UQ = $obj->getUQ();

        return $stmt->execute([$fk_tabela, $fk_atributo, $nome_atributo, $tipo, $PK, $NN, $AI, $UQ]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM atributo";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM atributo WHERE id_atributo = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Atributo $obj, int $id): bool {
        $fk_tabela = $obj->getFk_tabela();
        $fk_atributo = $obj->getFk_atributo();
        $nome_atributo = $obj->getNome_atributo();
        $tipo = $obj->getTipo();
        $PK = $obj->getPK();
        $NN = $obj->getNN();
        $AI = $obj->getAI();
        $UQ = $obj->getUQ();

        $sql = "UPDATE atributo SET fk_tabela = ?, fk_atributo = ?, nome_atributo = ?, tipo = ?, PK = ?, NN = ?, AI = ?, UQ = ? WHERE id_atributo = ?";
        $params = [$fk_tabela, $fk_atributo, $nome_atributo, $tipo, $PK, $NN, $AI, $UQ, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM atributo WHERE id_atributo = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}