<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Tabela;
use PDO;

class TabelaRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Tabela $obj): bool {
        $sql = "INSERT INTO tabela (nome_tabela) VALUES (?)";
        $stmt = $this->con->prepare($sql);
        $nome_tabela = $obj->getNome_tabela();

        return $stmt->execute([$nome_tabela]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM tabela";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM tabela WHERE id_tabela = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Tabela $obj, int $id): bool {
        $nome_tabela = $obj->getNome_tabela();

        $sql = "UPDATE tabela SET nome_tabela = ? WHERE id_tabela = ?";
        $params = [$nome_tabela, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM tabela WHERE id_tabela = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}