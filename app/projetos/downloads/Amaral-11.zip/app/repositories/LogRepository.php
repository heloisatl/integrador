<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Log;
use PDO;

class LogRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Log $obj): bool {
        $sql = "INSERT INTO log (acao, data) VALUES (?, ?)";
        $stmt = $this->con->prepare($sql);
        $acao = $obj->getAcao();
        $data = $obj->getData();

        return $stmt->execute([$acao, $data]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM log";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM log WHERE id_log = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Log $obj, int $id): bool {
        $acao = $obj->getAcao();
        $data = $obj->getData();

        $sql = "UPDATE log SET acao = ?, data = ? WHERE id_log = ?";
        $params = [$acao, $data, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM log WHERE id_log = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}