<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Cliente;
use appepositories\ClienteRepository;

class ClienteController extends Controller {
    private ClienteRepository $repository;

    public function __construct() {
        $this->repository = new ClienteRepository();
    }

    public function index(): void {
        $data['clientes'] = $this->repository->listarTodos();
        $this->view('clientes/index', $data);
    }

    public function cadastrar(): void {
        $this->view('clientes/create');
    }

    public function salvar(): void {
        $cliente = new Cliente();

        if ($this->repository->inserir($cliente)) {
            $this->redirect(URL_BASE . '/clientes');
        } else {
            $data['erro'] = 'Erro ao cadastrar cliente.';
            $this->view('clientes/create', $data);
        }
    }

    public function editar(): void {
        if (!$this->repository->buscarPorId($id)) {
            $this->redirect(URL_BASE . '/clientes');
        }

        $id = (int) $_GET['id'];
        $data['cliente'] = $this->repository->buscarPorId($id);

        if (!$data['cliente']) {
            $this->redirect(URL_BASE . '/clientes');
        }

        $this->view('clientes/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/clientes');
        }

        $id = (int) $_POST['id'];
        $cliente = new Cliente();

        if ($this->repository->alterar($cliente, $id)) {
            $this->redirect(URL_BASE . '/clientes');
        } else {
            $this->redirect(URL_BASE . '/clientes/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/clientes');
    }
}