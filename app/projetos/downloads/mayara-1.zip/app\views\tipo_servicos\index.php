<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Tipo_servico</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/tipo_servicos/cadastrar" class="btn btn-primary">
            Novo Tipo_servico
        </a>
    </div>
</div>

<?php if (empty($tipo_servicos)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/tipo_servicos/cadastrar" class="btn btn-primary">
            Criar Primeiro Tipo_servico
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tipo_servicos as $tipo_servico): ?>
                    <tr>
                        <td>
                            <a href="<?= URL_BASE ?>/tipo_servicos/editar?id=<?= $tipo_servico['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/tipo_servicos/excluir?id=<?= $tipo_servico['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>