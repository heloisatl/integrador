<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Ordem_servico;
use appepositories\Ordem_servicoRepository;

class Ordem_servicoController extends Controller {
    private Ordem_servicoRepository $repository;

    public function __construct() {
        $this->repository = new Ordem_servicoRepository();
    }

    public function index(): void {
        $data['ordem_servicos'] = $this->repository->listarTodos();
        $this->view('ordem_servicos/index', $data);
    }

    public function cadastrar(): void {
        $this->view('ordem_servicos/create');
    }

    public function salvar(): void {
        $ordem_servico = new Ordem_servico();

        if ($this->repository->inserir($ordem_servico)) {
            $this->redirect(URL_BASE . '/ordem_servicos');
        } else {
            $data['erro'] = 'Erro ao cadastrar ordem_servico.';
            $this->view('ordem_servicos/create', $data);
        }
    }

    public function editar(): void {
        if (!$this->repository->buscarPorId($id)) {
            $this->redirect(URL_BASE . '/ordem_servicos');
        }

        $id = (int) $_GET['id'];
        $data['ordem_servico'] = $this->repository->buscarPorId($id);

        if (!$data['ordem_servico']) {
            $this->redirect(URL_BASE . '/ordem_servicos');
        }

        $this->view('ordem_servicos/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/ordem_servicos');
        }

        $id = (int) $_POST['id'];
        $ordem_servico = new Ordem_servico();

        if ($this->repository->alterar($ordem_servico, $id)) {
            $this->redirect(URL_BASE . '/ordem_servicos');
        } else {
            $this->redirect(URL_BASE . '/ordem_servicos/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/ordem_servicos');
    }
}