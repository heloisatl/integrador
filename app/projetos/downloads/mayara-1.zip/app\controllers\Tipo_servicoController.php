<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Tipo_servico;
use appepositories\Tipo_servicoRepository;

class Tipo_servicoController extends Controller {
    private Tipo_servicoRepository $repository;

    public function __construct() {
        $this->repository = new Tipo_servicoRepository();
    }

    public function index(): void {
        $data['tipo_servicos'] = $this->repository->listarTodos();
        $this->view('tipo_servicos/index', $data);
    }

    public function cadastrar(): void {
        $this->view('tipo_servicos/create');
    }

    public function salvar(): void {
        $tipo_servico = new Tipo_servico();

        if ($this->repository->inserir($tipo_servico)) {
            $this->redirect(URL_BASE . '/tipo_servicos');
        } else {
            $data['erro'] = 'Erro ao cadastrar tipo_servico.';
            $this->view('tipo_servicos/create', $data);
        }
    }

    public function editar(): void {
        if (!$this->repository->buscarPorId($id)) {
            $this->redirect(URL_BASE . '/tipo_servicos');
        }

        $id = (int) $_GET['id'];
        $data['tipo_servico'] = $this->repository->buscarPorId($id);

        if (!$data['tipo_servico']) {
            $this->redirect(URL_BASE . '/tipo_servicos');
        }

        $this->view('tipo_servicos/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/tipo_servicos');
        }

        $id = (int) $_POST['id'];
        $tipo_servico = new Tipo_servico();

        if ($this->repository->alterar($tipo_servico, $id)) {
            $this->redirect(URL_BASE . '/tipo_servicos');
        } else {
            $this->redirect(URL_BASE . '/tipo_servicos/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/tipo_servicos');
    }
}