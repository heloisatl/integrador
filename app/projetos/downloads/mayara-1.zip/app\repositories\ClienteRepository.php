<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Cliente;
use PDO;

class ClienteRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Cliente $obj): bool {
        $sql = "INSERT INTO cliente (nome, telefone, email) VALUES (?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $nome = $obj->getNome();
        $telefone = $obj->getTelefone();
        $email = $obj->getEmail();

        return $stmt->execute([$nome, $telefone, $email]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM cliente";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM cliente WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Cliente $obj, int $id): bool {
        $nome = $obj->getNome();
        $telefone = $obj->getTelefone();
        $email = $obj->getEmail();

        $sql = "UPDATE cliente SET nome = ?, telefone = ?, email = ? WHERE id = ?";
        $params = [$nome, $telefone, $email, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM cliente WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}