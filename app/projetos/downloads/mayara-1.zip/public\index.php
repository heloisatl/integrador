        <?php
        <?php

        error_reporting(E_ALL);
        ini_set('display_errors', 1);

        require_once __DIR__ . '/../app/core/Autoload.php';
        require_once __DIR__ . '/../app/config/Config.php';

        use app\core\Router;

        $router = new Router();

$router->get('/cliente', 'ClienteController@index');
$router->get('/cliente/cadastrar', 'ClienteController@cadastrar');
$router->post('/cliente/salvar', 'ClienteController@salvar');
$router->get('/cliente/editar/', 'ClienteController@editar');
$router->post('/cliente/atualizar/', 'ClienteController@atualizar');
$router->get('/cliente/excluir/', 'ClienteController@excluir');
$router->run();
$router->get('/ordem_servico', 'Ordem_servicoController@index');
$router->get('/ordem_servico/cadastrar', 'Ordem_servicoController@cadastrar');
$router->post('/ordem_servico/salvar', 'Ordem_servicoController@salvar');
$router->get('/ordem_servico/editar/', 'Ordem_servicoController@editar');
$router->post('/ordem_servico/atualizar/', 'Ordem_servicoController@atualizar');
$router->get('/ordem_servico/excluir/', 'Ordem_servicoController@excluir');
$router->run();
$router->get('/tipo_servico', 'Tipo_servicoController@index');
$router->get('/tipo_servico/cadastrar', 'Tipo_servicoController@cadastrar');
$router->post('/tipo_servico/salvar', 'Tipo_servicoController@salvar');
$router->get('/tipo_servico/editar/', 'Tipo_servicoController@editar');
$router->post('/tipo_servico/atualizar/', 'Tipo_servicoController@atualizar');
$router->get('/tipo_servico/excluir/', 'Tipo_servicoController@excluir');
$router->run();
