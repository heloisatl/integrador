<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Ordem_servico;
use PDO;

class Ordem_servicoRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Ordem_servico $obj): bool {
        $sql = "INSERT INTO ordem_servico (descricao_problema, data_abertura, prazo_estimado, status, id_cliente, id_tipo_servico) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $descricao_problema = $obj->getDescricao_problema();
        $data_abertura = $obj->getData_abertura();
        $prazo_estimado = $obj->getPrazo_estimado();
        $status = $obj->getStatus();
        $id_cliente = $obj->getId_cliente();
        $id_tipo_servico = $obj->getId_tipo_servico();

        return $stmt->execute([$descricao_problema, $data_abertura, $prazo_estimado, $status, $id_cliente, $id_tipo_servico]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM ordem_servico";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM ordem_servico WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Ordem_servico $obj, int $id): bool {
        $descricao_problema = $obj->getDescricao_problema();
        $data_abertura = $obj->getData_abertura();
        $prazo_estimado = $obj->getPrazo_estimado();
        $status = $obj->getStatus();
        $id_cliente = $obj->getId_cliente();
        $id_tipo_servico = $obj->getId_tipo_servico();

        $sql = "UPDATE ordem_servico SET descricao_problema = ?, data_abertura = ?, prazo_estimado = ?, status = ?, id_cliente = ?, id_tipo_servico = ? WHERE id = ?";
        $params = [$descricao_problema, $data_abertura, $prazo_estimado, $status, $id_cliente, $id_tipo_servico, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM ordem_servico WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}