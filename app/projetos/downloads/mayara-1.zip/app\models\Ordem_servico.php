<?php

namespace app\models;

class Ordem_servico {

}