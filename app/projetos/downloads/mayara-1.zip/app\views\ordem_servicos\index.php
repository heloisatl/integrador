<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Ordem_servico</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/ordem_servicos/cadastrar" class="btn btn-primary">
            Novo Ordem_servico
        </a>
    </div>
</div>

<?php if (empty($ordem_servicos)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/ordem_servicos/cadastrar" class="btn btn-primary">
            Criar Primeiro Ordem_servico
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($ordem_servicos as $ordem_servico): ?>
                    <tr>
                        <td>
                            <a href="<?= URL_BASE ?>/ordem_servicos/editar?id=<?= $ordem_servico['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/ordem_servicos/excluir?id=<?= $ordem_servico['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>