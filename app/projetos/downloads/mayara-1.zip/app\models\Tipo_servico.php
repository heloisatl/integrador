<?php

namespace app\models;

class Tipo_servico {

}