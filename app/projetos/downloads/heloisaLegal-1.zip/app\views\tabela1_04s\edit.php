

<div class="page-header">
    <h1 class="page-title">Editar Tabela1_04</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/tabela1_04s" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/tabela1_04s/atualizar" method="POST">
<?php $obj = $tabela1_04; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($tabela1_04['id_tabela1_1'] ?? '') ?>">
<input type='text' name='id_tabela1_2' id='id_tabela1_2' value='<?= $obj?$obj['id_tabela1_2']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>