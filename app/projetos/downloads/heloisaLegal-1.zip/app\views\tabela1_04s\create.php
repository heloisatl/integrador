

<div class="page-header">
    <h1 class="page-title">Cadastrar Tabela1_04</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/tabela1_04s" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/tabela1_04s/salvar" method="POST">
<?php $obj = null; ?>
<input type='text' name='id_tabela1_2' id='id_tabela1_2' value='<?= $obj?$obj['id_tabela1_2']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>