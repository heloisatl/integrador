<?php

namespace app\models;

class Tabela1_04 {
    private $id_tabela1_1;
    private $id_tabela1_2;

    public function getId_tabela1_1() {
        return $this->id_tabela1_1;
    }

    public function setId_tabela1_1($id_tabela1_1) {
        $this->id_tabela1_1 = $id_tabela1_1;
    }

    public function getId_tabela1_2() {
        return $this->id_tabela1_2;
    }

    public function setId_tabela1_2($id_tabela1_2) {
        $this->id_tabela1_2 = $id_tabela1_2;
    }

}