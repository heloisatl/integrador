<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Tabela1_04;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Tabela1_04
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'tabela1_04':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class Tabela1_04Repository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Tabela1_04 $obj): bool {
        $sql = "INSERT INTO tabela1_04 (id_tabela1_2) VALUES (?)";
        $stmt = $this->con->prepare($sql);
        $id_tabela1_2 = $obj->getId_tabela1_2();

        return $stmt->execute([$id_tabela1_2]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM tabela1_04";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('id_tabela1_1').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM tabela1_04 WHERE id_tabela1_1 = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Tabela1_04 $obj, int $id): bool {
        $id_tabela1_2 = $obj->getId_tabela1_2();

        $sql = "UPDATE tabela1_04 SET id_tabela1_2 = ? WHERE id_tabela1_1 = ?";
        $params = [$id_tabela1_2, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM tabela1_04 WHERE id_tabela1_1 = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}