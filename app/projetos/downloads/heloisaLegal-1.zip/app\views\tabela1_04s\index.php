

<div class="page-header">
    <h1 class="page-title">Listagem de Tabela1_04</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/tabela1_04s/cadastrar" class="btn btn-primary">
            Novo Tabela1_04
        </a>
    </div>
</div>

<?php if (empty($tabela1_04s)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/tabela1_04s/cadastrar" class="btn btn-primary">
            Criar Primeiro Tabela1_04
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id_tabela1_1</th>
                    <th>Id_tabela1_2</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tabela1_04s as $tabela1_04): ?>
                    <tr>
                        <td><?= htmlspecialchars($tabela1_04['id_tabela1_1'] ?? '') ?></td>
                        <td><?= htmlspecialchars($tabela1_04['id_tabela1_2'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/tabela1_04s/editar?id=<?= $tabela1_04['id_tabela1_1'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/tabela1_04s/excluir?id=<?= $tabela1_04['id_tabela1_1'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>