-- Script gerado automaticamente pelo DevStudio (MVC Creator)
CREATE DATABASE IF NOT EXISTS `teste1` DEFAULT CHARACTER SET utf8mb4;
USE `teste1`;

CREATE TABLE IF NOT EXISTS `tabela1_04` (
    `id_tabela1_1` TEXT NOT NULL AUTO_INCREMENT,
    `id_tabela1_2` VARCHAR(60),
    PRIMARY KEY (`id_tabela1_1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

