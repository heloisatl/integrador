<?php

namespace app\services;

use app\models\Tabela1_04;
use app\repositories\Tabela1_04Repository;

class Tabela1_04Service {
    private Tabela1_04Repository $repository;

    public function __construct() {
        $this->repository = new Tabela1_04Repository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Tabela1_04 $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Tabela1_04 $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
