<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Tabela1_04;
use app\services\Tabela1_04Service;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (Tabela1_04Service) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class Tabela1_04Controller extends Controller {
    private Tabela1_04Service $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (Tabela1_04Service).
     */
    public function __construct() {
        $this->repository = new Tabela1_04Service();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (tabela1_04s/index).
     */
    public function index(): void {
        $data['tabela1_04s'] = $this->repository->listarTodos();
        $this->view('tabela1_04s/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('tabela1_04s/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Tabela1_04 e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $tabela1_04 = new Tabela1_04();
        $tabela1_04->setId_tabela1_2($_POST['id_tabela1_2'] ?? '');

        if ($this->repository->inserir($tabela1_04)) {
            $this->redirect(URL_BASE . '/tabela1_04s');
        } else {
            $data['erro'] = 'Erro ao cadastrar tabela1_04.';
            $this->view('tabela1_04s/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['tabela1_04'] = $this->repository->buscarPorId($id);

        if (!$data['tabela1_04']) {
            $this->redirect(URL_BASE . '/tabela1_04s');
        }

        $this->view('tabela1_04s/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Tabela1_04 e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/tabela1_04s');
        }

        $id = (int) $_POST['id'];
        $tabela1_04 = new Tabela1_04();
        $tabela1_04->setId_tabela1_2($_POST['id_tabela1_2'] ?? '');

        if ($this->repository->alterar($tabela1_04, $id)) {
            $this->redirect(URL_BASE . '/tabela1_04s');
        } else {
            $this->redirect(URL_BASE . '/tabela1_04s/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/tabela1_04s');
    }
}