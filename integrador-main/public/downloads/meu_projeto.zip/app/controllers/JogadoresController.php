<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Jogadores;
use appepositories\JogadoresRepository;

class JogadoresController extends Controller {
    private JogadoresRepository $repository;

    public function __construct() {
        $this->repository = new JogadoresRepository();
    }

    public function index(): void {
        $data['jogadoress'] = $this->repository->listarTodos();
        $this->view('jogadoress/index', $data);
    }

    public function cadastrar(): void {
        $this->view('jogadoress/create');
    }

    public function salvar(): void {
        $jogadores = new Jogadores();
        $jogadores->setData_nascimento($_POST['data_nascimento'] ?? '');
        $jogadores->setNacionalidade($_POST['nacionalidade'] ?? '');
        $jogadores->setAltura($_POST['altura'] ?? '');
        $jogadores->setPeso($_POST['peso'] ?? '');
        $jogadores->setPe_dominante($_POST['pe_dominante'] ?? '');
        $jogadores->setPosicao($_POST['posicao'] ?? '');
        $jogadores->setTime($_POST['time'] ?? '');
        $jogadores->setImagem($_POST['imagem'] ?? '');
        $jogadores->setCriado_em($_POST['criado_em'] ?? '');
        $jogadores->setNome_usuario($_POST['nome_usuario'] ?? '');
        $jogadores->setSenha($_POST['senha'] ?? '');
        $jogadores->setPerfil($_POST['perfil'] ?? '');

        if ($this->repository->inserir($jogadores)) {
            $this->redirect(URL_BASE . '/jogadoress');
        } else {
            $data['erro'] = 'Erro ao cadastrar jogadores.';
            $this->view('jogadoress/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/jogadoress');
        }

        $id = (int) $_GET['id'];
        $data['jogadores'] = $this->repository->buscarPorId($id);

        if (!$data['jogadores']) {
            $this->redirect(URL_BASE . '/jogadoress');
        }

        $this->view('jogadoress/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/jogadoress');
        }

        $id = (int) $_POST['id'];
        $jogadores = new Jogadores();
        $jogadores->setData_nascimento($_POST['data_nascimento'] ?? '');
        $jogadores->setNacionalidade($_POST['nacionalidade'] ?? '');
        $jogadores->setAltura($_POST['altura'] ?? '');
        $jogadores->setPeso($_POST['peso'] ?? '');
        $jogadores->setPe_dominante($_POST['pe_dominante'] ?? '');
        $jogadores->setPosicao($_POST['posicao'] ?? '');
        $jogadores->setTime($_POST['time'] ?? '');
        $jogadores->setImagem($_POST['imagem'] ?? '');
        $jogadores->setCriado_em($_POST['criado_em'] ?? '');
        $jogadores->setNome_usuario($_POST['nome_usuario'] ?? '');
        $jogadores->setSenha($_POST['senha'] ?? '');
        $jogadores->setPerfil($_POST['perfil'] ?? '');

        if ($this->repository->alterar($jogadores, $id)) {
            $this->redirect(URL_BASE . '/jogadoress');
        } else {
            $this->redirect(URL_BASE . '/jogadoress/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/jogadoress');
    }
}