<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Usuarios;
use appepositories\UsuariosRepository;

class UsuariosController extends Controller {
    private UsuariosRepository $repository;

    public function __construct() {
        $this->repository = new UsuariosRepository();
    }

    public function index(): void {
        $data['usuarioss'] = $this->repository->listarTodos();
        $this->view('usuarioss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('usuarioss/create');
    }

    public function salvar(): void {
        $usuarios = new Usuarios();
        $usuarios->setData_nascimento($_POST['data_nascimento'] ?? '');
        $usuarios->setNacionalidade($_POST['nacionalidade'] ?? '');
        $usuarios->setAltura($_POST['altura'] ?? '');
        $usuarios->setPeso($_POST['peso'] ?? '');
        $usuarios->setPe_dominante($_POST['pe_dominante'] ?? '');
        $usuarios->setPosicao($_POST['posicao'] ?? '');
        $usuarios->setTime($_POST['time'] ?? '');
        $usuarios->setImagem($_POST['imagem'] ?? '');
        $usuarios->setCriado_em($_POST['criado_em'] ?? '');
        $usuarios->setNome_usuario($_POST['nome_usuario'] ?? '');
        $usuarios->setSenha($_POST['senha'] ?? '');
        $usuarios->setPerfil($_POST['perfil'] ?? '');

        if ($this->repository->inserir($usuarios)) {
            $this->redirect(URL_BASE . '/usuarioss');
        } else {
            $data['erro'] = 'Erro ao cadastrar usuarios.';
            $this->view('usuarioss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/usuarioss');
        }

        $id = (int) $_GET['id'];
        $data['usuarios'] = $this->repository->buscarPorId($id);

        if (!$data['usuarios']) {
            $this->redirect(URL_BASE . '/usuarioss');
        }

        $this->view('usuarioss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/usuarioss');
        }

        $id = (int) $_POST['id'];
        $usuarios = new Usuarios();
        $usuarios->setData_nascimento($_POST['data_nascimento'] ?? '');
        $usuarios->setNacionalidade($_POST['nacionalidade'] ?? '');
        $usuarios->setAltura($_POST['altura'] ?? '');
        $usuarios->setPeso($_POST['peso'] ?? '');
        $usuarios->setPe_dominante($_POST['pe_dominante'] ?? '');
        $usuarios->setPosicao($_POST['posicao'] ?? '');
        $usuarios->setTime($_POST['time'] ?? '');
        $usuarios->setImagem($_POST['imagem'] ?? '');
        $usuarios->setCriado_em($_POST['criado_em'] ?? '');
        $usuarios->setNome_usuario($_POST['nome_usuario'] ?? '');
        $usuarios->setSenha($_POST['senha'] ?? '');
        $usuarios->setPerfil($_POST['perfil'] ?? '');

        if ($this->repository->alterar($usuarios, $id)) {
            $this->redirect(URL_BASE . '/usuarioss');
        } else {
            $this->redirect(URL_BASE . '/usuarioss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/usuarioss');
    }
}