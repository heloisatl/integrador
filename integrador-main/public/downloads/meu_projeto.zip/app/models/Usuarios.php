<?php

namespace app\models;

class Usuarios {
    private $id;
    private $data_nascimento;
    private $nacionalidade;
    private $altura;
    private $peso;
    private $pe_dominante;
    private $posicao;
    private $time;
    private $imagem;
    private $criado_em;
    private $id;
    private $nome_usuario;
    private $senha;
    private $perfil;

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getData_nascimento() {
        return $this->data_nascimento;
    }

    public function setData_nascimento($data_nascimento) {
        $this->data_nascimento = $data_nascimento;
    }

    public function getNacionalidade() {
        return $this->nacionalidade;
    }

    public function setNacionalidade($nacionalidade) {
        $this->nacionalidade = $nacionalidade;
    }

    public function getAltura() {
        return $this->altura;
    }

    public function setAltura($altura) {
        $this->altura = $altura;
    }

    public function getPeso() {
        return $this->peso;
    }

    public function setPeso($peso) {
        $this->peso = $peso;
    }

    public function getPe_dominante() {
        return $this->pe_dominante;
    }

    public function setPe_dominante($pe_dominante) {
        $this->pe_dominante = $pe_dominante;
    }

    public function getPosicao() {
        return $this->posicao;
    }

    public function setPosicao($posicao) {
        $this->posicao = $posicao;
    }

    public function getTime() {
        return $this->time;
    }

    public function setTime($time) {
        $this->time = $time;
    }

    public function getImagem() {
        return $this->imagem;
    }

    public function setImagem($imagem) {
        $this->imagem = $imagem;
    }

    public function getCriado_em() {
        return $this->criado_em;
    }

    public function setCriado_em($criado_em) {
        $this->criado_em = $criado_em;
    }

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getNome_usuario() {
        return $this->nome_usuario;
    }

    public function setNome_usuario($nome_usuario) {
        $this->nome_usuario = $nome_usuario;
    }

    public function getSenha() {
        return $this->senha;
    }

    public function setSenha($senha) {
        $this->senha = $senha;
    }

    public function getPerfil() {
        return $this->perfil;
    }

    public function setPerfil($perfil) {
        $this->perfil = $perfil;
    }

}