<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Editar Usuarios</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/usuarioss" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/usuarioss/atualizar" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($usuarios['id'] ?? '') ?>">
    <div class="form-group">
        <label for="data_nascimento">data_nascimento</label>
        <input type="text" name="data_nascimento" id="data_nascimento" value="<?= htmlspecialchars($usuarios['data_nascimento'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="nacionalidade">nacionalidade</label>
        <input type="text" name="nacionalidade" id="nacionalidade" value="<?= htmlspecialchars($usuarios['nacionalidade'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="altura">altura</label>
        <input type="text" name="altura" id="altura" value="<?= htmlspecialchars($usuarios['altura'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="peso">peso</label>
        <input type="text" name="peso" id="peso" value="<?= htmlspecialchars($usuarios['peso'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="pe_dominante">pe_dominante</label>
        <input type="text" name="pe_dominante" id="pe_dominante" value="<?= htmlspecialchars($usuarios['pe_dominante'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="posicao">posicao</label>
        <input type="text" name="posicao" id="posicao" value="<?= htmlspecialchars($usuarios['posicao'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="time">time</label>
        <input type="text" name="time" id="time" value="<?= htmlspecialchars($usuarios['time'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="imagem">imagem</label>
        <input type="text" name="imagem" id="imagem" value="<?= htmlspecialchars($usuarios['imagem'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="criado_em">criado_em</label>
        <input type="text" name="criado_em" id="criado_em" value="<?= htmlspecialchars($usuarios['criado_em'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="nome_usuario">nome_usuario</label>
        <input type="text" name="nome_usuario" id="nome_usuario" value="<?= htmlspecialchars($usuarios['nome_usuario'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="senha">senha</label>
        <input type="text" name="senha" id="senha" value="<?= htmlspecialchars($usuarios['senha'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="perfil">perfil</label>
        <input type="text" name="perfil" id="perfil" value="<?= htmlspecialchars($usuarios['perfil'] ?? '') ?>" class="form-control" required>
    </div>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>