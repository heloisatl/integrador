<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Usuarios</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/usuarioss/cadastrar" class="btn btn-primary">
            Novo Usuarios
        </a>
    </div>
</div>

<?php if (empty($usuarioss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/usuarioss/cadastrar" class="btn btn-primary">
            Criar Primeiro Usuarios
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Data_nascimento</th>
                    <th>Nacionalidade</th>
                    <th>Altura</th>
                    <th>Peso</th>
                    <th>Pe_dominante</th>
                    <th>Posicao</th>
                    <th>Time</th>
                    <th>Imagem</th>
                    <th>Criado_em</th>
                    <th>Id</th>
                    <th>Nome_usuario</th>
                    <th>Senha</th>
                    <th>Perfil</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarioss as $usuarios): ?>
                    <tr>
                        <td><?= htmlspecialchars($usuarios['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['data_nascimento'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['nacionalidade'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['altura'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['peso'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['pe_dominante'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['posicao'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['time'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['imagem'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['criado_em'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['nome_usuario'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['senha'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuarios['perfil'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/usuarioss/editar?id=<?= $usuarios['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/usuarioss/excluir?id=<?= $usuarios['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>