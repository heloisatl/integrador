<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Cadastrar Jogadores</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/jogadoress" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/jogadoress/salvar" method="POST">
<input type='date' name='data_nascimento' id='data_nascimento' value='<?= $obj?$obj['data_nascimento']:''?>'><br>
<input type='text' name='nacionalidade' id='nacionalidade' value='<?= $obj?$obj['nacionalidade']:''?>'><br>
<input type='number' step='0.01' name='altura' id='altura' value='<?= $obj?$obj['altura']:''?>'><br>
<input type='number' step='0.01' name='peso' id='peso' value='<?= $obj?$obj['peso']:''?>'><br>
<select name="pe_dominante" id="pe_dominante">
<option value=""><b>--</b></option>
<option value="Esquerdo" <?= $obj? ($obj['pe_dominante']=='Esquerdo' ? 'selected' : null) : null ?> ><b>Esquerdo</b></option>
<option value="Direito" <?= $obj? ($obj['pe_dominante']=='Direito' ? 'selected' : null) : null ?> ><b>Direito</b></option>
<option value="Ambos" <?= $obj? ($obj['pe_dominante']=='Ambos' ? 'selected' : null) : null ?> ><b>Ambos</b></option>
</select>
<select name="posicao" id="posicao">
<option value=""><b>--</b></option>
<option value="Goleiro" <?= $obj? ($obj['posicao']=='Goleiro' ? 'selected' : null) : null ?> ><b>Goleiro</b></option>
<option value="Defensor" <?= $obj? ($obj['posicao']=='Defensor' ? 'selected' : null) : null ?> ><b>Defensor</b></option>
<option value="Meio-campista" <?= $obj? ($obj['posicao']=='Meio-campista' ? 'selected' : null) : null ?> ><b>Meio-campista</b></option>
<option value="Atacante" <?= $obj? ($obj['posicao']=='Atacante' ? 'selected' : null) : null ?> ><b>Atacante</b></option>
</select>
<input type='text' name='time' id='time' value='<?= $obj?$obj['time']:''?>'><br>
<input type='text' name='imagem' id='imagem' value='<?= $obj?$obj['imagem']:''?>'><br>
<p><b>Erro:o tipo de atributo timestamp não foi reconhecido.</b></p><input type='text' name='nome_usuario' id='nome_usuario' value='<?= $obj?$obj['nome_usuario']:''?>'><br>
<input type='text' name='senha' id='senha' value='<?= $obj?$obj['senha']:''?>'><br>
<input type='text' name='perfil' id='perfil' value='<?= $obj?$obj['perfil']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>