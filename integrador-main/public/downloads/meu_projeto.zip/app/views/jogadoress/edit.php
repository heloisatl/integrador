<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Editar Jogadores</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/jogadoress" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/jogadoress/atualizar" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($jogadores['id'] ?? '') ?>">
    <div class="form-group">
        <label for="data_nascimento">data_nascimento</label>
        <input type="text" name="data_nascimento" id="data_nascimento" value="<?= htmlspecialchars($jogadores['data_nascimento'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="nacionalidade">nacionalidade</label>
        <input type="text" name="nacionalidade" id="nacionalidade" value="<?= htmlspecialchars($jogadores['nacionalidade'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="altura">altura</label>
        <input type="text" name="altura" id="altura" value="<?= htmlspecialchars($jogadores['altura'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="peso">peso</label>
        <input type="text" name="peso" id="peso" value="<?= htmlspecialchars($jogadores['peso'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="pe_dominante">pe_dominante</label>
        <input type="text" name="pe_dominante" id="pe_dominante" value="<?= htmlspecialchars($jogadores['pe_dominante'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="posicao">posicao</label>
        <input type="text" name="posicao" id="posicao" value="<?= htmlspecialchars($jogadores['posicao'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="time">time</label>
        <input type="text" name="time" id="time" value="<?= htmlspecialchars($jogadores['time'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="imagem">imagem</label>
        <input type="text" name="imagem" id="imagem" value="<?= htmlspecialchars($jogadores['imagem'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="criado_em">criado_em</label>
        <input type="text" name="criado_em" id="criado_em" value="<?= htmlspecialchars($jogadores['criado_em'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="nome_usuario">nome_usuario</label>
        <input type="text" name="nome_usuario" id="nome_usuario" value="<?= htmlspecialchars($jogadores['nome_usuario'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="senha">senha</label>
        <input type="text" name="senha" id="senha" value="<?= htmlspecialchars($jogadores['senha'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="perfil">perfil</label>
        <input type="text" name="perfil" id="perfil" value="<?= htmlspecialchars($jogadores['perfil'] ?? '') ?>" class="form-control" required>
    </div>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>