<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Jogadores</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/jogadoress/cadastrar" class="btn btn-primary">
            Novo Jogadores
        </a>
    </div>
</div>

<?php if (empty($jogadoress)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/jogadoress/cadastrar" class="btn btn-primary">
            Criar Primeiro Jogadores
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Data_nascimento</th>
                    <th>Nacionalidade</th>
                    <th>Altura</th>
                    <th>Peso</th>
                    <th>Pe_dominante</th>
                    <th>Posicao</th>
                    <th>Time</th>
                    <th>Imagem</th>
                    <th>Criado_em</th>
                    <th>Id</th>
                    <th>Nome_usuario</th>
                    <th>Senha</th>
                    <th>Perfil</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($jogadoress as $jogadores): ?>
                    <tr>
                        <td><?= htmlspecialchars($jogadores['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['data_nascimento'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['nacionalidade'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['altura'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['peso'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['pe_dominante'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['posicao'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['time'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['imagem'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['criado_em'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['nome_usuario'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['senha'] ?? '') ?></td>
                        <td><?= htmlspecialchars($jogadores['perfil'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/jogadoress/editar?id=<?= $jogadores['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/jogadoress/excluir?id=<?= $jogadores['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>