<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__recent;
use appepositories\Pma__recentRepository;

class Pma__recentController extends Controller {
    private Pma__recentRepository $repository;

    public function __construct() {
        $this->repository = new Pma__recentRepository();
    }

    public function index(): void {
        $data['pma__recents'] = $this->repository->listarTodos();
        $this->view('pma__recents/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__recents/create');
    }

    public function salvar(): void {
        $pma__recent = new Pma__recent();

        if ($this->repository->inserir($pma__recent)) {
            $this->redirect(URL_BASE . '/pma__recents');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__recent.';
            $this->view('pma__recents/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__recents');
        }

        $id = (int) $_GET['id'];
        $data['pma__recent'] = $this->repository->buscarPorId($id);

        if (!$data['pma__recent']) {
            $this->redirect(URL_BASE . '/pma__recents');
        }

        $this->view('pma__recents/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__recents');
        }

        $id = (int) $_POST['id'];
        $pma__recent = new Pma__recent();

        if ($this->repository->alterar($pma__recent, $id)) {
            $this->redirect(URL_BASE . '/pma__recents');
        } else {
            $this->redirect(URL_BASE . '/pma__recents/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__recents');
    }
}