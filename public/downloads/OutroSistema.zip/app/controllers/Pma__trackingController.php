<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__tracking;
use appepositories\Pma__trackingRepository;

class Pma__trackingController extends Controller {
    private Pma__trackingRepository $repository;

    public function __construct() {
        $this->repository = new Pma__trackingRepository();
    }

    public function index(): void {
        $data['pma__trackings'] = $this->repository->listarTodos();
        $this->view('pma__trackings/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__trackings/create');
    }

    public function salvar(): void {
        $pma__tracking = new Pma__tracking();

        if ($this->repository->inserir($pma__tracking)) {
            $this->redirect(URL_BASE . '/pma__trackings');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__tracking.';
            $this->view('pma__trackings/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__trackings');
        }

        $id = (int) $_GET['id'];
        $data['pma__tracking'] = $this->repository->buscarPorId($id);

        if (!$data['pma__tracking']) {
            $this->redirect(URL_BASE . '/pma__trackings');
        }

        $this->view('pma__trackings/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__trackings');
        }

        $id = (int) $_POST['id'];
        $pma__tracking = new Pma__tracking();

        if ($this->repository->alterar($pma__tracking, $id)) {
            $this->redirect(URL_BASE . '/pma__trackings');
        } else {
            $this->redirect(URL_BASE . '/pma__trackings/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__trackings');
    }
}