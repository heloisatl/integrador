<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__savedsearches;
use appepositories\Pma__savedsearchesRepository;

class Pma__savedsearchesController extends Controller {
    private Pma__savedsearchesRepository $repository;

    public function __construct() {
        $this->repository = new Pma__savedsearchesRepository();
    }

    public function index(): void {
        $data['pma__savedsearchess'] = $this->repository->listarTodos();
        $this->view('pma__savedsearchess/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__savedsearchess/create');
    }

    public function salvar(): void {
        $pma__savedsearches = new Pma__savedsearches();

        if ($this->repository->inserir($pma__savedsearches)) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__savedsearches.';
            $this->view('pma__savedsearchess/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        }

        $id = (int) $_GET['id'];
        $data['pma__savedsearches'] = $this->repository->buscarPorId($id);

        if (!$data['pma__savedsearches']) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        }

        $this->view('pma__savedsearchess/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        }

        $id = (int) $_POST['id'];
        $pma__savedsearches = new Pma__savedsearches();

        if ($this->repository->alterar($pma__savedsearches, $id)) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        } else {
            $this->redirect(URL_BASE . '/pma__savedsearchess/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__savedsearchess');
    }
}