<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__navigationhiding;
use appepositories\Pma__navigationhidingRepository;

class Pma__navigationhidingController extends Controller {
    private Pma__navigationhidingRepository $repository;

    public function __construct() {
        $this->repository = new Pma__navigationhidingRepository();
    }

    public function index(): void {
        $data['pma__navigationhidings'] = $this->repository->listarTodos();
        $this->view('pma__navigationhidings/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__navigationhidings/create');
    }

    public function salvar(): void {
        $pma__navigationhiding = new Pma__navigationhiding();

        if ($this->repository->inserir($pma__navigationhiding)) {
            $this->redirect(URL_BASE . '/pma__navigationhidings');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__navigationhiding.';
            $this->view('pma__navigationhidings/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__navigationhidings');
        }

        $id = (int) $_GET['id'];
        $data['pma__navigationhiding'] = $this->repository->buscarPorId($id);

        if (!$data['pma__navigationhiding']) {
            $this->redirect(URL_BASE . '/pma__navigationhidings');
        }

        $this->view('pma__navigationhidings/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__navigationhidings');
        }

        $id = (int) $_POST['id'];
        $pma__navigationhiding = new Pma__navigationhiding();

        if ($this->repository->alterar($pma__navigationhiding, $id)) {
            $this->redirect(URL_BASE . '/pma__navigationhidings');
        } else {
            $this->redirect(URL_BASE . '/pma__navigationhidings/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__navigationhidings');
    }
}