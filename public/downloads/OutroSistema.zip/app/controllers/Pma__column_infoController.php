<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__column_info;
use appepositories\Pma__column_infoRepository;

class Pma__column_infoController extends Controller {
    private Pma__column_infoRepository $repository;

    public function __construct() {
        $this->repository = new Pma__column_infoRepository();
    }

    public function index(): void {
        $data['pma__column_infos'] = $this->repository->listarTodos();
        $this->view('pma__column_infos/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__column_infos/create');
    }

    public function salvar(): void {
        $pma__column_info = new Pma__column_info();

        if ($this->repository->inserir($pma__column_info)) {
            $this->redirect(URL_BASE . '/pma__column_infos');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__column_info.';
            $this->view('pma__column_infos/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__column_infos');
        }

        $id = (int) $_GET['id'];
        $data['pma__column_info'] = $this->repository->buscarPorId($id);

        if (!$data['pma__column_info']) {
            $this->redirect(URL_BASE . '/pma__column_infos');
        }

        $this->view('pma__column_infos/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__column_infos');
        }

        $id = (int) $_POST['id'];
        $pma__column_info = new Pma__column_info();

        if ($this->repository->alterar($pma__column_info, $id)) {
            $this->redirect(URL_BASE . '/pma__column_infos');
        } else {
            $this->redirect(URL_BASE . '/pma__column_infos/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__column_infos');
    }
}