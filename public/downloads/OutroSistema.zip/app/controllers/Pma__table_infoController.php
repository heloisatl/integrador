<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__table_info;
use appepositories\Pma__table_infoRepository;

class Pma__table_infoController extends Controller {
    private Pma__table_infoRepository $repository;

    public function __construct() {
        $this->repository = new Pma__table_infoRepository();
    }

    public function index(): void {
        $data['pma__table_infos'] = $this->repository->listarTodos();
        $this->view('pma__table_infos/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__table_infos/create');
    }

    public function salvar(): void {
        $pma__table_info = new Pma__table_info();

        if ($this->repository->inserir($pma__table_info)) {
            $this->redirect(URL_BASE . '/pma__table_infos');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__table_info.';
            $this->view('pma__table_infos/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__table_infos');
        }

        $id = (int) $_GET['id'];
        $data['pma__table_info'] = $this->repository->buscarPorId($id);

        if (!$data['pma__table_info']) {
            $this->redirect(URL_BASE . '/pma__table_infos');
        }

        $this->view('pma__table_infos/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__table_infos');
        }

        $id = (int) $_POST['id'];
        $pma__table_info = new Pma__table_info();

        if ($this->repository->alterar($pma__table_info, $id)) {
            $this->redirect(URL_BASE . '/pma__table_infos');
        } else {
            $this->redirect(URL_BASE . '/pma__table_infos/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__table_infos');
    }
}