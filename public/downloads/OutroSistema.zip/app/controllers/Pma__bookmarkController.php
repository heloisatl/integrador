<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__bookmark;
use appepositories\Pma__bookmarkRepository;

class Pma__bookmarkController extends Controller {
    private Pma__bookmarkRepository $repository;

    public function __construct() {
        $this->repository = new Pma__bookmarkRepository();
    }

    public function index(): void {
        $data['pma__bookmarks'] = $this->repository->listarTodos();
        $this->view('pma__bookmarks/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__bookmarks/create');
    }

    public function salvar(): void {
        $pma__bookmark = new Pma__bookmark();

        if ($this->repository->inserir($pma__bookmark)) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__bookmark.';
            $this->view('pma__bookmarks/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        }

        $id = (int) $_GET['id'];
        $data['pma__bookmark'] = $this->repository->buscarPorId($id);

        if (!$data['pma__bookmark']) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        }

        $this->view('pma__bookmarks/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        }

        $id = (int) $_POST['id'];
        $pma__bookmark = new Pma__bookmark();

        if ($this->repository->alterar($pma__bookmark, $id)) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        } else {
            $this->redirect(URL_BASE . '/pma__bookmarks/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__bookmarks');
    }
}