<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__central_columns;
use appepositories\Pma__central_columnsRepository;

class Pma__central_columnsController extends Controller {
    private Pma__central_columnsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__central_columnsRepository();
    }

    public function index(): void {
        $data['pma__central_columnss'] = $this->repository->listarTodos();
        $this->view('pma__central_columnss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__central_columnss/create');
    }

    public function salvar(): void {
        $pma__central_columns = new Pma__central_columns();

        if ($this->repository->inserir($pma__central_columns)) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__central_columns.';
            $this->view('pma__central_columnss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        }

        $id = (int) $_GET['id'];
        $data['pma__central_columns'] = $this->repository->buscarPorId($id);

        if (!$data['pma__central_columns']) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        }

        $this->view('pma__central_columnss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        }

        $id = (int) $_POST['id'];
        $pma__central_columns = new Pma__central_columns();

        if ($this->repository->alterar($pma__central_columns, $id)) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        } else {
            $this->redirect(URL_BASE . '/pma__central_columnss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__central_columnss');
    }
}