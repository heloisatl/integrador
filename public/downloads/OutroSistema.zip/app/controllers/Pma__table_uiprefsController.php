<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__table_uiprefs;
use appepositories\Pma__table_uiprefsRepository;

class Pma__table_uiprefsController extends Controller {
    private Pma__table_uiprefsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__table_uiprefsRepository();
    }

    public function index(): void {
        $data['pma__table_uiprefss'] = $this->repository->listarTodos();
        $this->view('pma__table_uiprefss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__table_uiprefss/create');
    }

    public function salvar(): void {
        $pma__table_uiprefs = new Pma__table_uiprefs();

        if ($this->repository->inserir($pma__table_uiprefs)) {
            $this->redirect(URL_BASE . '/pma__table_uiprefss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__table_uiprefs.';
            $this->view('pma__table_uiprefss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__table_uiprefss');
        }

        $id = (int) $_GET['id'];
        $data['pma__table_uiprefs'] = $this->repository->buscarPorId($id);

        if (!$data['pma__table_uiprefs']) {
            $this->redirect(URL_BASE . '/pma__table_uiprefss');
        }

        $this->view('pma__table_uiprefss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__table_uiprefss');
        }

        $id = (int) $_POST['id'];
        $pma__table_uiprefs = new Pma__table_uiprefs();

        if ($this->repository->alterar($pma__table_uiprefs, $id)) {
            $this->redirect(URL_BASE . '/pma__table_uiprefss');
        } else {
            $this->redirect(URL_BASE . '/pma__table_uiprefss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__table_uiprefss');
    }
}