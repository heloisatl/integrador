<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__history;
use appepositories\Pma__historyRepository;

class Pma__historyController extends Controller {
    private Pma__historyRepository $repository;

    public function __construct() {
        $this->repository = new Pma__historyRepository();
    }

    public function index(): void {
        $data['pma__historys'] = $this->repository->listarTodos();
        $this->view('pma__historys/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__historys/create');
    }

    public function salvar(): void {
        $pma__history = new Pma__history();

        if ($this->repository->inserir($pma__history)) {
            $this->redirect(URL_BASE . '/pma__historys');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__history.';
            $this->view('pma__historys/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__historys');
        }

        $id = (int) $_GET['id'];
        $data['pma__history'] = $this->repository->buscarPorId($id);

        if (!$data['pma__history']) {
            $this->redirect(URL_BASE . '/pma__historys');
        }

        $this->view('pma__historys/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__historys');
        }

        $id = (int) $_POST['id'];
        $pma__history = new Pma__history();

        if ($this->repository->alterar($pma__history, $id)) {
            $this->redirect(URL_BASE . '/pma__historys');
        } else {
            $this->redirect(URL_BASE . '/pma__historys/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__historys');
    }
}