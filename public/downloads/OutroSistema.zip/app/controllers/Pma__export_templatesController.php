<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__export_templates;
use appepositories\Pma__export_templatesRepository;

class Pma__export_templatesController extends Controller {
    private Pma__export_templatesRepository $repository;

    public function __construct() {
        $this->repository = new Pma__export_templatesRepository();
    }

    public function index(): void {
        $data['pma__export_templatess'] = $this->repository->listarTodos();
        $this->view('pma__export_templatess/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__export_templatess/create');
    }

    public function salvar(): void {
        $pma__export_templates = new Pma__export_templates();

        if ($this->repository->inserir($pma__export_templates)) {
            $this->redirect(URL_BASE . '/pma__export_templatess');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__export_templates.';
            $this->view('pma__export_templatess/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__export_templatess');
        }

        $id = (int) $_GET['id'];
        $data['pma__export_templates'] = $this->repository->buscarPorId($id);

        if (!$data['pma__export_templates']) {
            $this->redirect(URL_BASE . '/pma__export_templatess');
        }

        $this->view('pma__export_templatess/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__export_templatess');
        }

        $id = (int) $_POST['id'];
        $pma__export_templates = new Pma__export_templates();

        if ($this->repository->alterar($pma__export_templates, $id)) {
            $this->redirect(URL_BASE . '/pma__export_templatess');
        } else {
            $this->redirect(URL_BASE . '/pma__export_templatess/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__export_templatess');
    }
}