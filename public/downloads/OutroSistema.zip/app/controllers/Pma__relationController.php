<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__relation;
use appepositories\Pma__relationRepository;

class Pma__relationController extends Controller {
    private Pma__relationRepository $repository;

    public function __construct() {
        $this->repository = new Pma__relationRepository();
    }

    public function index(): void {
        $data['pma__relations'] = $this->repository->listarTodos();
        $this->view('pma__relations/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__relations/create');
    }

    public function salvar(): void {
        $pma__relation = new Pma__relation();

        if ($this->repository->inserir($pma__relation)) {
            $this->redirect(URL_BASE . '/pma__relations');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__relation.';
            $this->view('pma__relations/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__relations');
        }

        $id = (int) $_GET['id'];
        $data['pma__relation'] = $this->repository->buscarPorId($id);

        if (!$data['pma__relation']) {
            $this->redirect(URL_BASE . '/pma__relations');
        }

        $this->view('pma__relations/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__relations');
        }

        $id = (int) $_POST['id'];
        $pma__relation = new Pma__relation();

        if ($this->repository->alterar($pma__relation, $id)) {
            $this->redirect(URL_BASE . '/pma__relations');
        } else {
            $this->redirect(URL_BASE . '/pma__relations/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__relations');
    }
}