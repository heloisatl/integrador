<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__designer_settings;
use appepositories\Pma__designer_settingsRepository;

class Pma__designer_settingsController extends Controller {
    private Pma__designer_settingsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__designer_settingsRepository();
    }

    public function index(): void {
        $data['pma__designer_settingss'] = $this->repository->listarTodos();
        $this->view('pma__designer_settingss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__designer_settingss/create');
    }

    public function salvar(): void {
        $pma__designer_settings = new Pma__designer_settings();

        if ($this->repository->inserir($pma__designer_settings)) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__designer_settings.';
            $this->view('pma__designer_settingss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        }

        $id = (int) $_GET['id'];
        $data['pma__designer_settings'] = $this->repository->buscarPorId($id);

        if (!$data['pma__designer_settings']) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        }

        $this->view('pma__designer_settingss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        }

        $id = (int) $_POST['id'];
        $pma__designer_settings = new Pma__designer_settings();

        if ($this->repository->alterar($pma__designer_settings, $id)) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        } else {
            $this->redirect(URL_BASE . '/pma__designer_settingss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__designer_settingss');
    }
}