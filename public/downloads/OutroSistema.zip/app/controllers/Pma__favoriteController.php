<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__favorite;
use appepositories\Pma__favoriteRepository;

class Pma__favoriteController extends Controller {
    private Pma__favoriteRepository $repository;

    public function __construct() {
        $this->repository = new Pma__favoriteRepository();
    }

    public function index(): void {
        $data['pma__favorites'] = $this->repository->listarTodos();
        $this->view('pma__favorites/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__favorites/create');
    }

    public function salvar(): void {
        $pma__favorite = new Pma__favorite();

        if ($this->repository->inserir($pma__favorite)) {
            $this->redirect(URL_BASE . '/pma__favorites');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__favorite.';
            $this->view('pma__favorites/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__favorites');
        }

        $id = (int) $_GET['id'];
        $data['pma__favorite'] = $this->repository->buscarPorId($id);

        if (!$data['pma__favorite']) {
            $this->redirect(URL_BASE . '/pma__favorites');
        }

        $this->view('pma__favorites/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__favorites');
        }

        $id = (int) $_POST['id'];
        $pma__favorite = new Pma__favorite();

        if ($this->repository->alterar($pma__favorite, $id)) {
            $this->redirect(URL_BASE . '/pma__favorites');
        } else {
            $this->redirect(URL_BASE . '/pma__favorites/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__favorites');
    }
}