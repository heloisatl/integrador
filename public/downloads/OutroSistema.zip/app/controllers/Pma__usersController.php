<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__users;
use appepositories\Pma__usersRepository;

class Pma__usersController extends Controller {
    private Pma__usersRepository $repository;

    public function __construct() {
        $this->repository = new Pma__usersRepository();
    }

    public function index(): void {
        $data['pma__userss'] = $this->repository->listarTodos();
        $this->view('pma__userss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__userss/create');
    }

    public function salvar(): void {
        $pma__users = new Pma__users();

        if ($this->repository->inserir($pma__users)) {
            $this->redirect(URL_BASE . '/pma__userss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__users.';
            $this->view('pma__userss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__userss');
        }

        $id = (int) $_GET['id'];
        $data['pma__users'] = $this->repository->buscarPorId($id);

        if (!$data['pma__users']) {
            $this->redirect(URL_BASE . '/pma__userss');
        }

        $this->view('pma__userss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__userss');
        }

        $id = (int) $_POST['id'];
        $pma__users = new Pma__users();

        if ($this->repository->alterar($pma__users, $id)) {
            $this->redirect(URL_BASE . '/pma__userss');
        } else {
            $this->redirect(URL_BASE . '/pma__userss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__userss');
    }
}