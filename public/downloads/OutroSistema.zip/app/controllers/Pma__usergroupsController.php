<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__usergroups;
use appepositories\Pma__usergroupsRepository;

class Pma__usergroupsController extends Controller {
    private Pma__usergroupsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__usergroupsRepository();
    }

    public function index(): void {
        $data['pma__usergroupss'] = $this->repository->listarTodos();
        $this->view('pma__usergroupss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__usergroupss/create');
    }

    public function salvar(): void {
        $pma__usergroups = new Pma__usergroups();

        if ($this->repository->inserir($pma__usergroups)) {
            $this->redirect(URL_BASE . '/pma__usergroupss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__usergroups.';
            $this->view('pma__usergroupss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__usergroupss');
        }

        $id = (int) $_GET['id'];
        $data['pma__usergroups'] = $this->repository->buscarPorId($id);

        if (!$data['pma__usergroups']) {
            $this->redirect(URL_BASE . '/pma__usergroupss');
        }

        $this->view('pma__usergroupss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__usergroupss');
        }

        $id = (int) $_POST['id'];
        $pma__usergroups = new Pma__usergroups();

        if ($this->repository->alterar($pma__usergroups, $id)) {
            $this->redirect(URL_BASE . '/pma__usergroupss');
        } else {
            $this->redirect(URL_BASE . '/pma__usergroupss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__usergroupss');
    }
}