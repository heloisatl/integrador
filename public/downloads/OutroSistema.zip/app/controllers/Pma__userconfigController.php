<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__userconfig;
use appepositories\Pma__userconfigRepository;

class Pma__userconfigController extends Controller {
    private Pma__userconfigRepository $repository;

    public function __construct() {
        $this->repository = new Pma__userconfigRepository();
    }

    public function index(): void {
        $data['pma__userconfigs'] = $this->repository->listarTodos();
        $this->view('pma__userconfigs/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__userconfigs/create');
    }

    public function salvar(): void {
        $pma__userconfig = new Pma__userconfig();

        if ($this->repository->inserir($pma__userconfig)) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__userconfig.';
            $this->view('pma__userconfigs/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        }

        $id = (int) $_GET['id'];
        $data['pma__userconfig'] = $this->repository->buscarPorId($id);

        if (!$data['pma__userconfig']) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        }

        $this->view('pma__userconfigs/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        }

        $id = (int) $_POST['id'];
        $pma__userconfig = new Pma__userconfig();

        if ($this->repository->alterar($pma__userconfig, $id)) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        } else {
            $this->redirect(URL_BASE . '/pma__userconfigs/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__userconfigs');
    }
}