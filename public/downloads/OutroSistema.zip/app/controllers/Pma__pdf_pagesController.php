<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__pdf_pages;
use appepositories\Pma__pdf_pagesRepository;

class Pma__pdf_pagesController extends Controller {
    private Pma__pdf_pagesRepository $repository;

    public function __construct() {
        $this->repository = new Pma__pdf_pagesRepository();
    }

    public function index(): void {
        $data['pma__pdf_pagess'] = $this->repository->listarTodos();
        $this->view('pma__pdf_pagess/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__pdf_pagess/create');
    }

    public function salvar(): void {
        $pma__pdf_pages = new Pma__pdf_pages();

        if ($this->repository->inserir($pma__pdf_pages)) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__pdf_pages.';
            $this->view('pma__pdf_pagess/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        }

        $id = (int) $_GET['id'];
        $data['pma__pdf_pages'] = $this->repository->buscarPorId($id);

        if (!$data['pma__pdf_pages']) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        }

        $this->view('pma__pdf_pagess/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        }

        $id = (int) $_POST['id'];
        $pma__pdf_pages = new Pma__pdf_pages();

        if ($this->repository->alterar($pma__pdf_pages, $id)) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        } else {
            $this->redirect(URL_BASE . '/pma__pdf_pagess/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__pdf_pagess');
    }
}