<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__table_coords;
use appepositories\Pma__table_coordsRepository;

class Pma__table_coordsController extends Controller {
    private Pma__table_coordsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__table_coordsRepository();
    }

    public function index(): void {
        $data['pma__table_coordss'] = $this->repository->listarTodos();
        $this->view('pma__table_coordss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__table_coordss/create');
    }

    public function salvar(): void {
        $pma__table_coords = new Pma__table_coords();

        if ($this->repository->inserir($pma__table_coords)) {
            $this->redirect(URL_BASE . '/pma__table_coordss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__table_coords.';
            $this->view('pma__table_coordss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__table_coordss');
        }

        $id = (int) $_GET['id'];
        $data['pma__table_coords'] = $this->repository->buscarPorId($id);

        if (!$data['pma__table_coords']) {
            $this->redirect(URL_BASE . '/pma__table_coordss');
        }

        $this->view('pma__table_coordss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__table_coordss');
        }

        $id = (int) $_POST['id'];
        $pma__table_coords = new Pma__table_coords();

        if ($this->repository->alterar($pma__table_coords, $id)) {
            $this->redirect(URL_BASE . '/pma__table_coordss');
        } else {
            $this->redirect(URL_BASE . '/pma__table_coordss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__table_coordss');
    }
}