<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__users</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__userss/cadastrar" class="btn btn-primary">
            Novo Pma__users
        </a>
    </div>
</div>

<?php if (empty($pma__userss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__userss/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__users
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__userss as $pma__users): ?>
                    <tr>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__userss/editar?id=<?= $pma__users['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__userss/excluir?id=<?= $pma__users['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>