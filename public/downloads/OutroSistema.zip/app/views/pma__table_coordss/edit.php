<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Editar Pma__table_coords</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__table_coordss" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__table_coordss/atualizar" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__table_coords['id'] ?? '') ?>">

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>