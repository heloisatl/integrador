<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__export_templates</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__export_templatess/cadastrar" class="btn btn-primary">
            Novo Pma__export_templates
        </a>
    </div>
</div>

<?php if (empty($pma__export_templatess)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__export_templatess/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__export_templates
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__export_templatess as $pma__export_templates): ?>
                    <tr>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__export_templatess/editar?id=<?= $pma__export_templates['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__export_templatess/excluir?id=<?= $pma__export_templates['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>