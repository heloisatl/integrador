<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__export_templates</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__export_templatess" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__export_templatess/salvar" method="POST">

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>