<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__history</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__historys/cadastrar" class="btn btn-primary">
            Novo Pma__history
        </a>
    </div>
</div>

<?php if (empty($pma__historys)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__historys/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__history
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__historys as $pma__history): ?>
                    <tr>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__historys/editar?id=<?= $pma__history['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__historys/excluir?id=<?= $pma__history['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>