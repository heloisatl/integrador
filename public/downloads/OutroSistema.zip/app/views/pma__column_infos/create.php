<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__column_info</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__column_infos" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__column_infos/salvar" method="POST">

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>