<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__column_info</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__column_infos/cadastrar" class="btn btn-primary">
            Novo Pma__column_info
        </a>
    </div>
</div>

<?php if (empty($pma__column_infos)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__column_infos/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__column_info
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__column_infos as $pma__column_info): ?>
                    <tr>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__column_infos/editar?id=<?= $pma__column_info['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__column_infos/excluir?id=<?= $pma__column_info['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>