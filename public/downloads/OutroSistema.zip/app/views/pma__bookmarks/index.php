<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__bookmark</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__bookmarks/cadastrar" class="btn btn-primary">
            Novo Pma__bookmark
        </a>
    </div>
</div>

<?php if (empty($pma__bookmarks)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__bookmarks/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__bookmark
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__bookmarks as $pma__bookmark): ?>
                    <tr>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__bookmarks/editar?id=<?= $pma__bookmark['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__bookmarks/excluir?id=<?= $pma__bookmark['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>