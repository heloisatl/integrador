<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__navigationhiding</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__navigationhidings" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__navigationhidings/salvar" method="POST">

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>