<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Pma__table_info;
use PDO;

class Pma__table_infoRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Pma__table_info $obj): bool {
        $sql = "INSERT INTO pma__table_info () VALUES ()";
        $stmt = $this->con->prepare($sql);

        return $stmt->execute([]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__table_info";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__table_info WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Pma__table_info $obj, int $id): bool {

        $sql = "UPDATE pma__table_info SET  WHERE id = ?";
        $params = [, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__table_info WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}