<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Pma__designer_settings;
use PDO;

class Pma__designer_settingsRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Pma__designer_settings $obj): bool {
        $sql = "INSERT INTO pma__designer_settings () VALUES ()";
        $stmt = $this->con->prepare($sql);

        return $stmt->execute([]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__designer_settings";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__designer_settings WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Pma__designer_settings $obj, int $id): bool {

        $sql = "UPDATE pma__designer_settings SET  WHERE id = ?";
        $params = [, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__designer_settings WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}