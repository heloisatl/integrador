<?php

namespace app\models;

class Pma__table_coords {

}