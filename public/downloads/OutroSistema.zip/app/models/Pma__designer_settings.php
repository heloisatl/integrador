<?php

namespace app\models;

class Pma__designer_settings {

}