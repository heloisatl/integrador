<?php

namespace app\models;

class Pma__central_columns {

}