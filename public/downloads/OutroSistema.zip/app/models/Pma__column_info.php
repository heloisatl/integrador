<?php

namespace app\models;

class Pma__column_info {

}