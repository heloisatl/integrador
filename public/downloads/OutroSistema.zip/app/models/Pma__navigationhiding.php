<?php

namespace app\models;

class Pma__navigationhiding {

}