<?php

namespace app\models;

class Pma__favorite {

}