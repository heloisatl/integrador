<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pokemons</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pokemonss/cadastrar" class="btn btn-primary">
            Novo Pokemons
        </a>
    </div>
</div>

<?php if (empty($pokemonss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pokemonss/cadastrar" class="btn btn-primary">
            Criar Primeiro Pokemons
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>Peso</th>
                    <th>Altura</th>
                    <th>Imagem</th>
                    <th>Cor</th>
                    <th>Id_regiao</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pokemonss as $pokemons): ?>
                    <tr>
                        <td><?= htmlspecialchars($pokemons['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pokemons['nome'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pokemons['peso'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pokemons['altura'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pokemons['imagem'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pokemons['cor'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pokemons['id_regiao'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pokemonss/editar?id=<?= $pokemons['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pokemonss/excluir?id=<?= $pokemons['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>