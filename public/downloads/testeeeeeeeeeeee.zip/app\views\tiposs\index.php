<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Tipos</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/tiposs/cadastrar" class="btn btn-primary">
            Novo Tipos
        </a>
    </div>
</div>

<?php if (empty($tiposs)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/tiposs/cadastrar" class="btn btn-primary">
            Criar Primeiro Tipos
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tiposs as $tipos): ?>
                    <tr>
                        <td><?= htmlspecialchars($tipos['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($tipos['nome'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/tiposs/editar?id=<?= $tipos['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/tiposs/excluir?id=<?= $tipos['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>