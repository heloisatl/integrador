<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pokemon_tipos;
use appepositories\Pokemon_tiposRepository;

class Pokemon_tiposController extends Controller {
    private Pokemon_tiposRepository $repository;

    public function __construct() {
        $this->repository = new Pokemon_tiposRepository();
    }

    public function index(): void {
        $data['pokemon_tiposs'] = $this->repository->listarTodos();
        $this->view('pokemon_tiposs/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pokemon_tiposs/create');
    }

    public function salvar(): void {
        $pokemon_tipos = new Pokemon_tipos();
        $pokemon_tipos->setId_pokemon($_POST['id_pokemon'] ?? '');
        $pokemon_tipos->setId_tipo($_POST['id_tipo'] ?? '');

        if ($this->repository->inserir($pokemon_tipos)) {
            $this->redirect(URL_BASE . '/pokemon_tiposs');
        } else {
            $data['erro'] = 'Erro ao cadastrar pokemon_tipos.';
            $this->view('pokemon_tiposs/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pokemon_tiposs');
        }

        $id = (int) $_GET['id'];
        $data['pokemon_tipos'] = $this->repository->buscarPorId($id);

        if (!$data['pokemon_tipos']) {
            $this->redirect(URL_BASE . '/pokemon_tiposs');
        }

        $this->view('pokemon_tiposs/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pokemon_tiposs');
        }

        $id = (int) $_POST['id'];
        $pokemon_tipos = new Pokemon_tipos();
        $pokemon_tipos->setId_pokemon($_POST['id_pokemon'] ?? '');
        $pokemon_tipos->setId_tipo($_POST['id_tipo'] ?? '');

        if ($this->repository->alterar($pokemon_tipos, $id)) {
            $this->redirect(URL_BASE . '/pokemon_tiposs');
        } else {
            $this->redirect(URL_BASE . '/pokemon_tiposs/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pokemon_tiposs');
    }
}