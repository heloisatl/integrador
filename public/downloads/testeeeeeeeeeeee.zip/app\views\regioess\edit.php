<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Editar Regioes</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/regioess" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/regioess/atualizar" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($regioes['id'] ?? '') ?>">
    <div class="form-group">
        <label for="nome">Nome</label>
        <input type="text" name="nome" id="nome" value="<?= htmlspecialchars($regioes['nome'] ?? '') ?>" class="form-control" required>
    </div>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>