<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Cadastrar Pokemon_tipos</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pokemon_tiposs" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pokemon_tiposs/salvar" method="POST">
    <div class="form-group">
        <label for="id_pokemon">Id_pokemon</label>
        <input type="text" name="id_pokemon" id="id_pokemon" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="id_tipo">Id_tipo</label>
        <input type="text" name="id_tipo" id="id_tipo" class="form-control" required>
    </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>