<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Cadastrar Pokemons</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pokemonss" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pokemonss/salvar" method="POST">
    <div class="form-group">
        <label for="nome">Nome</label>
        <input type="text" name="nome" id="nome" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="peso">Peso</label>
        <input type="text" name="peso" id="peso" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="altura">Altura</label>
        <input type="text" name="altura" id="altura" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="imagem">Imagem</label>
        <input type="text" name="imagem" id="imagem" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="cor">Cor</label>
        <input type="text" name="cor" id="cor" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="id_regiao">Id_regiao</label>
        <input type="text" name="id_regiao" id="id_regiao" class="form-control" required>
    </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>