<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Regioes;
use PDO;

class RegioesRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Regioes $obj): bool {
        $sql = "INSERT INTO regioes (nome) VALUES (?)";
        $stmt = $this->con->prepare($sql);
        $nome = $obj->getNome();

        return $stmt->execute([$nome]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM regioes";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM regioes WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Regioes $obj, int $id): bool {
        $nome = $obj->getNome();

        $sql = "UPDATE regioes SET nome = ? WHERE id = ?";
        $params = [$nome, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM regioes WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}