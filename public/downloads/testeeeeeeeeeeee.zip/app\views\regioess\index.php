<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Regioes</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/regioess/cadastrar" class="btn btn-primary">
            Novo Regioes
        </a>
    </div>
</div>

<?php if (empty($regioess)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/regioess/cadastrar" class="btn btn-primary">
            Criar Primeiro Regioes
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($regioess as $regioes): ?>
                    <tr>
                        <td><?= htmlspecialchars($regioes['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($regioes['nome'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/regioess/editar?id=<?= $regioes['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/regioess/excluir?id=<?= $regioes['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>