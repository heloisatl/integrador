<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Pokemons;
use PDO;

class PokemonsRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Pokemons $obj): bool {
        $sql = "INSERT INTO pokemons (nome, peso, altura, imagem, cor, id_regiao) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $nome = $obj->getNome();
        $peso = $obj->getPeso();
        $altura = $obj->getAltura();
        $imagem = $obj->getImagem();
        $cor = $obj->getCor();
        $id_regiao = $obj->getId_regiao();

        return $stmt->execute([$nome, $peso, $altura, $imagem, $cor, $id_regiao]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM pokemons";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pokemons WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Pokemons $obj, int $id): bool {
        $nome = $obj->getNome();
        $peso = $obj->getPeso();
        $altura = $obj->getAltura();
        $imagem = $obj->getImagem();
        $cor = $obj->getCor();
        $id_regiao = $obj->getId_regiao();

        $sql = "UPDATE pokemons SET nome = ?, peso = ?, altura = ?, imagem = ?, cor = ?, id_regiao = ? WHERE id = ?";
        $params = [$nome, $peso, $altura, $imagem, $cor, $id_regiao, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM pokemons WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}