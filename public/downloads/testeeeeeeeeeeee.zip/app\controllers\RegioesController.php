<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Regioes;
use appepositories\RegioesRepository;

class RegioesController extends Controller {
    private RegioesRepository $repository;

    public function __construct() {
        $this->repository = new RegioesRepository();
    }

    public function index(): void {
        $data['regioess'] = $this->repository->listarTodos();
        $this->view('regioess/index', $data);
    }

    public function cadastrar(): void {
        $this->view('regioess/create');
    }

    public function salvar(): void {
        $regioes = new Regioes();
        $regioes->setNome($_POST['nome'] ?? '');

        if ($this->repository->inserir($regioes)) {
            $this->redirect(URL_BASE . '/regioess');
        } else {
            $data['erro'] = 'Erro ao cadastrar regioes.';
            $this->view('regioess/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/regioess');
        }

        $id = (int) $_GET['id'];
        $data['regioes'] = $this->repository->buscarPorId($id);

        if (!$data['regioes']) {
            $this->redirect(URL_BASE . '/regioess');
        }

        $this->view('regioess/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/regioess');
        }

        $id = (int) $_POST['id'];
        $regioes = new Regioes();
        $regioes->setNome($_POST['nome'] ?? '');

        if ($this->repository->alterar($regioes, $id)) {
            $this->redirect(URL_BASE . '/regioess');
        } else {
            $this->redirect(URL_BASE . '/regioess/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/regioess');
    }
}