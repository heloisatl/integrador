<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Pokemon_tipos;
use PDO;

class Pokemon_tiposRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Pokemon_tipos $obj): bool {
        $sql = "INSERT INTO pokemon_tipos (id_pokemon, id_tipo) VALUES (?, ?)";
        $stmt = $this->con->prepare($sql);
        $id_pokemon = $obj->getId_pokemon();
        $id_tipo = $obj->getId_tipo();

        return $stmt->execute([$id_pokemon, $id_tipo]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM pokemon_tipos";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pokemon_tipos WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Pokemon_tipos $obj, int $id): bool {
        $id_pokemon = $obj->getId_pokemon();
        $id_tipo = $obj->getId_tipo();

        $sql = "UPDATE pokemon_tipos SET id_pokemon = ?, id_tipo = ? WHERE id = ?";
        $params = [$id_pokemon, $id_tipo, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM pokemon_tipos WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}