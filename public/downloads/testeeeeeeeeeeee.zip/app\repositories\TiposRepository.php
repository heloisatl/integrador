<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Tipos;
use PDO;

class TiposRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Tipos $obj): bool {
        $sql = "INSERT INTO tipos (nome) VALUES (?)";
        $stmt = $this->con->prepare($sql);
        $nome = $obj->getNome();

        return $stmt->execute([$nome]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM tipos";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM tipos WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Tipos $obj, int $id): bool {
        $nome = $obj->getNome();

        $sql = "UPDATE tipos SET nome = ? WHERE id = ?";
        $params = [$nome, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM tipos WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}