<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pokemons;
use appepositories\PokemonsRepository;

class PokemonsController extends Controller {
    private PokemonsRepository $repository;

    public function __construct() {
        $this->repository = new PokemonsRepository();
    }

    public function index(): void {
        $data['pokemonss'] = $this->repository->listarTodos();
        $this->view('pokemonss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pokemonss/create');
    }

    public function salvar(): void {
        $pokemons = new Pokemons();
        $pokemons->setNome($_POST['nome'] ?? '');
        $pokemons->setPeso($_POST['peso'] ?? '');
        $pokemons->setAltura($_POST['altura'] ?? '');
        $pokemons->setImagem($_POST['imagem'] ?? '');
        $pokemons->setCor($_POST['cor'] ?? '');
        $pokemons->setId_regiao($_POST['id_regiao'] ?? '');

        if ($this->repository->inserir($pokemons)) {
            $this->redirect(URL_BASE . '/pokemonss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pokemons.';
            $this->view('pokemonss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pokemonss');
        }

        $id = (int) $_GET['id'];
        $data['pokemons'] = $this->repository->buscarPorId($id);

        if (!$data['pokemons']) {
            $this->redirect(URL_BASE . '/pokemonss');
        }

        $this->view('pokemonss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pokemonss');
        }

        $id = (int) $_POST['id'];
        $pokemons = new Pokemons();
        $pokemons->setNome($_POST['nome'] ?? '');
        $pokemons->setPeso($_POST['peso'] ?? '');
        $pokemons->setAltura($_POST['altura'] ?? '');
        $pokemons->setImagem($_POST['imagem'] ?? '');
        $pokemons->setCor($_POST['cor'] ?? '');
        $pokemons->setId_regiao($_POST['id_regiao'] ?? '');

        if ($this->repository->alterar($pokemons, $id)) {
            $this->redirect(URL_BASE . '/pokemonss');
        } else {
            $this->redirect(URL_BASE . '/pokemonss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pokemonss');
    }
}