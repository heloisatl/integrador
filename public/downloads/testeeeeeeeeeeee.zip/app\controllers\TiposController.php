<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Tipos;
use appepositories\TiposRepository;

class TiposController extends Controller {
    private TiposRepository $repository;

    public function __construct() {
        $this->repository = new TiposRepository();
    }

    public function index(): void {
        $data['tiposs'] = $this->repository->listarTodos();
        $this->view('tiposs/index', $data);
    }

    public function cadastrar(): void {
        $this->view('tiposs/create');
    }

    public function salvar(): void {
        $tipos = new Tipos();
        $tipos->setNome($_POST['nome'] ?? '');

        if ($this->repository->inserir($tipos)) {
            $this->redirect(URL_BASE . '/tiposs');
        } else {
            $data['erro'] = 'Erro ao cadastrar tipos.';
            $this->view('tiposs/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/tiposs');
        }

        $id = (int) $_GET['id'];
        $data['tipos'] = $this->repository->buscarPorId($id);

        if (!$data['tipos']) {
            $this->redirect(URL_BASE . '/tiposs');
        }

        $this->view('tiposs/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/tiposs');
        }

        $id = (int) $_POST['id'];
        $tipos = new Tipos();
        $tipos->setNome($_POST['nome'] ?? '');

        if ($this->repository->alterar($tipos, $id)) {
            $this->redirect(URL_BASE . '/tiposs');
        } else {
            $this->redirect(URL_BASE . '/tiposs/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/tiposs');
    }
}