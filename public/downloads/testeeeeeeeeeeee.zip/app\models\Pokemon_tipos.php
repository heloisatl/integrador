<?php

namespace app\models;

class Pokemon_tipos {
    private $id;
    private $id_pokemon;
    private $id_tipo;

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getId_pokemon() {
        return $this->id_pokemon;
    }

    public function setId_pokemon($id_pokemon) {
        $this->id_pokemon = $id_pokemon;
    }

    public function getId_tipo() {
        return $this->id_tipo;
    }

    public function setId_tipo($id_tipo) {
        $this->id_tipo = $id_tipo;
    }

}