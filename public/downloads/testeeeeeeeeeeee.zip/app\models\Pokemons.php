<?php

namespace app\models;

class Pokemons {
    private $id;
    private $nome;
    private $peso;
    private $altura;
    private $imagem;
    private $cor;
    private $id_regiao;

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getNome() {
        return $this->nome;
    }

    public function setNome($nome) {
        $this->nome = $nome;
    }

    public function getPeso() {
        return $this->peso;
    }

    public function setPeso($peso) {
        $this->peso = $peso;
    }

    public function getAltura() {
        return $this->altura;
    }

    public function setAltura($altura) {
        $this->altura = $altura;
    }

    public function getImagem() {
        return $this->imagem;
    }

    public function setImagem($imagem) {
        $this->imagem = $imagem;
    }

    public function getCor() {
        return $this->cor;
    }

    public function setCor($cor) {
        $this->cor = $cor;
    }

    public function getId_regiao() {
        return $this->id_regiao;
    }

    public function setId_regiao($id_regiao) {
        $this->id_regiao = $id_regiao;
    }

}