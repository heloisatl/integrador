<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Cadastrar Tipos</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/tiposs" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/tiposs/salvar" method="POST">
    <div class="form-group">
        <label for="nome">Nome</label>
        <input type="text" name="nome" id="nome" class="form-control" required>
    </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>