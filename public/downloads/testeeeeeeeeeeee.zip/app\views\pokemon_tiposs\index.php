<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pokemon_tipos</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pokemon_tiposs/cadastrar" class="btn btn-primary">
            Novo Pokemon_tipos
        </a>
    </div>
</div>

<?php if (empty($pokemon_tiposs)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pokemon_tiposs/cadastrar" class="btn btn-primary">
            Criar Primeiro Pokemon_tipos
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Id_pokemon</th>
                    <th>Id_tipo</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pokemon_tiposs as $pokemon_tipos): ?>
                    <tr>
                        <td><?= htmlspecialchars($pokemon_tipos['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pokemon_tipos['id_pokemon'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pokemon_tipos['id_tipo'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pokemon_tiposs/editar?id=<?= $pokemon_tipos['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pokemon_tiposs/excluir?id=<?= $pokemon_tipos['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>