<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Editar Mobs</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/mobss" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/mobss/atualizar" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($mobs['id'] ?? '') ?>">
    <div class="form-group">
        <label for="nome">Nome</label>
        <input type="text" name="nome" id="nome" value="<?= htmlspecialchars($mobs['nome'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="tipo">Tipo</label>
        <input type="text" name="tipo" id="tipo" value="<?= htmlspecialchars($mobs['tipo'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="dificuldade">Dificuldade</label>
        <input type="text" name="dificuldade" id="dificuldade" value="<?= htmlspecialchars($mobs['dificuldade'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="versao">Versao</label>
        <input type="text" name="versao" id="versao" value="<?= htmlspecialchars($mobs['versao'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="imagem">Imagem</label>
        <input type="text" name="imagem" id="imagem" value="<?= htmlspecialchars($mobs['imagem'] ?? '') ?>" class="form-control" required>
    </div>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>