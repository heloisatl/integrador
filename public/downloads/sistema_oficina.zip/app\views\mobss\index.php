<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Mobs</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/mobss/cadastrar" class="btn btn-primary">
            Novo Mobs
        </a>
    </div>
</div>

<?php if (empty($mobss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/mobss/cadastrar" class="btn btn-primary">
            Criar Primeiro Mobs
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>Tipo</th>
                    <th>Dificuldade</th>
                    <th>Versao</th>
                    <th>Imagem</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($mobss as $mobs): ?>
                    <tr>
                        <td><?= htmlspecialchars($mobs['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($mobs['nome'] ?? '') ?></td>
                        <td><?= htmlspecialchars($mobs['tipo'] ?? '') ?></td>
                        <td><?= htmlspecialchars($mobs['dificuldade'] ?? '') ?></td>
                        <td><?= htmlspecialchars($mobs['versao'] ?? '') ?></td>
                        <td><?= htmlspecialchars($mobs['imagem'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/mobss/editar?id=<?= $mobs['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/mobss/excluir?id=<?= $mobs['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>