<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Mobs;
use appepositories\MobsRepository;

class MobsController extends Controller {
    private MobsRepository $repository;

    public function __construct() {
        $this->repository = new MobsRepository();
    }

    public function index(): void {
        $data['mobss'] = $this->repository->listarTodos();
        $this->view('mobss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('mobss/create');
    }

    public function salvar(): void {
        $mobs = new Mobs();
        $mobs->setNome($_POST['nome'] ?? '');
        $mobs->setTipo($_POST['tipo'] ?? '');
        $mobs->setDificuldade($_POST['dificuldade'] ?? '');
        $mobs->setVersao($_POST['versao'] ?? '');
        $mobs->setImagem($_POST['imagem'] ?? '');

        if ($this->repository->inserir($mobs)) {
            $this->redirect(URL_BASE . '/mobss');
        } else {
            $data['erro'] = 'Erro ao cadastrar mobs.';
            $this->view('mobss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/mobss');
        }

        $id = (int) $_GET['id'];
        $data['mobs'] = $this->repository->buscarPorId($id);

        if (!$data['mobs']) {
            $this->redirect(URL_BASE . '/mobss');
        }

        $this->view('mobss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/mobss');
        }

        $id = (int) $_POST['id'];
        $mobs = new Mobs();
        $mobs->setNome($_POST['nome'] ?? '');
        $mobs->setTipo($_POST['tipo'] ?? '');
        $mobs->setDificuldade($_POST['dificuldade'] ?? '');
        $mobs->setVersao($_POST['versao'] ?? '');
        $mobs->setImagem($_POST['imagem'] ?? '');

        if ($this->repository->alterar($mobs, $id)) {
            $this->redirect(URL_BASE . '/mobss');
        } else {
            $this->redirect(URL_BASE . '/mobss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/mobss');
    }
}