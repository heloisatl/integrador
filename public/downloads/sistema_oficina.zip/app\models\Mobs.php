<?php

namespace app\models;

class Mobs {
    private $id;
    private $nome;
    private $tipo;
    private $dificuldade;
    private $versao;
    private $imagem;

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getNome() {
        return $this->nome;
    }

    public function setNome($nome) {
        $this->nome = $nome;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function setTipo($tipo) {
        $this->tipo = $tipo;
    }

    public function getDificuldade() {
        return $this->dificuldade;
    }

    public function setDificuldade($dificuldade) {
        $this->dificuldade = $dificuldade;
    }

    public function getVersao() {
        return $this->versao;
    }

    public function setVersao($versao) {
        $this->versao = $versao;
    }

    public function getImagem() {
        return $this->imagem;
    }

    public function setImagem($imagem) {
        $this->imagem = $imagem;
    }

}