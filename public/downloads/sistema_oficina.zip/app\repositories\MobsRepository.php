<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Mobs;
use PDO;

class MobsRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Mobs $obj): bool {
        $sql = "INSERT INTO mobs (nome, tipo, dificuldade, versao, imagem) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $nome = $obj->getNome();
        $tipo = $obj->getTipo();
        $dificuldade = $obj->getDificuldade();
        $versao = $obj->getVersao();
        $imagem = $obj->getImagem();

        return $stmt->execute([$nome, $tipo, $dificuldade, $versao, $imagem]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM mobs";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM mobs WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Mobs $obj, int $id): bool {
        $nome = $obj->getNome();
        $tipo = $obj->getTipo();
        $dificuldade = $obj->getDificuldade();
        $versao = $obj->getVersao();
        $imagem = $obj->getImagem();

        $sql = "UPDATE mobs SET nome = ?, tipo = ?, dificuldade = ?, versao = ?, imagem = ? WHERE id = ?";
        $params = [$nome, $tipo, $dificuldade, $versao, $imagem, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM mobs WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}