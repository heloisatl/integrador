<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__navigationhiding;
use appepositories\Pma__navigationhidingRepository;

class Pma__navigationhidingController extends Controller {
    private Pma__navigationhidingRepository $repository;

    public function __construct() {
        $this->repository = new Pma__navigationhidingRepository();
    }

    public function index(): void {
        $data['pma__navigationhidings'] = $this->repository->listarTodos();
        $this->view('pma__navigationhidings/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__navigationhidings/create');
    }

    public function salvar(): void {
        $pma__navigationhiding = new Pma__navigationhiding();
        $pma__navigationhiding->setDbase($_POST['dbase'] ?? '');
        $pma__navigationhiding->setUser($_POST['user'] ?? '');
        $pma__navigationhiding->setLabel($_POST['label'] ?? '');
        $pma__navigationhiding->setQuery($_POST['query'] ?? '');
        $pma__navigationhiding->setCol_type($_POST['col_type'] ?? '');
        $pma__navigationhiding->setCol_length($_POST['col_length'] ?? '');
        $pma__navigationhiding->setCol_collation($_POST['col_collation'] ?? '');
        $pma__navigationhiding->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__navigationhiding->setCol_extra($_POST['col_extra'] ?? '');
        $pma__navigationhiding->setCol_default($_POST['col_default'] ?? '');
        $pma__navigationhiding->setTable_name($_POST['table_name'] ?? '');
        $pma__navigationhiding->setColumn_name($_POST['column_name'] ?? '');
        $pma__navigationhiding->setComment($_POST['comment'] ?? '');
        $pma__navigationhiding->setMimetype($_POST['mimetype'] ?? '');
        $pma__navigationhiding->setTransformation($_POST['transformation'] ?? '');
        $pma__navigationhiding->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__navigationhiding->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__navigationhiding->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__navigationhiding->setSettings_data($_POST['settings_data'] ?? '');
        $pma__navigationhiding->setExport_type($_POST['export_type'] ?? '');
        $pma__navigationhiding->setTemplate_name($_POST['template_name'] ?? '');
        $pma__navigationhiding->setTemplate_data($_POST['template_data'] ?? '');
        $pma__navigationhiding->setTables($_POST['tables'] ?? '');
        $pma__navigationhiding->setDb($_POST['db'] ?? '');
        $pma__navigationhiding->setTable($_POST['table'] ?? '');
        $pma__navigationhiding->setTimevalue($_POST['timevalue'] ?? '');
        $pma__navigationhiding->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__navigationhiding->setDb_name($_POST['db_name'] ?? '');
        $pma__navigationhiding->setPage_descr($_POST['page_descr'] ?? '');
        $pma__navigationhiding->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__navigationhiding->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__navigationhiding->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__navigationhiding->setSearch_name($_POST['search_name'] ?? '');
        $pma__navigationhiding->setSearch_data($_POST['search_data'] ?? '');
        $pma__navigationhiding->setX($_POST['x'] ?? '');
        $pma__navigationhiding->setY($_POST['y'] ?? '');
        $pma__navigationhiding->setDisplay_field($_POST['display_field'] ?? '');
        $pma__navigationhiding->setPrefs($_POST['prefs'] ?? '');
        $pma__navigationhiding->setLast_update($_POST['last_update'] ?? '');
        $pma__navigationhiding->setDate_created($_POST['date_created'] ?? '');
        $pma__navigationhiding->setDate_updated($_POST['date_updated'] ?? '');
        $pma__navigationhiding->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__navigationhiding->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__navigationhiding->setData_sql($_POST['data_sql'] ?? '');
        $pma__navigationhiding->setTracking($_POST['tracking'] ?? '');
        $pma__navigationhiding->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__navigationhiding->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__navigationhiding)) {
            $this->redirect(URL_BASE . '/pma__navigationhidings');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__navigationhiding.';
            $this->view('pma__navigationhidings/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__navigationhidings');
        }

        $id = (int) $_GET['id'];
        $data['pma__navigationhiding'] = $this->repository->buscarPorId($id);

        if (!$data['pma__navigationhiding']) {
            $this->redirect(URL_BASE . '/pma__navigationhidings');
        }

        $this->view('pma__navigationhidings/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__navigationhidings');
        }

        $id = (int) $_POST['id'];
        $pma__navigationhiding = new Pma__navigationhiding();
        $pma__navigationhiding->setDbase($_POST['dbase'] ?? '');
        $pma__navigationhiding->setUser($_POST['user'] ?? '');
        $pma__navigationhiding->setLabel($_POST['label'] ?? '');
        $pma__navigationhiding->setQuery($_POST['query'] ?? '');
        $pma__navigationhiding->setCol_type($_POST['col_type'] ?? '');
        $pma__navigationhiding->setCol_length($_POST['col_length'] ?? '');
        $pma__navigationhiding->setCol_collation($_POST['col_collation'] ?? '');
        $pma__navigationhiding->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__navigationhiding->setCol_extra($_POST['col_extra'] ?? '');
        $pma__navigationhiding->setCol_default($_POST['col_default'] ?? '');
        $pma__navigationhiding->setTable_name($_POST['table_name'] ?? '');
        $pma__navigationhiding->setColumn_name($_POST['column_name'] ?? '');
        $pma__navigationhiding->setComment($_POST['comment'] ?? '');
        $pma__navigationhiding->setMimetype($_POST['mimetype'] ?? '');
        $pma__navigationhiding->setTransformation($_POST['transformation'] ?? '');
        $pma__navigationhiding->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__navigationhiding->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__navigationhiding->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__navigationhiding->setSettings_data($_POST['settings_data'] ?? '');
        $pma__navigationhiding->setExport_type($_POST['export_type'] ?? '');
        $pma__navigationhiding->setTemplate_name($_POST['template_name'] ?? '');
        $pma__navigationhiding->setTemplate_data($_POST['template_data'] ?? '');
        $pma__navigationhiding->setTables($_POST['tables'] ?? '');
        $pma__navigationhiding->setDb($_POST['db'] ?? '');
        $pma__navigationhiding->setTable($_POST['table'] ?? '');
        $pma__navigationhiding->setTimevalue($_POST['timevalue'] ?? '');
        $pma__navigationhiding->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__navigationhiding->setDb_name($_POST['db_name'] ?? '');
        $pma__navigationhiding->setPage_descr($_POST['page_descr'] ?? '');
        $pma__navigationhiding->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__navigationhiding->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__navigationhiding->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__navigationhiding->setSearch_name($_POST['search_name'] ?? '');
        $pma__navigationhiding->setSearch_data($_POST['search_data'] ?? '');
        $pma__navigationhiding->setX($_POST['x'] ?? '');
        $pma__navigationhiding->setY($_POST['y'] ?? '');
        $pma__navigationhiding->setDisplay_field($_POST['display_field'] ?? '');
        $pma__navigationhiding->setPrefs($_POST['prefs'] ?? '');
        $pma__navigationhiding->setLast_update($_POST['last_update'] ?? '');
        $pma__navigationhiding->setDate_created($_POST['date_created'] ?? '');
        $pma__navigationhiding->setDate_updated($_POST['date_updated'] ?? '');
        $pma__navigationhiding->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__navigationhiding->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__navigationhiding->setData_sql($_POST['data_sql'] ?? '');
        $pma__navigationhiding->setTracking($_POST['tracking'] ?? '');
        $pma__navigationhiding->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__navigationhiding->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__navigationhiding, $id)) {
            $this->redirect(URL_BASE . '/pma__navigationhidings');
        } else {
            $this->redirect(URL_BASE . '/pma__navigationhidings/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__navigationhidings');
    }
}