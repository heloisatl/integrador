<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__table_coords;
use appepositories\Pma__table_coordsRepository;

class Pma__table_coordsController extends Controller {
    private Pma__table_coordsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__table_coordsRepository();
    }

    public function index(): void {
        $data['pma__table_coordss'] = $this->repository->listarTodos();
        $this->view('pma__table_coordss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__table_coordss/create');
    }

    public function salvar(): void {
        $pma__table_coords = new Pma__table_coords();
        $pma__table_coords->setDbase($_POST['dbase'] ?? '');
        $pma__table_coords->setUser($_POST['user'] ?? '');
        $pma__table_coords->setLabel($_POST['label'] ?? '');
        $pma__table_coords->setQuery($_POST['query'] ?? '');
        $pma__table_coords->setCol_type($_POST['col_type'] ?? '');
        $pma__table_coords->setCol_length($_POST['col_length'] ?? '');
        $pma__table_coords->setCol_collation($_POST['col_collation'] ?? '');
        $pma__table_coords->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__table_coords->setCol_extra($_POST['col_extra'] ?? '');
        $pma__table_coords->setCol_default($_POST['col_default'] ?? '');
        $pma__table_coords->setTable_name($_POST['table_name'] ?? '');
        $pma__table_coords->setColumn_name($_POST['column_name'] ?? '');
        $pma__table_coords->setComment($_POST['comment'] ?? '');
        $pma__table_coords->setMimetype($_POST['mimetype'] ?? '');
        $pma__table_coords->setTransformation($_POST['transformation'] ?? '');
        $pma__table_coords->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__table_coords->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__table_coords->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__table_coords->setSettings_data($_POST['settings_data'] ?? '');
        $pma__table_coords->setExport_type($_POST['export_type'] ?? '');
        $pma__table_coords->setTemplate_name($_POST['template_name'] ?? '');
        $pma__table_coords->setTemplate_data($_POST['template_data'] ?? '');
        $pma__table_coords->setTables($_POST['tables'] ?? '');
        $pma__table_coords->setDb($_POST['db'] ?? '');
        $pma__table_coords->setTable($_POST['table'] ?? '');
        $pma__table_coords->setTimevalue($_POST['timevalue'] ?? '');
        $pma__table_coords->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__table_coords->setDb_name($_POST['db_name'] ?? '');
        $pma__table_coords->setPage_descr($_POST['page_descr'] ?? '');
        $pma__table_coords->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__table_coords->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__table_coords->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__table_coords->setSearch_name($_POST['search_name'] ?? '');
        $pma__table_coords->setSearch_data($_POST['search_data'] ?? '');
        $pma__table_coords->setX($_POST['x'] ?? '');
        $pma__table_coords->setY($_POST['y'] ?? '');
        $pma__table_coords->setDisplay_field($_POST['display_field'] ?? '');
        $pma__table_coords->setPrefs($_POST['prefs'] ?? '');
        $pma__table_coords->setLast_update($_POST['last_update'] ?? '');
        $pma__table_coords->setDate_created($_POST['date_created'] ?? '');
        $pma__table_coords->setDate_updated($_POST['date_updated'] ?? '');
        $pma__table_coords->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__table_coords->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__table_coords->setData_sql($_POST['data_sql'] ?? '');
        $pma__table_coords->setTracking($_POST['tracking'] ?? '');
        $pma__table_coords->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__table_coords->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__table_coords)) {
            $this->redirect(URL_BASE . '/pma__table_coordss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__table_coords.';
            $this->view('pma__table_coordss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__table_coordss');
        }

        $id = (int) $_GET['id'];
        $data['pma__table_coords'] = $this->repository->buscarPorId($id);

        if (!$data['pma__table_coords']) {
            $this->redirect(URL_BASE . '/pma__table_coordss');
        }

        $this->view('pma__table_coordss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__table_coordss');
        }

        $id = (int) $_POST['id'];
        $pma__table_coords = new Pma__table_coords();
        $pma__table_coords->setDbase($_POST['dbase'] ?? '');
        $pma__table_coords->setUser($_POST['user'] ?? '');
        $pma__table_coords->setLabel($_POST['label'] ?? '');
        $pma__table_coords->setQuery($_POST['query'] ?? '');
        $pma__table_coords->setCol_type($_POST['col_type'] ?? '');
        $pma__table_coords->setCol_length($_POST['col_length'] ?? '');
        $pma__table_coords->setCol_collation($_POST['col_collation'] ?? '');
        $pma__table_coords->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__table_coords->setCol_extra($_POST['col_extra'] ?? '');
        $pma__table_coords->setCol_default($_POST['col_default'] ?? '');
        $pma__table_coords->setTable_name($_POST['table_name'] ?? '');
        $pma__table_coords->setColumn_name($_POST['column_name'] ?? '');
        $pma__table_coords->setComment($_POST['comment'] ?? '');
        $pma__table_coords->setMimetype($_POST['mimetype'] ?? '');
        $pma__table_coords->setTransformation($_POST['transformation'] ?? '');
        $pma__table_coords->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__table_coords->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__table_coords->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__table_coords->setSettings_data($_POST['settings_data'] ?? '');
        $pma__table_coords->setExport_type($_POST['export_type'] ?? '');
        $pma__table_coords->setTemplate_name($_POST['template_name'] ?? '');
        $pma__table_coords->setTemplate_data($_POST['template_data'] ?? '');
        $pma__table_coords->setTables($_POST['tables'] ?? '');
        $pma__table_coords->setDb($_POST['db'] ?? '');
        $pma__table_coords->setTable($_POST['table'] ?? '');
        $pma__table_coords->setTimevalue($_POST['timevalue'] ?? '');
        $pma__table_coords->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__table_coords->setDb_name($_POST['db_name'] ?? '');
        $pma__table_coords->setPage_descr($_POST['page_descr'] ?? '');
        $pma__table_coords->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__table_coords->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__table_coords->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__table_coords->setSearch_name($_POST['search_name'] ?? '');
        $pma__table_coords->setSearch_data($_POST['search_data'] ?? '');
        $pma__table_coords->setX($_POST['x'] ?? '');
        $pma__table_coords->setY($_POST['y'] ?? '');
        $pma__table_coords->setDisplay_field($_POST['display_field'] ?? '');
        $pma__table_coords->setPrefs($_POST['prefs'] ?? '');
        $pma__table_coords->setLast_update($_POST['last_update'] ?? '');
        $pma__table_coords->setDate_created($_POST['date_created'] ?? '');
        $pma__table_coords->setDate_updated($_POST['date_updated'] ?? '');
        $pma__table_coords->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__table_coords->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__table_coords->setData_sql($_POST['data_sql'] ?? '');
        $pma__table_coords->setTracking($_POST['tracking'] ?? '');
        $pma__table_coords->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__table_coords->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__table_coords, $id)) {
            $this->redirect(URL_BASE . '/pma__table_coordss');
        } else {
            $this->redirect(URL_BASE . '/pma__table_coordss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__table_coordss');
    }
}