<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__pdf_pages</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__pdf_pagess/cadastrar" class="btn btn-primary">
            Novo Pma__pdf_pages
        </a>
    </div>
</div>

<?php if (empty($pma__pdf_pagess)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__pdf_pagess/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__pdf_pages
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__pdf_pagess as $pma__pdf_pages): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__pdf_pages['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__pdf_pagess/editar?id=<?= $pma__pdf_pages['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__pdf_pagess/excluir?id=<?= $pma__pdf_pages['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>