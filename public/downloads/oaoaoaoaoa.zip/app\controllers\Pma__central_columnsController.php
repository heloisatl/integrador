<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__central_columns;
use appepositories\Pma__central_columnsRepository;

class Pma__central_columnsController extends Controller {
    private Pma__central_columnsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__central_columnsRepository();
    }

    public function index(): void {
        $data['pma__central_columnss'] = $this->repository->listarTodos();
        $this->view('pma__central_columnss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__central_columnss/create');
    }

    public function salvar(): void {
        $pma__central_columns = new Pma__central_columns();
        $pma__central_columns->setDbase($_POST['dbase'] ?? '');
        $pma__central_columns->setUser($_POST['user'] ?? '');
        $pma__central_columns->setLabel($_POST['label'] ?? '');
        $pma__central_columns->setQuery($_POST['query'] ?? '');
        $pma__central_columns->setCol_type($_POST['col_type'] ?? '');
        $pma__central_columns->setCol_length($_POST['col_length'] ?? '');
        $pma__central_columns->setCol_collation($_POST['col_collation'] ?? '');
        $pma__central_columns->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__central_columns->setCol_extra($_POST['col_extra'] ?? '');
        $pma__central_columns->setCol_default($_POST['col_default'] ?? '');
        $pma__central_columns->setTable_name($_POST['table_name'] ?? '');
        $pma__central_columns->setColumn_name($_POST['column_name'] ?? '');
        $pma__central_columns->setComment($_POST['comment'] ?? '');
        $pma__central_columns->setMimetype($_POST['mimetype'] ?? '');
        $pma__central_columns->setTransformation($_POST['transformation'] ?? '');
        $pma__central_columns->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__central_columns->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__central_columns->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__central_columns->setSettings_data($_POST['settings_data'] ?? '');
        $pma__central_columns->setExport_type($_POST['export_type'] ?? '');
        $pma__central_columns->setTemplate_name($_POST['template_name'] ?? '');
        $pma__central_columns->setTemplate_data($_POST['template_data'] ?? '');
        $pma__central_columns->setTables($_POST['tables'] ?? '');
        $pma__central_columns->setDb($_POST['db'] ?? '');
        $pma__central_columns->setTable($_POST['table'] ?? '');
        $pma__central_columns->setTimevalue($_POST['timevalue'] ?? '');
        $pma__central_columns->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__central_columns->setDb_name($_POST['db_name'] ?? '');
        $pma__central_columns->setPage_descr($_POST['page_descr'] ?? '');
        $pma__central_columns->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__central_columns->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__central_columns->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__central_columns->setSearch_name($_POST['search_name'] ?? '');
        $pma__central_columns->setSearch_data($_POST['search_data'] ?? '');
        $pma__central_columns->setX($_POST['x'] ?? '');
        $pma__central_columns->setY($_POST['y'] ?? '');
        $pma__central_columns->setDisplay_field($_POST['display_field'] ?? '');
        $pma__central_columns->setPrefs($_POST['prefs'] ?? '');
        $pma__central_columns->setLast_update($_POST['last_update'] ?? '');
        $pma__central_columns->setDate_created($_POST['date_created'] ?? '');
        $pma__central_columns->setDate_updated($_POST['date_updated'] ?? '');
        $pma__central_columns->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__central_columns->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__central_columns->setData_sql($_POST['data_sql'] ?? '');
        $pma__central_columns->setTracking($_POST['tracking'] ?? '');
        $pma__central_columns->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__central_columns->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__central_columns)) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__central_columns.';
            $this->view('pma__central_columnss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        }

        $id = (int) $_GET['id'];
        $data['pma__central_columns'] = $this->repository->buscarPorId($id);

        if (!$data['pma__central_columns']) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        }

        $this->view('pma__central_columnss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        }

        $id = (int) $_POST['id'];
        $pma__central_columns = new Pma__central_columns();
        $pma__central_columns->setDbase($_POST['dbase'] ?? '');
        $pma__central_columns->setUser($_POST['user'] ?? '');
        $pma__central_columns->setLabel($_POST['label'] ?? '');
        $pma__central_columns->setQuery($_POST['query'] ?? '');
        $pma__central_columns->setCol_type($_POST['col_type'] ?? '');
        $pma__central_columns->setCol_length($_POST['col_length'] ?? '');
        $pma__central_columns->setCol_collation($_POST['col_collation'] ?? '');
        $pma__central_columns->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__central_columns->setCol_extra($_POST['col_extra'] ?? '');
        $pma__central_columns->setCol_default($_POST['col_default'] ?? '');
        $pma__central_columns->setTable_name($_POST['table_name'] ?? '');
        $pma__central_columns->setColumn_name($_POST['column_name'] ?? '');
        $pma__central_columns->setComment($_POST['comment'] ?? '');
        $pma__central_columns->setMimetype($_POST['mimetype'] ?? '');
        $pma__central_columns->setTransformation($_POST['transformation'] ?? '');
        $pma__central_columns->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__central_columns->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__central_columns->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__central_columns->setSettings_data($_POST['settings_data'] ?? '');
        $pma__central_columns->setExport_type($_POST['export_type'] ?? '');
        $pma__central_columns->setTemplate_name($_POST['template_name'] ?? '');
        $pma__central_columns->setTemplate_data($_POST['template_data'] ?? '');
        $pma__central_columns->setTables($_POST['tables'] ?? '');
        $pma__central_columns->setDb($_POST['db'] ?? '');
        $pma__central_columns->setTable($_POST['table'] ?? '');
        $pma__central_columns->setTimevalue($_POST['timevalue'] ?? '');
        $pma__central_columns->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__central_columns->setDb_name($_POST['db_name'] ?? '');
        $pma__central_columns->setPage_descr($_POST['page_descr'] ?? '');
        $pma__central_columns->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__central_columns->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__central_columns->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__central_columns->setSearch_name($_POST['search_name'] ?? '');
        $pma__central_columns->setSearch_data($_POST['search_data'] ?? '');
        $pma__central_columns->setX($_POST['x'] ?? '');
        $pma__central_columns->setY($_POST['y'] ?? '');
        $pma__central_columns->setDisplay_field($_POST['display_field'] ?? '');
        $pma__central_columns->setPrefs($_POST['prefs'] ?? '');
        $pma__central_columns->setLast_update($_POST['last_update'] ?? '');
        $pma__central_columns->setDate_created($_POST['date_created'] ?? '');
        $pma__central_columns->setDate_updated($_POST['date_updated'] ?? '');
        $pma__central_columns->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__central_columns->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__central_columns->setData_sql($_POST['data_sql'] ?? '');
        $pma__central_columns->setTracking($_POST['tracking'] ?? '');
        $pma__central_columns->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__central_columns->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__central_columns, $id)) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        } else {
            $this->redirect(URL_BASE . '/pma__central_columnss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__central_columnss');
    }
}