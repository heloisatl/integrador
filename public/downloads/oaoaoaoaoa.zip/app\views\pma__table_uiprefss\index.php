<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__table_uiprefs</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__table_uiprefss/cadastrar" class="btn btn-primary">
            Novo Pma__table_uiprefs
        </a>
    </div>
</div>

<?php if (empty($pma__table_uiprefss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__table_uiprefss/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__table_uiprefs
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__table_uiprefss as $pma__table_uiprefs): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__table_uiprefs['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_uiprefs['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__table_uiprefss/editar?id=<?= $pma__table_uiprefs['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__table_uiprefss/excluir?id=<?= $pma__table_uiprefs['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>