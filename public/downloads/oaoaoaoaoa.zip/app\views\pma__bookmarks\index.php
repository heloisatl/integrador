<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__bookmark</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__bookmarks/cadastrar" class="btn btn-primary">
            Novo Pma__bookmark
        </a>
    </div>
</div>

<?php if (empty($pma__bookmarks)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__bookmarks/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__bookmark
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__bookmarks as $pma__bookmark): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__bookmark['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__bookmark['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__bookmarks/editar?id=<?= $pma__bookmark['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__bookmarks/excluir?id=<?= $pma__bookmark['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>