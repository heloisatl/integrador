<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__users;
use appepositories\Pma__usersRepository;

class Pma__usersController extends Controller {
    private Pma__usersRepository $repository;

    public function __construct() {
        $this->repository = new Pma__usersRepository();
    }

    public function index(): void {
        $data['pma__userss'] = $this->repository->listarTodos();
        $this->view('pma__userss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__userss/create');
    }

    public function salvar(): void {
        $pma__users = new Pma__users();
        $pma__users->setDbase($_POST['dbase'] ?? '');
        $pma__users->setUser($_POST['user'] ?? '');
        $pma__users->setLabel($_POST['label'] ?? '');
        $pma__users->setQuery($_POST['query'] ?? '');
        $pma__users->setCol_type($_POST['col_type'] ?? '');
        $pma__users->setCol_length($_POST['col_length'] ?? '');
        $pma__users->setCol_collation($_POST['col_collation'] ?? '');
        $pma__users->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__users->setCol_extra($_POST['col_extra'] ?? '');
        $pma__users->setCol_default($_POST['col_default'] ?? '');
        $pma__users->setTable_name($_POST['table_name'] ?? '');
        $pma__users->setColumn_name($_POST['column_name'] ?? '');
        $pma__users->setComment($_POST['comment'] ?? '');
        $pma__users->setMimetype($_POST['mimetype'] ?? '');
        $pma__users->setTransformation($_POST['transformation'] ?? '');
        $pma__users->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__users->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__users->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__users->setSettings_data($_POST['settings_data'] ?? '');
        $pma__users->setExport_type($_POST['export_type'] ?? '');
        $pma__users->setTemplate_name($_POST['template_name'] ?? '');
        $pma__users->setTemplate_data($_POST['template_data'] ?? '');
        $pma__users->setTables($_POST['tables'] ?? '');
        $pma__users->setDb($_POST['db'] ?? '');
        $pma__users->setTable($_POST['table'] ?? '');
        $pma__users->setTimevalue($_POST['timevalue'] ?? '');
        $pma__users->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__users->setDb_name($_POST['db_name'] ?? '');
        $pma__users->setPage_descr($_POST['page_descr'] ?? '');
        $pma__users->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__users->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__users->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__users->setSearch_name($_POST['search_name'] ?? '');
        $pma__users->setSearch_data($_POST['search_data'] ?? '');
        $pma__users->setX($_POST['x'] ?? '');
        $pma__users->setY($_POST['y'] ?? '');
        $pma__users->setDisplay_field($_POST['display_field'] ?? '');
        $pma__users->setPrefs($_POST['prefs'] ?? '');
        $pma__users->setLast_update($_POST['last_update'] ?? '');
        $pma__users->setDate_created($_POST['date_created'] ?? '');
        $pma__users->setDate_updated($_POST['date_updated'] ?? '');
        $pma__users->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__users->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__users->setData_sql($_POST['data_sql'] ?? '');
        $pma__users->setTracking($_POST['tracking'] ?? '');
        $pma__users->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__users->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__users)) {
            $this->redirect(URL_BASE . '/pma__userss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__users.';
            $this->view('pma__userss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__userss');
        }

        $id = (int) $_GET['id'];
        $data['pma__users'] = $this->repository->buscarPorId($id);

        if (!$data['pma__users']) {
            $this->redirect(URL_BASE . '/pma__userss');
        }

        $this->view('pma__userss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__userss');
        }

        $id = (int) $_POST['id'];
        $pma__users = new Pma__users();
        $pma__users->setDbase($_POST['dbase'] ?? '');
        $pma__users->setUser($_POST['user'] ?? '');
        $pma__users->setLabel($_POST['label'] ?? '');
        $pma__users->setQuery($_POST['query'] ?? '');
        $pma__users->setCol_type($_POST['col_type'] ?? '');
        $pma__users->setCol_length($_POST['col_length'] ?? '');
        $pma__users->setCol_collation($_POST['col_collation'] ?? '');
        $pma__users->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__users->setCol_extra($_POST['col_extra'] ?? '');
        $pma__users->setCol_default($_POST['col_default'] ?? '');
        $pma__users->setTable_name($_POST['table_name'] ?? '');
        $pma__users->setColumn_name($_POST['column_name'] ?? '');
        $pma__users->setComment($_POST['comment'] ?? '');
        $pma__users->setMimetype($_POST['mimetype'] ?? '');
        $pma__users->setTransformation($_POST['transformation'] ?? '');
        $pma__users->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__users->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__users->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__users->setSettings_data($_POST['settings_data'] ?? '');
        $pma__users->setExport_type($_POST['export_type'] ?? '');
        $pma__users->setTemplate_name($_POST['template_name'] ?? '');
        $pma__users->setTemplate_data($_POST['template_data'] ?? '');
        $pma__users->setTables($_POST['tables'] ?? '');
        $pma__users->setDb($_POST['db'] ?? '');
        $pma__users->setTable($_POST['table'] ?? '');
        $pma__users->setTimevalue($_POST['timevalue'] ?? '');
        $pma__users->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__users->setDb_name($_POST['db_name'] ?? '');
        $pma__users->setPage_descr($_POST['page_descr'] ?? '');
        $pma__users->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__users->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__users->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__users->setSearch_name($_POST['search_name'] ?? '');
        $pma__users->setSearch_data($_POST['search_data'] ?? '');
        $pma__users->setX($_POST['x'] ?? '');
        $pma__users->setY($_POST['y'] ?? '');
        $pma__users->setDisplay_field($_POST['display_field'] ?? '');
        $pma__users->setPrefs($_POST['prefs'] ?? '');
        $pma__users->setLast_update($_POST['last_update'] ?? '');
        $pma__users->setDate_created($_POST['date_created'] ?? '');
        $pma__users->setDate_updated($_POST['date_updated'] ?? '');
        $pma__users->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__users->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__users->setData_sql($_POST['data_sql'] ?? '');
        $pma__users->setTracking($_POST['tracking'] ?? '');
        $pma__users->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__users->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__users, $id)) {
            $this->redirect(URL_BASE . '/pma__userss');
        } else {
            $this->redirect(URL_BASE . '/pma__userss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__userss');
    }
}