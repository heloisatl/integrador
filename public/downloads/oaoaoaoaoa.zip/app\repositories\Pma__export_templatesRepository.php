<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Pma__export_templates;
use PDO;

class Pma__export_templatesRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Pma__export_templates $obj): bool {
        $sql = "INSERT INTO pma__export_templates () VALUES ()";
        $stmt = $this->con->prepare($sql);

        return $stmt->execute([]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__export_templates";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__export_templates WHERE username = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Pma__export_templates $obj, int $id): bool {

        $sql = "UPDATE pma__export_templates SET  WHERE username = ?";
        $params = [, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__export_templates WHERE username = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}