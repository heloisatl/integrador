<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__savedsearches;
use appepositories\Pma__savedsearchesRepository;

class Pma__savedsearchesController extends Controller {
    private Pma__savedsearchesRepository $repository;

    public function __construct() {
        $this->repository = new Pma__savedsearchesRepository();
    }

    public function index(): void {
        $data['pma__savedsearchess'] = $this->repository->listarTodos();
        $this->view('pma__savedsearchess/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__savedsearchess/create');
    }

    public function salvar(): void {
        $pma__savedsearches = new Pma__savedsearches();
        $pma__savedsearches->setDbase($_POST['dbase'] ?? '');
        $pma__savedsearches->setUser($_POST['user'] ?? '');
        $pma__savedsearches->setLabel($_POST['label'] ?? '');
        $pma__savedsearches->setQuery($_POST['query'] ?? '');
        $pma__savedsearches->setCol_type($_POST['col_type'] ?? '');
        $pma__savedsearches->setCol_length($_POST['col_length'] ?? '');
        $pma__savedsearches->setCol_collation($_POST['col_collation'] ?? '');
        $pma__savedsearches->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__savedsearches->setCol_extra($_POST['col_extra'] ?? '');
        $pma__savedsearches->setCol_default($_POST['col_default'] ?? '');
        $pma__savedsearches->setTable_name($_POST['table_name'] ?? '');
        $pma__savedsearches->setColumn_name($_POST['column_name'] ?? '');
        $pma__savedsearches->setComment($_POST['comment'] ?? '');
        $pma__savedsearches->setMimetype($_POST['mimetype'] ?? '');
        $pma__savedsearches->setTransformation($_POST['transformation'] ?? '');
        $pma__savedsearches->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__savedsearches->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__savedsearches->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__savedsearches->setSettings_data($_POST['settings_data'] ?? '');
        $pma__savedsearches->setExport_type($_POST['export_type'] ?? '');
        $pma__savedsearches->setTemplate_name($_POST['template_name'] ?? '');
        $pma__savedsearches->setTemplate_data($_POST['template_data'] ?? '');
        $pma__savedsearches->setTables($_POST['tables'] ?? '');
        $pma__savedsearches->setDb($_POST['db'] ?? '');
        $pma__savedsearches->setTable($_POST['table'] ?? '');
        $pma__savedsearches->setTimevalue($_POST['timevalue'] ?? '');
        $pma__savedsearches->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__savedsearches->setDb_name($_POST['db_name'] ?? '');
        $pma__savedsearches->setPage_descr($_POST['page_descr'] ?? '');
        $pma__savedsearches->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__savedsearches->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__savedsearches->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__savedsearches->setSearch_name($_POST['search_name'] ?? '');
        $pma__savedsearches->setSearch_data($_POST['search_data'] ?? '');
        $pma__savedsearches->setX($_POST['x'] ?? '');
        $pma__savedsearches->setY($_POST['y'] ?? '');
        $pma__savedsearches->setDisplay_field($_POST['display_field'] ?? '');
        $pma__savedsearches->setPrefs($_POST['prefs'] ?? '');
        $pma__savedsearches->setLast_update($_POST['last_update'] ?? '');
        $pma__savedsearches->setDate_created($_POST['date_created'] ?? '');
        $pma__savedsearches->setDate_updated($_POST['date_updated'] ?? '');
        $pma__savedsearches->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__savedsearches->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__savedsearches->setData_sql($_POST['data_sql'] ?? '');
        $pma__savedsearches->setTracking($_POST['tracking'] ?? '');
        $pma__savedsearches->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__savedsearches->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__savedsearches)) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__savedsearches.';
            $this->view('pma__savedsearchess/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        }

        $id = (int) $_GET['id'];
        $data['pma__savedsearches'] = $this->repository->buscarPorId($id);

        if (!$data['pma__savedsearches']) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        }

        $this->view('pma__savedsearchess/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        }

        $id = (int) $_POST['id'];
        $pma__savedsearches = new Pma__savedsearches();
        $pma__savedsearches->setDbase($_POST['dbase'] ?? '');
        $pma__savedsearches->setUser($_POST['user'] ?? '');
        $pma__savedsearches->setLabel($_POST['label'] ?? '');
        $pma__savedsearches->setQuery($_POST['query'] ?? '');
        $pma__savedsearches->setCol_type($_POST['col_type'] ?? '');
        $pma__savedsearches->setCol_length($_POST['col_length'] ?? '');
        $pma__savedsearches->setCol_collation($_POST['col_collation'] ?? '');
        $pma__savedsearches->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__savedsearches->setCol_extra($_POST['col_extra'] ?? '');
        $pma__savedsearches->setCol_default($_POST['col_default'] ?? '');
        $pma__savedsearches->setTable_name($_POST['table_name'] ?? '');
        $pma__savedsearches->setColumn_name($_POST['column_name'] ?? '');
        $pma__savedsearches->setComment($_POST['comment'] ?? '');
        $pma__savedsearches->setMimetype($_POST['mimetype'] ?? '');
        $pma__savedsearches->setTransformation($_POST['transformation'] ?? '');
        $pma__savedsearches->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__savedsearches->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__savedsearches->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__savedsearches->setSettings_data($_POST['settings_data'] ?? '');
        $pma__savedsearches->setExport_type($_POST['export_type'] ?? '');
        $pma__savedsearches->setTemplate_name($_POST['template_name'] ?? '');
        $pma__savedsearches->setTemplate_data($_POST['template_data'] ?? '');
        $pma__savedsearches->setTables($_POST['tables'] ?? '');
        $pma__savedsearches->setDb($_POST['db'] ?? '');
        $pma__savedsearches->setTable($_POST['table'] ?? '');
        $pma__savedsearches->setTimevalue($_POST['timevalue'] ?? '');
        $pma__savedsearches->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__savedsearches->setDb_name($_POST['db_name'] ?? '');
        $pma__savedsearches->setPage_descr($_POST['page_descr'] ?? '');
        $pma__savedsearches->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__savedsearches->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__savedsearches->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__savedsearches->setSearch_name($_POST['search_name'] ?? '');
        $pma__savedsearches->setSearch_data($_POST['search_data'] ?? '');
        $pma__savedsearches->setX($_POST['x'] ?? '');
        $pma__savedsearches->setY($_POST['y'] ?? '');
        $pma__savedsearches->setDisplay_field($_POST['display_field'] ?? '');
        $pma__savedsearches->setPrefs($_POST['prefs'] ?? '');
        $pma__savedsearches->setLast_update($_POST['last_update'] ?? '');
        $pma__savedsearches->setDate_created($_POST['date_created'] ?? '');
        $pma__savedsearches->setDate_updated($_POST['date_updated'] ?? '');
        $pma__savedsearches->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__savedsearches->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__savedsearches->setData_sql($_POST['data_sql'] ?? '');
        $pma__savedsearches->setTracking($_POST['tracking'] ?? '');
        $pma__savedsearches->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__savedsearches->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__savedsearches, $id)) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        } else {
            $this->redirect(URL_BASE . '/pma__savedsearchess/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__savedsearchess');
    }
}