<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__favorite</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__favorites/cadastrar" class="btn btn-primary">
            Novo Pma__favorite
        </a>
    </div>
</div>

<?php if (empty($pma__favorites)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__favorites/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__favorite
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__favorites as $pma__favorite): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__favorite['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__favorite['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__favorites/editar?id=<?= $pma__favorite['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__favorites/excluir?id=<?= $pma__favorite['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>