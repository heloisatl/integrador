<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Pma__table_coords;
use PDO;

class Pma__table_coordsRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Pma__table_coords $obj): bool {
        $sql = "INSERT INTO pma__table_coords () VALUES ()";
        $stmt = $this->con->prepare($sql);

        return $stmt->execute([]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__table_coords";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__table_coords WHERE username = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Pma__table_coords $obj, int $id): bool {

        $sql = "UPDATE pma__table_coords SET  WHERE username = ?";
        $params = [, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__table_coords WHERE username = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}