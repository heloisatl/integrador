<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__pdf_pages;
use appepositories\Pma__pdf_pagesRepository;

class Pma__pdf_pagesController extends Controller {
    private Pma__pdf_pagesRepository $repository;

    public function __construct() {
        $this->repository = new Pma__pdf_pagesRepository();
    }

    public function index(): void {
        $data['pma__pdf_pagess'] = $this->repository->listarTodos();
        $this->view('pma__pdf_pagess/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__pdf_pagess/create');
    }

    public function salvar(): void {
        $pma__pdf_pages = new Pma__pdf_pages();
        $pma__pdf_pages->setDbase($_POST['dbase'] ?? '');
        $pma__pdf_pages->setUser($_POST['user'] ?? '');
        $pma__pdf_pages->setLabel($_POST['label'] ?? '');
        $pma__pdf_pages->setQuery($_POST['query'] ?? '');
        $pma__pdf_pages->setCol_type($_POST['col_type'] ?? '');
        $pma__pdf_pages->setCol_length($_POST['col_length'] ?? '');
        $pma__pdf_pages->setCol_collation($_POST['col_collation'] ?? '');
        $pma__pdf_pages->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__pdf_pages->setCol_extra($_POST['col_extra'] ?? '');
        $pma__pdf_pages->setCol_default($_POST['col_default'] ?? '');
        $pma__pdf_pages->setTable_name($_POST['table_name'] ?? '');
        $pma__pdf_pages->setColumn_name($_POST['column_name'] ?? '');
        $pma__pdf_pages->setComment($_POST['comment'] ?? '');
        $pma__pdf_pages->setMimetype($_POST['mimetype'] ?? '');
        $pma__pdf_pages->setTransformation($_POST['transformation'] ?? '');
        $pma__pdf_pages->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__pdf_pages->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__pdf_pages->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__pdf_pages->setSettings_data($_POST['settings_data'] ?? '');
        $pma__pdf_pages->setExport_type($_POST['export_type'] ?? '');
        $pma__pdf_pages->setTemplate_name($_POST['template_name'] ?? '');
        $pma__pdf_pages->setTemplate_data($_POST['template_data'] ?? '');
        $pma__pdf_pages->setTables($_POST['tables'] ?? '');
        $pma__pdf_pages->setDb($_POST['db'] ?? '');
        $pma__pdf_pages->setTable($_POST['table'] ?? '');
        $pma__pdf_pages->setTimevalue($_POST['timevalue'] ?? '');
        $pma__pdf_pages->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__pdf_pages->setDb_name($_POST['db_name'] ?? '');
        $pma__pdf_pages->setPage_descr($_POST['page_descr'] ?? '');
        $pma__pdf_pages->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__pdf_pages->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__pdf_pages->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__pdf_pages->setSearch_name($_POST['search_name'] ?? '');
        $pma__pdf_pages->setSearch_data($_POST['search_data'] ?? '');
        $pma__pdf_pages->setX($_POST['x'] ?? '');
        $pma__pdf_pages->setY($_POST['y'] ?? '');
        $pma__pdf_pages->setDisplay_field($_POST['display_field'] ?? '');
        $pma__pdf_pages->setPrefs($_POST['prefs'] ?? '');
        $pma__pdf_pages->setLast_update($_POST['last_update'] ?? '');
        $pma__pdf_pages->setDate_created($_POST['date_created'] ?? '');
        $pma__pdf_pages->setDate_updated($_POST['date_updated'] ?? '');
        $pma__pdf_pages->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__pdf_pages->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__pdf_pages->setData_sql($_POST['data_sql'] ?? '');
        $pma__pdf_pages->setTracking($_POST['tracking'] ?? '');
        $pma__pdf_pages->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__pdf_pages->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__pdf_pages)) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__pdf_pages.';
            $this->view('pma__pdf_pagess/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        }

        $id = (int) $_GET['id'];
        $data['pma__pdf_pages'] = $this->repository->buscarPorId($id);

        if (!$data['pma__pdf_pages']) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        }

        $this->view('pma__pdf_pagess/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        }

        $id = (int) $_POST['id'];
        $pma__pdf_pages = new Pma__pdf_pages();
        $pma__pdf_pages->setDbase($_POST['dbase'] ?? '');
        $pma__pdf_pages->setUser($_POST['user'] ?? '');
        $pma__pdf_pages->setLabel($_POST['label'] ?? '');
        $pma__pdf_pages->setQuery($_POST['query'] ?? '');
        $pma__pdf_pages->setCol_type($_POST['col_type'] ?? '');
        $pma__pdf_pages->setCol_length($_POST['col_length'] ?? '');
        $pma__pdf_pages->setCol_collation($_POST['col_collation'] ?? '');
        $pma__pdf_pages->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__pdf_pages->setCol_extra($_POST['col_extra'] ?? '');
        $pma__pdf_pages->setCol_default($_POST['col_default'] ?? '');
        $pma__pdf_pages->setTable_name($_POST['table_name'] ?? '');
        $pma__pdf_pages->setColumn_name($_POST['column_name'] ?? '');
        $pma__pdf_pages->setComment($_POST['comment'] ?? '');
        $pma__pdf_pages->setMimetype($_POST['mimetype'] ?? '');
        $pma__pdf_pages->setTransformation($_POST['transformation'] ?? '');
        $pma__pdf_pages->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__pdf_pages->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__pdf_pages->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__pdf_pages->setSettings_data($_POST['settings_data'] ?? '');
        $pma__pdf_pages->setExport_type($_POST['export_type'] ?? '');
        $pma__pdf_pages->setTemplate_name($_POST['template_name'] ?? '');
        $pma__pdf_pages->setTemplate_data($_POST['template_data'] ?? '');
        $pma__pdf_pages->setTables($_POST['tables'] ?? '');
        $pma__pdf_pages->setDb($_POST['db'] ?? '');
        $pma__pdf_pages->setTable($_POST['table'] ?? '');
        $pma__pdf_pages->setTimevalue($_POST['timevalue'] ?? '');
        $pma__pdf_pages->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__pdf_pages->setDb_name($_POST['db_name'] ?? '');
        $pma__pdf_pages->setPage_descr($_POST['page_descr'] ?? '');
        $pma__pdf_pages->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__pdf_pages->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__pdf_pages->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__pdf_pages->setSearch_name($_POST['search_name'] ?? '');
        $pma__pdf_pages->setSearch_data($_POST['search_data'] ?? '');
        $pma__pdf_pages->setX($_POST['x'] ?? '');
        $pma__pdf_pages->setY($_POST['y'] ?? '');
        $pma__pdf_pages->setDisplay_field($_POST['display_field'] ?? '');
        $pma__pdf_pages->setPrefs($_POST['prefs'] ?? '');
        $pma__pdf_pages->setLast_update($_POST['last_update'] ?? '');
        $pma__pdf_pages->setDate_created($_POST['date_created'] ?? '');
        $pma__pdf_pages->setDate_updated($_POST['date_updated'] ?? '');
        $pma__pdf_pages->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__pdf_pages->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__pdf_pages->setData_sql($_POST['data_sql'] ?? '');
        $pma__pdf_pages->setTracking($_POST['tracking'] ?? '');
        $pma__pdf_pages->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__pdf_pages->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__pdf_pages, $id)) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        } else {
            $this->redirect(URL_BASE . '/pma__pdf_pagess/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__pdf_pagess');
    }
}