<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__relation;
use appepositories\Pma__relationRepository;

class Pma__relationController extends Controller {
    private Pma__relationRepository $repository;

    public function __construct() {
        $this->repository = new Pma__relationRepository();
    }

    public function index(): void {
        $data['pma__relations'] = $this->repository->listarTodos();
        $this->view('pma__relations/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__relations/create');
    }

    public function salvar(): void {
        $pma__relation = new Pma__relation();
        $pma__relation->setDbase($_POST['dbase'] ?? '');
        $pma__relation->setUser($_POST['user'] ?? '');
        $pma__relation->setLabel($_POST['label'] ?? '');
        $pma__relation->setQuery($_POST['query'] ?? '');
        $pma__relation->setCol_type($_POST['col_type'] ?? '');
        $pma__relation->setCol_length($_POST['col_length'] ?? '');
        $pma__relation->setCol_collation($_POST['col_collation'] ?? '');
        $pma__relation->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__relation->setCol_extra($_POST['col_extra'] ?? '');
        $pma__relation->setCol_default($_POST['col_default'] ?? '');
        $pma__relation->setTable_name($_POST['table_name'] ?? '');
        $pma__relation->setColumn_name($_POST['column_name'] ?? '');
        $pma__relation->setComment($_POST['comment'] ?? '');
        $pma__relation->setMimetype($_POST['mimetype'] ?? '');
        $pma__relation->setTransformation($_POST['transformation'] ?? '');
        $pma__relation->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__relation->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__relation->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__relation->setSettings_data($_POST['settings_data'] ?? '');
        $pma__relation->setExport_type($_POST['export_type'] ?? '');
        $pma__relation->setTemplate_name($_POST['template_name'] ?? '');
        $pma__relation->setTemplate_data($_POST['template_data'] ?? '');
        $pma__relation->setTables($_POST['tables'] ?? '');
        $pma__relation->setDb($_POST['db'] ?? '');
        $pma__relation->setTable($_POST['table'] ?? '');
        $pma__relation->setTimevalue($_POST['timevalue'] ?? '');
        $pma__relation->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__relation->setDb_name($_POST['db_name'] ?? '');
        $pma__relation->setPage_descr($_POST['page_descr'] ?? '');
        $pma__relation->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__relation->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__relation->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__relation->setSearch_name($_POST['search_name'] ?? '');
        $pma__relation->setSearch_data($_POST['search_data'] ?? '');
        $pma__relation->setX($_POST['x'] ?? '');
        $pma__relation->setY($_POST['y'] ?? '');
        $pma__relation->setDisplay_field($_POST['display_field'] ?? '');
        $pma__relation->setPrefs($_POST['prefs'] ?? '');
        $pma__relation->setLast_update($_POST['last_update'] ?? '');
        $pma__relation->setDate_created($_POST['date_created'] ?? '');
        $pma__relation->setDate_updated($_POST['date_updated'] ?? '');
        $pma__relation->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__relation->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__relation->setData_sql($_POST['data_sql'] ?? '');
        $pma__relation->setTracking($_POST['tracking'] ?? '');
        $pma__relation->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__relation->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__relation)) {
            $this->redirect(URL_BASE . '/pma__relations');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__relation.';
            $this->view('pma__relations/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__relations');
        }

        $id = (int) $_GET['id'];
        $data['pma__relation'] = $this->repository->buscarPorId($id);

        if (!$data['pma__relation']) {
            $this->redirect(URL_BASE . '/pma__relations');
        }

        $this->view('pma__relations/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__relations');
        }

        $id = (int) $_POST['id'];
        $pma__relation = new Pma__relation();
        $pma__relation->setDbase($_POST['dbase'] ?? '');
        $pma__relation->setUser($_POST['user'] ?? '');
        $pma__relation->setLabel($_POST['label'] ?? '');
        $pma__relation->setQuery($_POST['query'] ?? '');
        $pma__relation->setCol_type($_POST['col_type'] ?? '');
        $pma__relation->setCol_length($_POST['col_length'] ?? '');
        $pma__relation->setCol_collation($_POST['col_collation'] ?? '');
        $pma__relation->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__relation->setCol_extra($_POST['col_extra'] ?? '');
        $pma__relation->setCol_default($_POST['col_default'] ?? '');
        $pma__relation->setTable_name($_POST['table_name'] ?? '');
        $pma__relation->setColumn_name($_POST['column_name'] ?? '');
        $pma__relation->setComment($_POST['comment'] ?? '');
        $pma__relation->setMimetype($_POST['mimetype'] ?? '');
        $pma__relation->setTransformation($_POST['transformation'] ?? '');
        $pma__relation->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__relation->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__relation->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__relation->setSettings_data($_POST['settings_data'] ?? '');
        $pma__relation->setExport_type($_POST['export_type'] ?? '');
        $pma__relation->setTemplate_name($_POST['template_name'] ?? '');
        $pma__relation->setTemplate_data($_POST['template_data'] ?? '');
        $pma__relation->setTables($_POST['tables'] ?? '');
        $pma__relation->setDb($_POST['db'] ?? '');
        $pma__relation->setTable($_POST['table'] ?? '');
        $pma__relation->setTimevalue($_POST['timevalue'] ?? '');
        $pma__relation->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__relation->setDb_name($_POST['db_name'] ?? '');
        $pma__relation->setPage_descr($_POST['page_descr'] ?? '');
        $pma__relation->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__relation->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__relation->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__relation->setSearch_name($_POST['search_name'] ?? '');
        $pma__relation->setSearch_data($_POST['search_data'] ?? '');
        $pma__relation->setX($_POST['x'] ?? '');
        $pma__relation->setY($_POST['y'] ?? '');
        $pma__relation->setDisplay_field($_POST['display_field'] ?? '');
        $pma__relation->setPrefs($_POST['prefs'] ?? '');
        $pma__relation->setLast_update($_POST['last_update'] ?? '');
        $pma__relation->setDate_created($_POST['date_created'] ?? '');
        $pma__relation->setDate_updated($_POST['date_updated'] ?? '');
        $pma__relation->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__relation->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__relation->setData_sql($_POST['data_sql'] ?? '');
        $pma__relation->setTracking($_POST['tracking'] ?? '');
        $pma__relation->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__relation->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__relation, $id)) {
            $this->redirect(URL_BASE . '/pma__relations');
        } else {
            $this->redirect(URL_BASE . '/pma__relations/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__relations');
    }
}