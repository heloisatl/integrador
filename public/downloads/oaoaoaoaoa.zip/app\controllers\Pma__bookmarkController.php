<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__bookmark;
use appepositories\Pma__bookmarkRepository;

class Pma__bookmarkController extends Controller {
    private Pma__bookmarkRepository $repository;

    public function __construct() {
        $this->repository = new Pma__bookmarkRepository();
    }

    public function index(): void {
        $data['pma__bookmarks'] = $this->repository->listarTodos();
        $this->view('pma__bookmarks/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__bookmarks/create');
    }

    public function salvar(): void {
        $pma__bookmark = new Pma__bookmark();
        $pma__bookmark->setDbase($_POST['dbase'] ?? '');
        $pma__bookmark->setUser($_POST['user'] ?? '');
        $pma__bookmark->setLabel($_POST['label'] ?? '');
        $pma__bookmark->setQuery($_POST['query'] ?? '');
        $pma__bookmark->setCol_type($_POST['col_type'] ?? '');
        $pma__bookmark->setCol_length($_POST['col_length'] ?? '');
        $pma__bookmark->setCol_collation($_POST['col_collation'] ?? '');
        $pma__bookmark->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__bookmark->setCol_extra($_POST['col_extra'] ?? '');
        $pma__bookmark->setCol_default($_POST['col_default'] ?? '');
        $pma__bookmark->setTable_name($_POST['table_name'] ?? '');
        $pma__bookmark->setColumn_name($_POST['column_name'] ?? '');
        $pma__bookmark->setComment($_POST['comment'] ?? '');
        $pma__bookmark->setMimetype($_POST['mimetype'] ?? '');
        $pma__bookmark->setTransformation($_POST['transformation'] ?? '');
        $pma__bookmark->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__bookmark->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__bookmark->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__bookmark->setSettings_data($_POST['settings_data'] ?? '');
        $pma__bookmark->setExport_type($_POST['export_type'] ?? '');
        $pma__bookmark->setTemplate_name($_POST['template_name'] ?? '');
        $pma__bookmark->setTemplate_data($_POST['template_data'] ?? '');
        $pma__bookmark->setTables($_POST['tables'] ?? '');
        $pma__bookmark->setDb($_POST['db'] ?? '');
        $pma__bookmark->setTable($_POST['table'] ?? '');
        $pma__bookmark->setTimevalue($_POST['timevalue'] ?? '');
        $pma__bookmark->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__bookmark->setDb_name($_POST['db_name'] ?? '');
        $pma__bookmark->setPage_descr($_POST['page_descr'] ?? '');
        $pma__bookmark->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__bookmark->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__bookmark->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__bookmark->setSearch_name($_POST['search_name'] ?? '');
        $pma__bookmark->setSearch_data($_POST['search_data'] ?? '');
        $pma__bookmark->setX($_POST['x'] ?? '');
        $pma__bookmark->setY($_POST['y'] ?? '');
        $pma__bookmark->setDisplay_field($_POST['display_field'] ?? '');
        $pma__bookmark->setPrefs($_POST['prefs'] ?? '');
        $pma__bookmark->setLast_update($_POST['last_update'] ?? '');
        $pma__bookmark->setDate_created($_POST['date_created'] ?? '');
        $pma__bookmark->setDate_updated($_POST['date_updated'] ?? '');
        $pma__bookmark->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__bookmark->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__bookmark->setData_sql($_POST['data_sql'] ?? '');
        $pma__bookmark->setTracking($_POST['tracking'] ?? '');
        $pma__bookmark->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__bookmark->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__bookmark)) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__bookmark.';
            $this->view('pma__bookmarks/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        }

        $id = (int) $_GET['id'];
        $data['pma__bookmark'] = $this->repository->buscarPorId($id);

        if (!$data['pma__bookmark']) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        }

        $this->view('pma__bookmarks/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        }

        $id = (int) $_POST['id'];
        $pma__bookmark = new Pma__bookmark();
        $pma__bookmark->setDbase($_POST['dbase'] ?? '');
        $pma__bookmark->setUser($_POST['user'] ?? '');
        $pma__bookmark->setLabel($_POST['label'] ?? '');
        $pma__bookmark->setQuery($_POST['query'] ?? '');
        $pma__bookmark->setCol_type($_POST['col_type'] ?? '');
        $pma__bookmark->setCol_length($_POST['col_length'] ?? '');
        $pma__bookmark->setCol_collation($_POST['col_collation'] ?? '');
        $pma__bookmark->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__bookmark->setCol_extra($_POST['col_extra'] ?? '');
        $pma__bookmark->setCol_default($_POST['col_default'] ?? '');
        $pma__bookmark->setTable_name($_POST['table_name'] ?? '');
        $pma__bookmark->setColumn_name($_POST['column_name'] ?? '');
        $pma__bookmark->setComment($_POST['comment'] ?? '');
        $pma__bookmark->setMimetype($_POST['mimetype'] ?? '');
        $pma__bookmark->setTransformation($_POST['transformation'] ?? '');
        $pma__bookmark->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__bookmark->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__bookmark->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__bookmark->setSettings_data($_POST['settings_data'] ?? '');
        $pma__bookmark->setExport_type($_POST['export_type'] ?? '');
        $pma__bookmark->setTemplate_name($_POST['template_name'] ?? '');
        $pma__bookmark->setTemplate_data($_POST['template_data'] ?? '');
        $pma__bookmark->setTables($_POST['tables'] ?? '');
        $pma__bookmark->setDb($_POST['db'] ?? '');
        $pma__bookmark->setTable($_POST['table'] ?? '');
        $pma__bookmark->setTimevalue($_POST['timevalue'] ?? '');
        $pma__bookmark->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__bookmark->setDb_name($_POST['db_name'] ?? '');
        $pma__bookmark->setPage_descr($_POST['page_descr'] ?? '');
        $pma__bookmark->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__bookmark->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__bookmark->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__bookmark->setSearch_name($_POST['search_name'] ?? '');
        $pma__bookmark->setSearch_data($_POST['search_data'] ?? '');
        $pma__bookmark->setX($_POST['x'] ?? '');
        $pma__bookmark->setY($_POST['y'] ?? '');
        $pma__bookmark->setDisplay_field($_POST['display_field'] ?? '');
        $pma__bookmark->setPrefs($_POST['prefs'] ?? '');
        $pma__bookmark->setLast_update($_POST['last_update'] ?? '');
        $pma__bookmark->setDate_created($_POST['date_created'] ?? '');
        $pma__bookmark->setDate_updated($_POST['date_updated'] ?? '');
        $pma__bookmark->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__bookmark->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__bookmark->setData_sql($_POST['data_sql'] ?? '');
        $pma__bookmark->setTracking($_POST['tracking'] ?? '');
        $pma__bookmark->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__bookmark->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__bookmark, $id)) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        } else {
            $this->redirect(URL_BASE . '/pma__bookmarks/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__bookmarks');
    }
}