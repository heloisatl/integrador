<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__table_uiprefs;
use appepositories\Pma__table_uiprefsRepository;

class Pma__table_uiprefsController extends Controller {
    private Pma__table_uiprefsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__table_uiprefsRepository();
    }

    public function index(): void {
        $data['pma__table_uiprefss'] = $this->repository->listarTodos();
        $this->view('pma__table_uiprefss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__table_uiprefss/create');
    }

    public function salvar(): void {
        $pma__table_uiprefs = new Pma__table_uiprefs();
        $pma__table_uiprefs->setDbase($_POST['dbase'] ?? '');
        $pma__table_uiprefs->setUser($_POST['user'] ?? '');
        $pma__table_uiprefs->setLabel($_POST['label'] ?? '');
        $pma__table_uiprefs->setQuery($_POST['query'] ?? '');
        $pma__table_uiprefs->setCol_type($_POST['col_type'] ?? '');
        $pma__table_uiprefs->setCol_length($_POST['col_length'] ?? '');
        $pma__table_uiprefs->setCol_collation($_POST['col_collation'] ?? '');
        $pma__table_uiprefs->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__table_uiprefs->setCol_extra($_POST['col_extra'] ?? '');
        $pma__table_uiprefs->setCol_default($_POST['col_default'] ?? '');
        $pma__table_uiprefs->setTable_name($_POST['table_name'] ?? '');
        $pma__table_uiprefs->setColumn_name($_POST['column_name'] ?? '');
        $pma__table_uiprefs->setComment($_POST['comment'] ?? '');
        $pma__table_uiprefs->setMimetype($_POST['mimetype'] ?? '');
        $pma__table_uiprefs->setTransformation($_POST['transformation'] ?? '');
        $pma__table_uiprefs->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__table_uiprefs->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__table_uiprefs->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__table_uiprefs->setSettings_data($_POST['settings_data'] ?? '');
        $pma__table_uiprefs->setExport_type($_POST['export_type'] ?? '');
        $pma__table_uiprefs->setTemplate_name($_POST['template_name'] ?? '');
        $pma__table_uiprefs->setTemplate_data($_POST['template_data'] ?? '');
        $pma__table_uiprefs->setTables($_POST['tables'] ?? '');
        $pma__table_uiprefs->setDb($_POST['db'] ?? '');
        $pma__table_uiprefs->setTable($_POST['table'] ?? '');
        $pma__table_uiprefs->setTimevalue($_POST['timevalue'] ?? '');
        $pma__table_uiprefs->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__table_uiprefs->setDb_name($_POST['db_name'] ?? '');
        $pma__table_uiprefs->setPage_descr($_POST['page_descr'] ?? '');
        $pma__table_uiprefs->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__table_uiprefs->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__table_uiprefs->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__table_uiprefs->setSearch_name($_POST['search_name'] ?? '');
        $pma__table_uiprefs->setSearch_data($_POST['search_data'] ?? '');
        $pma__table_uiprefs->setX($_POST['x'] ?? '');
        $pma__table_uiprefs->setY($_POST['y'] ?? '');
        $pma__table_uiprefs->setDisplay_field($_POST['display_field'] ?? '');
        $pma__table_uiprefs->setPrefs($_POST['prefs'] ?? '');
        $pma__table_uiprefs->setLast_update($_POST['last_update'] ?? '');
        $pma__table_uiprefs->setDate_created($_POST['date_created'] ?? '');
        $pma__table_uiprefs->setDate_updated($_POST['date_updated'] ?? '');
        $pma__table_uiprefs->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__table_uiprefs->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__table_uiprefs->setData_sql($_POST['data_sql'] ?? '');
        $pma__table_uiprefs->setTracking($_POST['tracking'] ?? '');
        $pma__table_uiprefs->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__table_uiprefs->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__table_uiprefs)) {
            $this->redirect(URL_BASE . '/pma__table_uiprefss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__table_uiprefs.';
            $this->view('pma__table_uiprefss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__table_uiprefss');
        }

        $id = (int) $_GET['id'];
        $data['pma__table_uiprefs'] = $this->repository->buscarPorId($id);

        if (!$data['pma__table_uiprefs']) {
            $this->redirect(URL_BASE . '/pma__table_uiprefss');
        }

        $this->view('pma__table_uiprefss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__table_uiprefss');
        }

        $id = (int) $_POST['id'];
        $pma__table_uiprefs = new Pma__table_uiprefs();
        $pma__table_uiprefs->setDbase($_POST['dbase'] ?? '');
        $pma__table_uiprefs->setUser($_POST['user'] ?? '');
        $pma__table_uiprefs->setLabel($_POST['label'] ?? '');
        $pma__table_uiprefs->setQuery($_POST['query'] ?? '');
        $pma__table_uiprefs->setCol_type($_POST['col_type'] ?? '');
        $pma__table_uiprefs->setCol_length($_POST['col_length'] ?? '');
        $pma__table_uiprefs->setCol_collation($_POST['col_collation'] ?? '');
        $pma__table_uiprefs->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__table_uiprefs->setCol_extra($_POST['col_extra'] ?? '');
        $pma__table_uiprefs->setCol_default($_POST['col_default'] ?? '');
        $pma__table_uiprefs->setTable_name($_POST['table_name'] ?? '');
        $pma__table_uiprefs->setColumn_name($_POST['column_name'] ?? '');
        $pma__table_uiprefs->setComment($_POST['comment'] ?? '');
        $pma__table_uiprefs->setMimetype($_POST['mimetype'] ?? '');
        $pma__table_uiprefs->setTransformation($_POST['transformation'] ?? '');
        $pma__table_uiprefs->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__table_uiprefs->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__table_uiprefs->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__table_uiprefs->setSettings_data($_POST['settings_data'] ?? '');
        $pma__table_uiprefs->setExport_type($_POST['export_type'] ?? '');
        $pma__table_uiprefs->setTemplate_name($_POST['template_name'] ?? '');
        $pma__table_uiprefs->setTemplate_data($_POST['template_data'] ?? '');
        $pma__table_uiprefs->setTables($_POST['tables'] ?? '');
        $pma__table_uiprefs->setDb($_POST['db'] ?? '');
        $pma__table_uiprefs->setTable($_POST['table'] ?? '');
        $pma__table_uiprefs->setTimevalue($_POST['timevalue'] ?? '');
        $pma__table_uiprefs->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__table_uiprefs->setDb_name($_POST['db_name'] ?? '');
        $pma__table_uiprefs->setPage_descr($_POST['page_descr'] ?? '');
        $pma__table_uiprefs->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__table_uiprefs->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__table_uiprefs->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__table_uiprefs->setSearch_name($_POST['search_name'] ?? '');
        $pma__table_uiprefs->setSearch_data($_POST['search_data'] ?? '');
        $pma__table_uiprefs->setX($_POST['x'] ?? '');
        $pma__table_uiprefs->setY($_POST['y'] ?? '');
        $pma__table_uiprefs->setDisplay_field($_POST['display_field'] ?? '');
        $pma__table_uiprefs->setPrefs($_POST['prefs'] ?? '');
        $pma__table_uiprefs->setLast_update($_POST['last_update'] ?? '');
        $pma__table_uiprefs->setDate_created($_POST['date_created'] ?? '');
        $pma__table_uiprefs->setDate_updated($_POST['date_updated'] ?? '');
        $pma__table_uiprefs->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__table_uiprefs->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__table_uiprefs->setData_sql($_POST['data_sql'] ?? '');
        $pma__table_uiprefs->setTracking($_POST['tracking'] ?? '');
        $pma__table_uiprefs->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__table_uiprefs->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__table_uiprefs, $id)) {
            $this->redirect(URL_BASE . '/pma__table_uiprefss');
        } else {
            $this->redirect(URL_BASE . '/pma__table_uiprefss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__table_uiprefss');
    }
}