<?php

namespace appepositories;

use app\database\ConnectionFactory;
use app\models\Pma__recent;
use PDO;

class Pma__recentRepository {
    private PDO $con;

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function inserir(Pma__recent $obj): bool {
        $sql = "INSERT INTO pma__recent () VALUES ()";
        $stmt = $this->con->prepare($sql);

        return $stmt->execute([]);
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__recent";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__recent WHERE username = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    public function alterar(Pma__recent $obj, int $id): bool {

        $sql = "UPDATE pma__recent SET  WHERE username = ?";
        $params = [, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__recent WHERE username = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}