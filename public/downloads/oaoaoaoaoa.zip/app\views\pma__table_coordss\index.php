<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__table_coords</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__table_coordss/cadastrar" class="btn btn-primary">
            Novo Pma__table_coords
        </a>
    </div>
</div>

<?php if (empty($pma__table_coordss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__table_coordss/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__table_coords
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__table_coordss as $pma__table_coords): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__table_coords['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__table_coordss/editar?id=<?= $pma__table_coords['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__table_coordss/excluir?id=<?= $pma__table_coords['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>