<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__recent</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__recents/cadastrar" class="btn btn-primary">
            Novo Pma__recent
        </a>
    </div>
</div>

<?php if (empty($pma__recents)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__recents/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__recent
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__recents as $pma__recent): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__recent['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__recent['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__recents/editar?id=<?= $pma__recent['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__recents/excluir?id=<?= $pma__recent['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>