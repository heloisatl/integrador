<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__central_columns</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__central_columnss/cadastrar" class="btn btn-primary">
            Novo Pma__central_columns
        </a>
    </div>
</div>

<?php if (empty($pma__central_columnss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__central_columnss/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__central_columns
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__central_columnss as $pma__central_columns): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__central_columns['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__central_columnss/editar?id=<?= $pma__central_columns['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__central_columnss/excluir?id=<?= $pma__central_columns['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>