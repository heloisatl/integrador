<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__userconfig;
use appepositories\Pma__userconfigRepository;

class Pma__userconfigController extends Controller {
    private Pma__userconfigRepository $repository;

    public function __construct() {
        $this->repository = new Pma__userconfigRepository();
    }

    public function index(): void {
        $data['pma__userconfigs'] = $this->repository->listarTodos();
        $this->view('pma__userconfigs/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__userconfigs/create');
    }

    public function salvar(): void {
        $pma__userconfig = new Pma__userconfig();
        $pma__userconfig->setDbase($_POST['dbase'] ?? '');
        $pma__userconfig->setUser($_POST['user'] ?? '');
        $pma__userconfig->setLabel($_POST['label'] ?? '');
        $pma__userconfig->setQuery($_POST['query'] ?? '');
        $pma__userconfig->setCol_type($_POST['col_type'] ?? '');
        $pma__userconfig->setCol_length($_POST['col_length'] ?? '');
        $pma__userconfig->setCol_collation($_POST['col_collation'] ?? '');
        $pma__userconfig->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__userconfig->setCol_extra($_POST['col_extra'] ?? '');
        $pma__userconfig->setCol_default($_POST['col_default'] ?? '');
        $pma__userconfig->setTable_name($_POST['table_name'] ?? '');
        $pma__userconfig->setColumn_name($_POST['column_name'] ?? '');
        $pma__userconfig->setComment($_POST['comment'] ?? '');
        $pma__userconfig->setMimetype($_POST['mimetype'] ?? '');
        $pma__userconfig->setTransformation($_POST['transformation'] ?? '');
        $pma__userconfig->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__userconfig->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__userconfig->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__userconfig->setSettings_data($_POST['settings_data'] ?? '');
        $pma__userconfig->setExport_type($_POST['export_type'] ?? '');
        $pma__userconfig->setTemplate_name($_POST['template_name'] ?? '');
        $pma__userconfig->setTemplate_data($_POST['template_data'] ?? '');
        $pma__userconfig->setTables($_POST['tables'] ?? '');
        $pma__userconfig->setDb($_POST['db'] ?? '');
        $pma__userconfig->setTable($_POST['table'] ?? '');
        $pma__userconfig->setTimevalue($_POST['timevalue'] ?? '');
        $pma__userconfig->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__userconfig->setDb_name($_POST['db_name'] ?? '');
        $pma__userconfig->setPage_descr($_POST['page_descr'] ?? '');
        $pma__userconfig->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__userconfig->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__userconfig->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__userconfig->setSearch_name($_POST['search_name'] ?? '');
        $pma__userconfig->setSearch_data($_POST['search_data'] ?? '');
        $pma__userconfig->setX($_POST['x'] ?? '');
        $pma__userconfig->setY($_POST['y'] ?? '');
        $pma__userconfig->setDisplay_field($_POST['display_field'] ?? '');
        $pma__userconfig->setPrefs($_POST['prefs'] ?? '');
        $pma__userconfig->setLast_update($_POST['last_update'] ?? '');
        $pma__userconfig->setDate_created($_POST['date_created'] ?? '');
        $pma__userconfig->setDate_updated($_POST['date_updated'] ?? '');
        $pma__userconfig->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__userconfig->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__userconfig->setData_sql($_POST['data_sql'] ?? '');
        $pma__userconfig->setTracking($_POST['tracking'] ?? '');
        $pma__userconfig->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__userconfig->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__userconfig)) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__userconfig.';
            $this->view('pma__userconfigs/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        }

        $id = (int) $_GET['id'];
        $data['pma__userconfig'] = $this->repository->buscarPorId($id);

        if (!$data['pma__userconfig']) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        }

        $this->view('pma__userconfigs/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        }

        $id = (int) $_POST['id'];
        $pma__userconfig = new Pma__userconfig();
        $pma__userconfig->setDbase($_POST['dbase'] ?? '');
        $pma__userconfig->setUser($_POST['user'] ?? '');
        $pma__userconfig->setLabel($_POST['label'] ?? '');
        $pma__userconfig->setQuery($_POST['query'] ?? '');
        $pma__userconfig->setCol_type($_POST['col_type'] ?? '');
        $pma__userconfig->setCol_length($_POST['col_length'] ?? '');
        $pma__userconfig->setCol_collation($_POST['col_collation'] ?? '');
        $pma__userconfig->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__userconfig->setCol_extra($_POST['col_extra'] ?? '');
        $pma__userconfig->setCol_default($_POST['col_default'] ?? '');
        $pma__userconfig->setTable_name($_POST['table_name'] ?? '');
        $pma__userconfig->setColumn_name($_POST['column_name'] ?? '');
        $pma__userconfig->setComment($_POST['comment'] ?? '');
        $pma__userconfig->setMimetype($_POST['mimetype'] ?? '');
        $pma__userconfig->setTransformation($_POST['transformation'] ?? '');
        $pma__userconfig->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__userconfig->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__userconfig->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__userconfig->setSettings_data($_POST['settings_data'] ?? '');
        $pma__userconfig->setExport_type($_POST['export_type'] ?? '');
        $pma__userconfig->setTemplate_name($_POST['template_name'] ?? '');
        $pma__userconfig->setTemplate_data($_POST['template_data'] ?? '');
        $pma__userconfig->setTables($_POST['tables'] ?? '');
        $pma__userconfig->setDb($_POST['db'] ?? '');
        $pma__userconfig->setTable($_POST['table'] ?? '');
        $pma__userconfig->setTimevalue($_POST['timevalue'] ?? '');
        $pma__userconfig->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__userconfig->setDb_name($_POST['db_name'] ?? '');
        $pma__userconfig->setPage_descr($_POST['page_descr'] ?? '');
        $pma__userconfig->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__userconfig->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__userconfig->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__userconfig->setSearch_name($_POST['search_name'] ?? '');
        $pma__userconfig->setSearch_data($_POST['search_data'] ?? '');
        $pma__userconfig->setX($_POST['x'] ?? '');
        $pma__userconfig->setY($_POST['y'] ?? '');
        $pma__userconfig->setDisplay_field($_POST['display_field'] ?? '');
        $pma__userconfig->setPrefs($_POST['prefs'] ?? '');
        $pma__userconfig->setLast_update($_POST['last_update'] ?? '');
        $pma__userconfig->setDate_created($_POST['date_created'] ?? '');
        $pma__userconfig->setDate_updated($_POST['date_updated'] ?? '');
        $pma__userconfig->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__userconfig->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__userconfig->setData_sql($_POST['data_sql'] ?? '');
        $pma__userconfig->setTracking($_POST['tracking'] ?? '');
        $pma__userconfig->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__userconfig->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__userconfig, $id)) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        } else {
            $this->redirect(URL_BASE . '/pma__userconfigs/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__userconfigs');
    }
}