<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__column_info;
use appepositories\Pma__column_infoRepository;

class Pma__column_infoController extends Controller {
    private Pma__column_infoRepository $repository;

    public function __construct() {
        $this->repository = new Pma__column_infoRepository();
    }

    public function index(): void {
        $data['pma__column_infos'] = $this->repository->listarTodos();
        $this->view('pma__column_infos/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__column_infos/create');
    }

    public function salvar(): void {
        $pma__column_info = new Pma__column_info();
        $pma__column_info->setDbase($_POST['dbase'] ?? '');
        $pma__column_info->setUser($_POST['user'] ?? '');
        $pma__column_info->setLabel($_POST['label'] ?? '');
        $pma__column_info->setQuery($_POST['query'] ?? '');
        $pma__column_info->setCol_type($_POST['col_type'] ?? '');
        $pma__column_info->setCol_length($_POST['col_length'] ?? '');
        $pma__column_info->setCol_collation($_POST['col_collation'] ?? '');
        $pma__column_info->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__column_info->setCol_extra($_POST['col_extra'] ?? '');
        $pma__column_info->setCol_default($_POST['col_default'] ?? '');
        $pma__column_info->setTable_name($_POST['table_name'] ?? '');
        $pma__column_info->setColumn_name($_POST['column_name'] ?? '');
        $pma__column_info->setComment($_POST['comment'] ?? '');
        $pma__column_info->setMimetype($_POST['mimetype'] ?? '');
        $pma__column_info->setTransformation($_POST['transformation'] ?? '');
        $pma__column_info->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__column_info->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__column_info->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__column_info->setSettings_data($_POST['settings_data'] ?? '');
        $pma__column_info->setExport_type($_POST['export_type'] ?? '');
        $pma__column_info->setTemplate_name($_POST['template_name'] ?? '');
        $pma__column_info->setTemplate_data($_POST['template_data'] ?? '');
        $pma__column_info->setTables($_POST['tables'] ?? '');
        $pma__column_info->setDb($_POST['db'] ?? '');
        $pma__column_info->setTable($_POST['table'] ?? '');
        $pma__column_info->setTimevalue($_POST['timevalue'] ?? '');
        $pma__column_info->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__column_info->setDb_name($_POST['db_name'] ?? '');
        $pma__column_info->setPage_descr($_POST['page_descr'] ?? '');
        $pma__column_info->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__column_info->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__column_info->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__column_info->setSearch_name($_POST['search_name'] ?? '');
        $pma__column_info->setSearch_data($_POST['search_data'] ?? '');
        $pma__column_info->setX($_POST['x'] ?? '');
        $pma__column_info->setY($_POST['y'] ?? '');
        $pma__column_info->setDisplay_field($_POST['display_field'] ?? '');
        $pma__column_info->setPrefs($_POST['prefs'] ?? '');
        $pma__column_info->setLast_update($_POST['last_update'] ?? '');
        $pma__column_info->setDate_created($_POST['date_created'] ?? '');
        $pma__column_info->setDate_updated($_POST['date_updated'] ?? '');
        $pma__column_info->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__column_info->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__column_info->setData_sql($_POST['data_sql'] ?? '');
        $pma__column_info->setTracking($_POST['tracking'] ?? '');
        $pma__column_info->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__column_info->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__column_info)) {
            $this->redirect(URL_BASE . '/pma__column_infos');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__column_info.';
            $this->view('pma__column_infos/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__column_infos');
        }

        $id = (int) $_GET['id'];
        $data['pma__column_info'] = $this->repository->buscarPorId($id);

        if (!$data['pma__column_info']) {
            $this->redirect(URL_BASE . '/pma__column_infos');
        }

        $this->view('pma__column_infos/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__column_infos');
        }

        $id = (int) $_POST['id'];
        $pma__column_info = new Pma__column_info();
        $pma__column_info->setDbase($_POST['dbase'] ?? '');
        $pma__column_info->setUser($_POST['user'] ?? '');
        $pma__column_info->setLabel($_POST['label'] ?? '');
        $pma__column_info->setQuery($_POST['query'] ?? '');
        $pma__column_info->setCol_type($_POST['col_type'] ?? '');
        $pma__column_info->setCol_length($_POST['col_length'] ?? '');
        $pma__column_info->setCol_collation($_POST['col_collation'] ?? '');
        $pma__column_info->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__column_info->setCol_extra($_POST['col_extra'] ?? '');
        $pma__column_info->setCol_default($_POST['col_default'] ?? '');
        $pma__column_info->setTable_name($_POST['table_name'] ?? '');
        $pma__column_info->setColumn_name($_POST['column_name'] ?? '');
        $pma__column_info->setComment($_POST['comment'] ?? '');
        $pma__column_info->setMimetype($_POST['mimetype'] ?? '');
        $pma__column_info->setTransformation($_POST['transformation'] ?? '');
        $pma__column_info->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__column_info->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__column_info->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__column_info->setSettings_data($_POST['settings_data'] ?? '');
        $pma__column_info->setExport_type($_POST['export_type'] ?? '');
        $pma__column_info->setTemplate_name($_POST['template_name'] ?? '');
        $pma__column_info->setTemplate_data($_POST['template_data'] ?? '');
        $pma__column_info->setTables($_POST['tables'] ?? '');
        $pma__column_info->setDb($_POST['db'] ?? '');
        $pma__column_info->setTable($_POST['table'] ?? '');
        $pma__column_info->setTimevalue($_POST['timevalue'] ?? '');
        $pma__column_info->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__column_info->setDb_name($_POST['db_name'] ?? '');
        $pma__column_info->setPage_descr($_POST['page_descr'] ?? '');
        $pma__column_info->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__column_info->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__column_info->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__column_info->setSearch_name($_POST['search_name'] ?? '');
        $pma__column_info->setSearch_data($_POST['search_data'] ?? '');
        $pma__column_info->setX($_POST['x'] ?? '');
        $pma__column_info->setY($_POST['y'] ?? '');
        $pma__column_info->setDisplay_field($_POST['display_field'] ?? '');
        $pma__column_info->setPrefs($_POST['prefs'] ?? '');
        $pma__column_info->setLast_update($_POST['last_update'] ?? '');
        $pma__column_info->setDate_created($_POST['date_created'] ?? '');
        $pma__column_info->setDate_updated($_POST['date_updated'] ?? '');
        $pma__column_info->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__column_info->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__column_info->setData_sql($_POST['data_sql'] ?? '');
        $pma__column_info->setTracking($_POST['tracking'] ?? '');
        $pma__column_info->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__column_info->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__column_info, $id)) {
            $this->redirect(URL_BASE . '/pma__column_infos');
        } else {
            $this->redirect(URL_BASE . '/pma__column_infos/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__column_infos');
    }
}