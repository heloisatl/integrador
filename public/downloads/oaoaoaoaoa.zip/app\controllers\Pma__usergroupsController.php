<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__usergroups;
use appepositories\Pma__usergroupsRepository;

class Pma__usergroupsController extends Controller {
    private Pma__usergroupsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__usergroupsRepository();
    }

    public function index(): void {
        $data['pma__usergroupss'] = $this->repository->listarTodos();
        $this->view('pma__usergroupss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__usergroupss/create');
    }

    public function salvar(): void {
        $pma__usergroups = new Pma__usergroups();
        $pma__usergroups->setDbase($_POST['dbase'] ?? '');
        $pma__usergroups->setUser($_POST['user'] ?? '');
        $pma__usergroups->setLabel($_POST['label'] ?? '');
        $pma__usergroups->setQuery($_POST['query'] ?? '');
        $pma__usergroups->setCol_type($_POST['col_type'] ?? '');
        $pma__usergroups->setCol_length($_POST['col_length'] ?? '');
        $pma__usergroups->setCol_collation($_POST['col_collation'] ?? '');
        $pma__usergroups->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__usergroups->setCol_extra($_POST['col_extra'] ?? '');
        $pma__usergroups->setCol_default($_POST['col_default'] ?? '');
        $pma__usergroups->setTable_name($_POST['table_name'] ?? '');
        $pma__usergroups->setColumn_name($_POST['column_name'] ?? '');
        $pma__usergroups->setComment($_POST['comment'] ?? '');
        $pma__usergroups->setMimetype($_POST['mimetype'] ?? '');
        $pma__usergroups->setTransformation($_POST['transformation'] ?? '');
        $pma__usergroups->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__usergroups->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__usergroups->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__usergroups->setSettings_data($_POST['settings_data'] ?? '');
        $pma__usergroups->setExport_type($_POST['export_type'] ?? '');
        $pma__usergroups->setTemplate_name($_POST['template_name'] ?? '');
        $pma__usergroups->setTemplate_data($_POST['template_data'] ?? '');
        $pma__usergroups->setTables($_POST['tables'] ?? '');
        $pma__usergroups->setDb($_POST['db'] ?? '');
        $pma__usergroups->setTable($_POST['table'] ?? '');
        $pma__usergroups->setTimevalue($_POST['timevalue'] ?? '');
        $pma__usergroups->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__usergroups->setDb_name($_POST['db_name'] ?? '');
        $pma__usergroups->setPage_descr($_POST['page_descr'] ?? '');
        $pma__usergroups->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__usergroups->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__usergroups->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__usergroups->setSearch_name($_POST['search_name'] ?? '');
        $pma__usergroups->setSearch_data($_POST['search_data'] ?? '');
        $pma__usergroups->setX($_POST['x'] ?? '');
        $pma__usergroups->setY($_POST['y'] ?? '');
        $pma__usergroups->setDisplay_field($_POST['display_field'] ?? '');
        $pma__usergroups->setPrefs($_POST['prefs'] ?? '');
        $pma__usergroups->setLast_update($_POST['last_update'] ?? '');
        $pma__usergroups->setDate_created($_POST['date_created'] ?? '');
        $pma__usergroups->setDate_updated($_POST['date_updated'] ?? '');
        $pma__usergroups->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__usergroups->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__usergroups->setData_sql($_POST['data_sql'] ?? '');
        $pma__usergroups->setTracking($_POST['tracking'] ?? '');
        $pma__usergroups->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__usergroups->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__usergroups)) {
            $this->redirect(URL_BASE . '/pma__usergroupss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__usergroups.';
            $this->view('pma__usergroupss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__usergroupss');
        }

        $id = (int) $_GET['id'];
        $data['pma__usergroups'] = $this->repository->buscarPorId($id);

        if (!$data['pma__usergroups']) {
            $this->redirect(URL_BASE . '/pma__usergroupss');
        }

        $this->view('pma__usergroupss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__usergroupss');
        }

        $id = (int) $_POST['id'];
        $pma__usergroups = new Pma__usergroups();
        $pma__usergroups->setDbase($_POST['dbase'] ?? '');
        $pma__usergroups->setUser($_POST['user'] ?? '');
        $pma__usergroups->setLabel($_POST['label'] ?? '');
        $pma__usergroups->setQuery($_POST['query'] ?? '');
        $pma__usergroups->setCol_type($_POST['col_type'] ?? '');
        $pma__usergroups->setCol_length($_POST['col_length'] ?? '');
        $pma__usergroups->setCol_collation($_POST['col_collation'] ?? '');
        $pma__usergroups->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__usergroups->setCol_extra($_POST['col_extra'] ?? '');
        $pma__usergroups->setCol_default($_POST['col_default'] ?? '');
        $pma__usergroups->setTable_name($_POST['table_name'] ?? '');
        $pma__usergroups->setColumn_name($_POST['column_name'] ?? '');
        $pma__usergroups->setComment($_POST['comment'] ?? '');
        $pma__usergroups->setMimetype($_POST['mimetype'] ?? '');
        $pma__usergroups->setTransformation($_POST['transformation'] ?? '');
        $pma__usergroups->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__usergroups->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__usergroups->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__usergroups->setSettings_data($_POST['settings_data'] ?? '');
        $pma__usergroups->setExport_type($_POST['export_type'] ?? '');
        $pma__usergroups->setTemplate_name($_POST['template_name'] ?? '');
        $pma__usergroups->setTemplate_data($_POST['template_data'] ?? '');
        $pma__usergroups->setTables($_POST['tables'] ?? '');
        $pma__usergroups->setDb($_POST['db'] ?? '');
        $pma__usergroups->setTable($_POST['table'] ?? '');
        $pma__usergroups->setTimevalue($_POST['timevalue'] ?? '');
        $pma__usergroups->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__usergroups->setDb_name($_POST['db_name'] ?? '');
        $pma__usergroups->setPage_descr($_POST['page_descr'] ?? '');
        $pma__usergroups->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__usergroups->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__usergroups->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__usergroups->setSearch_name($_POST['search_name'] ?? '');
        $pma__usergroups->setSearch_data($_POST['search_data'] ?? '');
        $pma__usergroups->setX($_POST['x'] ?? '');
        $pma__usergroups->setY($_POST['y'] ?? '');
        $pma__usergroups->setDisplay_field($_POST['display_field'] ?? '');
        $pma__usergroups->setPrefs($_POST['prefs'] ?? '');
        $pma__usergroups->setLast_update($_POST['last_update'] ?? '');
        $pma__usergroups->setDate_created($_POST['date_created'] ?? '');
        $pma__usergroups->setDate_updated($_POST['date_updated'] ?? '');
        $pma__usergroups->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__usergroups->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__usergroups->setData_sql($_POST['data_sql'] ?? '');
        $pma__usergroups->setTracking($_POST['tracking'] ?? '');
        $pma__usergroups->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__usergroups->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__usergroups, $id)) {
            $this->redirect(URL_BASE . '/pma__usergroupss');
        } else {
            $this->redirect(URL_BASE . '/pma__usergroupss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__usergroupss');
    }
}