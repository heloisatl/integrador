<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__export_templates</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__export_templatess/cadastrar" class="btn btn-primary">
            Novo Pma__export_templates
        </a>
    </div>
</div>

<?php if (empty($pma__export_templatess)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__export_templatess/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__export_templates
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__export_templatess as $pma__export_templates): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__export_templates['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__export_templates['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__export_templatess/editar?id=<?= $pma__export_templates['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__export_templatess/excluir?id=<?= $pma__export_templates['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>