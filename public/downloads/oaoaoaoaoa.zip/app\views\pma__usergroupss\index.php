<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__usergroups</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__usergroupss/cadastrar" class="btn btn-primary">
            Novo Pma__usergroups
        </a>
    </div>
</div>

<?php if (empty($pma__usergroupss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__usergroupss/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__usergroups
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__usergroupss as $pma__usergroups): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__usergroups['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__usergroupss/editar?id=<?= $pma__usergroups['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__usergroupss/excluir?id=<?= $pma__usergroups['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>