<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Editar Pma__export_templates</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__export_templatess" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__export_templatess/atualizar" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__export_templates['id'] ?? '') ?>">
    <div class="form-group">
        <label for="dbase">dbase</label>
        <input type="text" name="dbase" id="dbase" value="<?= htmlspecialchars($pma__export_templates['dbase'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="user">user</label>
        <input type="text" name="user" id="user" value="<?= htmlspecialchars($pma__export_templates['user'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="label">label</label>
        <input type="text" name="label" id="label" value="<?= htmlspecialchars($pma__export_templates['label'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="query">query</label>
        <input type="text" name="query" id="query" value="<?= htmlspecialchars($pma__export_templates['query'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="col_type">col_type</label>
        <input type="text" name="col_type" id="col_type" value="<?= htmlspecialchars($pma__export_templates['col_type'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="col_length">col_length</label>
        <input type="text" name="col_length" id="col_length" value="<?= htmlspecialchars($pma__export_templates['col_length'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="col_collation">col_collation</label>
        <input type="text" name="col_collation" id="col_collation" value="<?= htmlspecialchars($pma__export_templates['col_collation'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="col_isNull">col_isNull</label>
        <input type="text" name="col_isNull" id="col_isNull" value="<?= htmlspecialchars($pma__export_templates['col_isNull'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="col_extra">col_extra</label>
        <input type="text" name="col_extra" id="col_extra" value="<?= htmlspecialchars($pma__export_templates['col_extra'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="col_default">col_default</label>
        <input type="text" name="col_default" id="col_default" value="<?= htmlspecialchars($pma__export_templates['col_default'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="table_name">table_name</label>
        <input type="text" name="table_name" id="table_name" value="<?= htmlspecialchars($pma__export_templates['table_name'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="column_name">column_name</label>
        <input type="text" name="column_name" id="column_name" value="<?= htmlspecialchars($pma__export_templates['column_name'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="comment">comment</label>
        <input type="text" name="comment" id="comment" value="<?= htmlspecialchars($pma__export_templates['comment'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="mimetype">mimetype</label>
        <input type="text" name="mimetype" id="mimetype" value="<?= htmlspecialchars($pma__export_templates['mimetype'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="transformation">transformation</label>
        <input type="text" name="transformation" id="transformation" value="<?= htmlspecialchars($pma__export_templates['transformation'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="transformation_options">transformation_options</label>
        <input type="text" name="transformation_options" id="transformation_options" value="<?= htmlspecialchars($pma__export_templates['transformation_options'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="input_transformation">input_transformation</label>
        <input type="text" name="input_transformation" id="input_transformation" value="<?= htmlspecialchars($pma__export_templates['input_transformation'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="input_transformation_options">input_transformation_options</label>
        <input type="text" name="input_transformation_options" id="input_transformation_options" value="<?= htmlspecialchars($pma__export_templates['input_transformation_options'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="settings_data">settings_data</label>
        <input type="text" name="settings_data" id="settings_data" value="<?= htmlspecialchars($pma__export_templates['settings_data'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="export_type">export_type</label>
        <input type="text" name="export_type" id="export_type" value="<?= htmlspecialchars($pma__export_templates['export_type'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="template_name">template_name</label>
        <input type="text" name="template_name" id="template_name" value="<?= htmlspecialchars($pma__export_templates['template_name'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="template_data">template_data</label>
        <input type="text" name="template_data" id="template_data" value="<?= htmlspecialchars($pma__export_templates['template_data'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="tables">tables</label>
        <input type="text" name="tables" id="tables" value="<?= htmlspecialchars($pma__export_templates['tables'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="db">db</label>
        <input type="text" name="db" id="db" value="<?= htmlspecialchars($pma__export_templates['db'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="table">table</label>
        <input type="text" name="table" id="table" value="<?= htmlspecialchars($pma__export_templates['table'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="timevalue">timevalue</label>
        <input type="text" name="timevalue" id="timevalue" value="<?= htmlspecialchars($pma__export_templates['timevalue'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="sqlquery">sqlquery</label>
        <input type="text" name="sqlquery" id="sqlquery" value="<?= htmlspecialchars($pma__export_templates['sqlquery'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="db_name">db_name</label>
        <input type="text" name="db_name" id="db_name" value="<?= htmlspecialchars($pma__export_templates['db_name'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="page_descr">page_descr</label>
        <input type="text" name="page_descr" id="page_descr" value="<?= htmlspecialchars($pma__export_templates['page_descr'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="foreign_db">foreign_db</label>
        <input type="text" name="foreign_db" id="foreign_db" value="<?= htmlspecialchars($pma__export_templates['foreign_db'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="foreign_table">foreign_table</label>
        <input type="text" name="foreign_table" id="foreign_table" value="<?= htmlspecialchars($pma__export_templates['foreign_table'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="foreign_field">foreign_field</label>
        <input type="text" name="foreign_field" id="foreign_field" value="<?= htmlspecialchars($pma__export_templates['foreign_field'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="search_name">search_name</label>
        <input type="text" name="search_name" id="search_name" value="<?= htmlspecialchars($pma__export_templates['search_name'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="search_data">search_data</label>
        <input type="text" name="search_data" id="search_data" value="<?= htmlspecialchars($pma__export_templates['search_data'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="x">x</label>
        <input type="text" name="x" id="x" value="<?= htmlspecialchars($pma__export_templates['x'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="y">y</label>
        <input type="text" name="y" id="y" value="<?= htmlspecialchars($pma__export_templates['y'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="display_field">display_field</label>
        <input type="text" name="display_field" id="display_field" value="<?= htmlspecialchars($pma__export_templates['display_field'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="prefs">prefs</label>
        <input type="text" name="prefs" id="prefs" value="<?= htmlspecialchars($pma__export_templates['prefs'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="last_update">last_update</label>
        <input type="text" name="last_update" id="last_update" value="<?= htmlspecialchars($pma__export_templates['last_update'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="date_created">date_created</label>
        <input type="text" name="date_created" id="date_created" value="<?= htmlspecialchars($pma__export_templates['date_created'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="date_updated">date_updated</label>
        <input type="text" name="date_updated" id="date_updated" value="<?= htmlspecialchars($pma__export_templates['date_updated'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="schema_snapshot">schema_snapshot</label>
        <input type="text" name="schema_snapshot" id="schema_snapshot" value="<?= htmlspecialchars($pma__export_templates['schema_snapshot'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="schema_sql">schema_sql</label>
        <input type="text" name="schema_sql" id="schema_sql" value="<?= htmlspecialchars($pma__export_templates['schema_sql'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="data_sql">data_sql</label>
        <input type="text" name="data_sql" id="data_sql" value="<?= htmlspecialchars($pma__export_templates['data_sql'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="tracking">tracking</label>
        <input type="text" name="tracking" id="tracking" value="<?= htmlspecialchars($pma__export_templates['tracking'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="tracking_active">tracking_active</label>
        <input type="text" name="tracking_active" id="tracking_active" value="<?= htmlspecialchars($pma__export_templates['tracking_active'] ?? '') ?>" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="config_data">config_data</label>
        <input type="text" name="config_data" id="config_data" value="<?= htmlspecialchars($pma__export_templates['config_data'] ?? '') ?>" class="form-control" required>
    </div>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>