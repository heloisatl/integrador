<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__export_templates;
use appepositories\Pma__export_templatesRepository;

class Pma__export_templatesController extends Controller {
    private Pma__export_templatesRepository $repository;

    public function __construct() {
        $this->repository = new Pma__export_templatesRepository();
    }

    public function index(): void {
        $data['pma__export_templatess'] = $this->repository->listarTodos();
        $this->view('pma__export_templatess/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__export_templatess/create');
    }

    public function salvar(): void {
        $pma__export_templates = new Pma__export_templates();
        $pma__export_templates->setDbase($_POST['dbase'] ?? '');
        $pma__export_templates->setUser($_POST['user'] ?? '');
        $pma__export_templates->setLabel($_POST['label'] ?? '');
        $pma__export_templates->setQuery($_POST['query'] ?? '');
        $pma__export_templates->setCol_type($_POST['col_type'] ?? '');
        $pma__export_templates->setCol_length($_POST['col_length'] ?? '');
        $pma__export_templates->setCol_collation($_POST['col_collation'] ?? '');
        $pma__export_templates->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__export_templates->setCol_extra($_POST['col_extra'] ?? '');
        $pma__export_templates->setCol_default($_POST['col_default'] ?? '');
        $pma__export_templates->setTable_name($_POST['table_name'] ?? '');
        $pma__export_templates->setColumn_name($_POST['column_name'] ?? '');
        $pma__export_templates->setComment($_POST['comment'] ?? '');
        $pma__export_templates->setMimetype($_POST['mimetype'] ?? '');
        $pma__export_templates->setTransformation($_POST['transformation'] ?? '');
        $pma__export_templates->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__export_templates->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__export_templates->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__export_templates->setSettings_data($_POST['settings_data'] ?? '');
        $pma__export_templates->setExport_type($_POST['export_type'] ?? '');
        $pma__export_templates->setTemplate_name($_POST['template_name'] ?? '');
        $pma__export_templates->setTemplate_data($_POST['template_data'] ?? '');
        $pma__export_templates->setTables($_POST['tables'] ?? '');
        $pma__export_templates->setDb($_POST['db'] ?? '');
        $pma__export_templates->setTable($_POST['table'] ?? '');
        $pma__export_templates->setTimevalue($_POST['timevalue'] ?? '');
        $pma__export_templates->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__export_templates->setDb_name($_POST['db_name'] ?? '');
        $pma__export_templates->setPage_descr($_POST['page_descr'] ?? '');
        $pma__export_templates->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__export_templates->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__export_templates->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__export_templates->setSearch_name($_POST['search_name'] ?? '');
        $pma__export_templates->setSearch_data($_POST['search_data'] ?? '');
        $pma__export_templates->setX($_POST['x'] ?? '');
        $pma__export_templates->setY($_POST['y'] ?? '');
        $pma__export_templates->setDisplay_field($_POST['display_field'] ?? '');
        $pma__export_templates->setPrefs($_POST['prefs'] ?? '');
        $pma__export_templates->setLast_update($_POST['last_update'] ?? '');
        $pma__export_templates->setDate_created($_POST['date_created'] ?? '');
        $pma__export_templates->setDate_updated($_POST['date_updated'] ?? '');
        $pma__export_templates->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__export_templates->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__export_templates->setData_sql($_POST['data_sql'] ?? '');
        $pma__export_templates->setTracking($_POST['tracking'] ?? '');
        $pma__export_templates->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__export_templates->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__export_templates)) {
            $this->redirect(URL_BASE . '/pma__export_templatess');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__export_templates.';
            $this->view('pma__export_templatess/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__export_templatess');
        }

        $id = (int) $_GET['id'];
        $data['pma__export_templates'] = $this->repository->buscarPorId($id);

        if (!$data['pma__export_templates']) {
            $this->redirect(URL_BASE . '/pma__export_templatess');
        }

        $this->view('pma__export_templatess/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__export_templatess');
        }

        $id = (int) $_POST['id'];
        $pma__export_templates = new Pma__export_templates();
        $pma__export_templates->setDbase($_POST['dbase'] ?? '');
        $pma__export_templates->setUser($_POST['user'] ?? '');
        $pma__export_templates->setLabel($_POST['label'] ?? '');
        $pma__export_templates->setQuery($_POST['query'] ?? '');
        $pma__export_templates->setCol_type($_POST['col_type'] ?? '');
        $pma__export_templates->setCol_length($_POST['col_length'] ?? '');
        $pma__export_templates->setCol_collation($_POST['col_collation'] ?? '');
        $pma__export_templates->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__export_templates->setCol_extra($_POST['col_extra'] ?? '');
        $pma__export_templates->setCol_default($_POST['col_default'] ?? '');
        $pma__export_templates->setTable_name($_POST['table_name'] ?? '');
        $pma__export_templates->setColumn_name($_POST['column_name'] ?? '');
        $pma__export_templates->setComment($_POST['comment'] ?? '');
        $pma__export_templates->setMimetype($_POST['mimetype'] ?? '');
        $pma__export_templates->setTransformation($_POST['transformation'] ?? '');
        $pma__export_templates->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__export_templates->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__export_templates->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__export_templates->setSettings_data($_POST['settings_data'] ?? '');
        $pma__export_templates->setExport_type($_POST['export_type'] ?? '');
        $pma__export_templates->setTemplate_name($_POST['template_name'] ?? '');
        $pma__export_templates->setTemplate_data($_POST['template_data'] ?? '');
        $pma__export_templates->setTables($_POST['tables'] ?? '');
        $pma__export_templates->setDb($_POST['db'] ?? '');
        $pma__export_templates->setTable($_POST['table'] ?? '');
        $pma__export_templates->setTimevalue($_POST['timevalue'] ?? '');
        $pma__export_templates->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__export_templates->setDb_name($_POST['db_name'] ?? '');
        $pma__export_templates->setPage_descr($_POST['page_descr'] ?? '');
        $pma__export_templates->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__export_templates->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__export_templates->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__export_templates->setSearch_name($_POST['search_name'] ?? '');
        $pma__export_templates->setSearch_data($_POST['search_data'] ?? '');
        $pma__export_templates->setX($_POST['x'] ?? '');
        $pma__export_templates->setY($_POST['y'] ?? '');
        $pma__export_templates->setDisplay_field($_POST['display_field'] ?? '');
        $pma__export_templates->setPrefs($_POST['prefs'] ?? '');
        $pma__export_templates->setLast_update($_POST['last_update'] ?? '');
        $pma__export_templates->setDate_created($_POST['date_created'] ?? '');
        $pma__export_templates->setDate_updated($_POST['date_updated'] ?? '');
        $pma__export_templates->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__export_templates->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__export_templates->setData_sql($_POST['data_sql'] ?? '');
        $pma__export_templates->setTracking($_POST['tracking'] ?? '');
        $pma__export_templates->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__export_templates->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__export_templates, $id)) {
            $this->redirect(URL_BASE . '/pma__export_templatess');
        } else {
            $this->redirect(URL_BASE . '/pma__export_templatess/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__export_templatess');
    }
}