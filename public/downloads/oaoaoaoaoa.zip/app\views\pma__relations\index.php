<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__relation</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__relations/cadastrar" class="btn btn-primary">
            Novo Pma__relation
        </a>
    </div>
</div>

<?php if (empty($pma__relations)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__relations/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__relation
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__relations as $pma__relation): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__relation['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__relation['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__relations/editar?id=<?= $pma__relation['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__relations/excluir?id=<?= $pma__relation['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>