<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__designer_settings</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__designer_settingss/cadastrar" class="btn btn-primary">
            Novo Pma__designer_settings
        </a>
    </div>
</div>

<?php if (empty($pma__designer_settingss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__designer_settingss/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__designer_settings
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__designer_settingss as $pma__designer_settings): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__designer_settings['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__designer_settingss/editar?id=<?= $pma__designer_settings['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__designer_settingss/excluir?id=<?= $pma__designer_settings['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>