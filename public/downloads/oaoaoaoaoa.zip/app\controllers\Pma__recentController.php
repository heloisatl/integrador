<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__recent;
use appepositories\Pma__recentRepository;

class Pma__recentController extends Controller {
    private Pma__recentRepository $repository;

    public function __construct() {
        $this->repository = new Pma__recentRepository();
    }

    public function index(): void {
        $data['pma__recents'] = $this->repository->listarTodos();
        $this->view('pma__recents/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__recents/create');
    }

    public function salvar(): void {
        $pma__recent = new Pma__recent();
        $pma__recent->setDbase($_POST['dbase'] ?? '');
        $pma__recent->setUser($_POST['user'] ?? '');
        $pma__recent->setLabel($_POST['label'] ?? '');
        $pma__recent->setQuery($_POST['query'] ?? '');
        $pma__recent->setCol_type($_POST['col_type'] ?? '');
        $pma__recent->setCol_length($_POST['col_length'] ?? '');
        $pma__recent->setCol_collation($_POST['col_collation'] ?? '');
        $pma__recent->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__recent->setCol_extra($_POST['col_extra'] ?? '');
        $pma__recent->setCol_default($_POST['col_default'] ?? '');
        $pma__recent->setTable_name($_POST['table_name'] ?? '');
        $pma__recent->setColumn_name($_POST['column_name'] ?? '');
        $pma__recent->setComment($_POST['comment'] ?? '');
        $pma__recent->setMimetype($_POST['mimetype'] ?? '');
        $pma__recent->setTransformation($_POST['transformation'] ?? '');
        $pma__recent->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__recent->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__recent->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__recent->setSettings_data($_POST['settings_data'] ?? '');
        $pma__recent->setExport_type($_POST['export_type'] ?? '');
        $pma__recent->setTemplate_name($_POST['template_name'] ?? '');
        $pma__recent->setTemplate_data($_POST['template_data'] ?? '');
        $pma__recent->setTables($_POST['tables'] ?? '');
        $pma__recent->setDb($_POST['db'] ?? '');
        $pma__recent->setTable($_POST['table'] ?? '');
        $pma__recent->setTimevalue($_POST['timevalue'] ?? '');
        $pma__recent->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__recent->setDb_name($_POST['db_name'] ?? '');
        $pma__recent->setPage_descr($_POST['page_descr'] ?? '');
        $pma__recent->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__recent->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__recent->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__recent->setSearch_name($_POST['search_name'] ?? '');
        $pma__recent->setSearch_data($_POST['search_data'] ?? '');
        $pma__recent->setX($_POST['x'] ?? '');
        $pma__recent->setY($_POST['y'] ?? '');
        $pma__recent->setDisplay_field($_POST['display_field'] ?? '');
        $pma__recent->setPrefs($_POST['prefs'] ?? '');
        $pma__recent->setLast_update($_POST['last_update'] ?? '');
        $pma__recent->setDate_created($_POST['date_created'] ?? '');
        $pma__recent->setDate_updated($_POST['date_updated'] ?? '');
        $pma__recent->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__recent->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__recent->setData_sql($_POST['data_sql'] ?? '');
        $pma__recent->setTracking($_POST['tracking'] ?? '');
        $pma__recent->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__recent->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__recent)) {
            $this->redirect(URL_BASE . '/pma__recents');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__recent.';
            $this->view('pma__recents/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__recents');
        }

        $id = (int) $_GET['id'];
        $data['pma__recent'] = $this->repository->buscarPorId($id);

        if (!$data['pma__recent']) {
            $this->redirect(URL_BASE . '/pma__recents');
        }

        $this->view('pma__recents/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__recents');
        }

        $id = (int) $_POST['id'];
        $pma__recent = new Pma__recent();
        $pma__recent->setDbase($_POST['dbase'] ?? '');
        $pma__recent->setUser($_POST['user'] ?? '');
        $pma__recent->setLabel($_POST['label'] ?? '');
        $pma__recent->setQuery($_POST['query'] ?? '');
        $pma__recent->setCol_type($_POST['col_type'] ?? '');
        $pma__recent->setCol_length($_POST['col_length'] ?? '');
        $pma__recent->setCol_collation($_POST['col_collation'] ?? '');
        $pma__recent->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__recent->setCol_extra($_POST['col_extra'] ?? '');
        $pma__recent->setCol_default($_POST['col_default'] ?? '');
        $pma__recent->setTable_name($_POST['table_name'] ?? '');
        $pma__recent->setColumn_name($_POST['column_name'] ?? '');
        $pma__recent->setComment($_POST['comment'] ?? '');
        $pma__recent->setMimetype($_POST['mimetype'] ?? '');
        $pma__recent->setTransformation($_POST['transformation'] ?? '');
        $pma__recent->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__recent->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__recent->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__recent->setSettings_data($_POST['settings_data'] ?? '');
        $pma__recent->setExport_type($_POST['export_type'] ?? '');
        $pma__recent->setTemplate_name($_POST['template_name'] ?? '');
        $pma__recent->setTemplate_data($_POST['template_data'] ?? '');
        $pma__recent->setTables($_POST['tables'] ?? '');
        $pma__recent->setDb($_POST['db'] ?? '');
        $pma__recent->setTable($_POST['table'] ?? '');
        $pma__recent->setTimevalue($_POST['timevalue'] ?? '');
        $pma__recent->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__recent->setDb_name($_POST['db_name'] ?? '');
        $pma__recent->setPage_descr($_POST['page_descr'] ?? '');
        $pma__recent->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__recent->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__recent->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__recent->setSearch_name($_POST['search_name'] ?? '');
        $pma__recent->setSearch_data($_POST['search_data'] ?? '');
        $pma__recent->setX($_POST['x'] ?? '');
        $pma__recent->setY($_POST['y'] ?? '');
        $pma__recent->setDisplay_field($_POST['display_field'] ?? '');
        $pma__recent->setPrefs($_POST['prefs'] ?? '');
        $pma__recent->setLast_update($_POST['last_update'] ?? '');
        $pma__recent->setDate_created($_POST['date_created'] ?? '');
        $pma__recent->setDate_updated($_POST['date_updated'] ?? '');
        $pma__recent->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__recent->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__recent->setData_sql($_POST['data_sql'] ?? '');
        $pma__recent->setTracking($_POST['tracking'] ?? '');
        $pma__recent->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__recent->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__recent, $id)) {
            $this->redirect(URL_BASE . '/pma__recents');
        } else {
            $this->redirect(URL_BASE . '/pma__recents/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__recents');
    }
}