<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__designer_settings;
use appepositories\Pma__designer_settingsRepository;

class Pma__designer_settingsController extends Controller {
    private Pma__designer_settingsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__designer_settingsRepository();
    }

    public function index(): void {
        $data['pma__designer_settingss'] = $this->repository->listarTodos();
        $this->view('pma__designer_settingss/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__designer_settingss/create');
    }

    public function salvar(): void {
        $pma__designer_settings = new Pma__designer_settings();
        $pma__designer_settings->setDbase($_POST['dbase'] ?? '');
        $pma__designer_settings->setUser($_POST['user'] ?? '');
        $pma__designer_settings->setLabel($_POST['label'] ?? '');
        $pma__designer_settings->setQuery($_POST['query'] ?? '');
        $pma__designer_settings->setCol_type($_POST['col_type'] ?? '');
        $pma__designer_settings->setCol_length($_POST['col_length'] ?? '');
        $pma__designer_settings->setCol_collation($_POST['col_collation'] ?? '');
        $pma__designer_settings->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__designer_settings->setCol_extra($_POST['col_extra'] ?? '');
        $pma__designer_settings->setCol_default($_POST['col_default'] ?? '');
        $pma__designer_settings->setTable_name($_POST['table_name'] ?? '');
        $pma__designer_settings->setColumn_name($_POST['column_name'] ?? '');
        $pma__designer_settings->setComment($_POST['comment'] ?? '');
        $pma__designer_settings->setMimetype($_POST['mimetype'] ?? '');
        $pma__designer_settings->setTransformation($_POST['transformation'] ?? '');
        $pma__designer_settings->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__designer_settings->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__designer_settings->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__designer_settings->setSettings_data($_POST['settings_data'] ?? '');
        $pma__designer_settings->setExport_type($_POST['export_type'] ?? '');
        $pma__designer_settings->setTemplate_name($_POST['template_name'] ?? '');
        $pma__designer_settings->setTemplate_data($_POST['template_data'] ?? '');
        $pma__designer_settings->setTables($_POST['tables'] ?? '');
        $pma__designer_settings->setDb($_POST['db'] ?? '');
        $pma__designer_settings->setTable($_POST['table'] ?? '');
        $pma__designer_settings->setTimevalue($_POST['timevalue'] ?? '');
        $pma__designer_settings->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__designer_settings->setDb_name($_POST['db_name'] ?? '');
        $pma__designer_settings->setPage_descr($_POST['page_descr'] ?? '');
        $pma__designer_settings->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__designer_settings->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__designer_settings->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__designer_settings->setSearch_name($_POST['search_name'] ?? '');
        $pma__designer_settings->setSearch_data($_POST['search_data'] ?? '');
        $pma__designer_settings->setX($_POST['x'] ?? '');
        $pma__designer_settings->setY($_POST['y'] ?? '');
        $pma__designer_settings->setDisplay_field($_POST['display_field'] ?? '');
        $pma__designer_settings->setPrefs($_POST['prefs'] ?? '');
        $pma__designer_settings->setLast_update($_POST['last_update'] ?? '');
        $pma__designer_settings->setDate_created($_POST['date_created'] ?? '');
        $pma__designer_settings->setDate_updated($_POST['date_updated'] ?? '');
        $pma__designer_settings->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__designer_settings->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__designer_settings->setData_sql($_POST['data_sql'] ?? '');
        $pma__designer_settings->setTracking($_POST['tracking'] ?? '');
        $pma__designer_settings->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__designer_settings->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__designer_settings)) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__designer_settings.';
            $this->view('pma__designer_settingss/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        }

        $id = (int) $_GET['id'];
        $data['pma__designer_settings'] = $this->repository->buscarPorId($id);

        if (!$data['pma__designer_settings']) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        }

        $this->view('pma__designer_settingss/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        }

        $id = (int) $_POST['id'];
        $pma__designer_settings = new Pma__designer_settings();
        $pma__designer_settings->setDbase($_POST['dbase'] ?? '');
        $pma__designer_settings->setUser($_POST['user'] ?? '');
        $pma__designer_settings->setLabel($_POST['label'] ?? '');
        $pma__designer_settings->setQuery($_POST['query'] ?? '');
        $pma__designer_settings->setCol_type($_POST['col_type'] ?? '');
        $pma__designer_settings->setCol_length($_POST['col_length'] ?? '');
        $pma__designer_settings->setCol_collation($_POST['col_collation'] ?? '');
        $pma__designer_settings->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__designer_settings->setCol_extra($_POST['col_extra'] ?? '');
        $pma__designer_settings->setCol_default($_POST['col_default'] ?? '');
        $pma__designer_settings->setTable_name($_POST['table_name'] ?? '');
        $pma__designer_settings->setColumn_name($_POST['column_name'] ?? '');
        $pma__designer_settings->setComment($_POST['comment'] ?? '');
        $pma__designer_settings->setMimetype($_POST['mimetype'] ?? '');
        $pma__designer_settings->setTransformation($_POST['transformation'] ?? '');
        $pma__designer_settings->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__designer_settings->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__designer_settings->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__designer_settings->setSettings_data($_POST['settings_data'] ?? '');
        $pma__designer_settings->setExport_type($_POST['export_type'] ?? '');
        $pma__designer_settings->setTemplate_name($_POST['template_name'] ?? '');
        $pma__designer_settings->setTemplate_data($_POST['template_data'] ?? '');
        $pma__designer_settings->setTables($_POST['tables'] ?? '');
        $pma__designer_settings->setDb($_POST['db'] ?? '');
        $pma__designer_settings->setTable($_POST['table'] ?? '');
        $pma__designer_settings->setTimevalue($_POST['timevalue'] ?? '');
        $pma__designer_settings->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__designer_settings->setDb_name($_POST['db_name'] ?? '');
        $pma__designer_settings->setPage_descr($_POST['page_descr'] ?? '');
        $pma__designer_settings->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__designer_settings->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__designer_settings->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__designer_settings->setSearch_name($_POST['search_name'] ?? '');
        $pma__designer_settings->setSearch_data($_POST['search_data'] ?? '');
        $pma__designer_settings->setX($_POST['x'] ?? '');
        $pma__designer_settings->setY($_POST['y'] ?? '');
        $pma__designer_settings->setDisplay_field($_POST['display_field'] ?? '');
        $pma__designer_settings->setPrefs($_POST['prefs'] ?? '');
        $pma__designer_settings->setLast_update($_POST['last_update'] ?? '');
        $pma__designer_settings->setDate_created($_POST['date_created'] ?? '');
        $pma__designer_settings->setDate_updated($_POST['date_updated'] ?? '');
        $pma__designer_settings->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__designer_settings->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__designer_settings->setData_sql($_POST['data_sql'] ?? '');
        $pma__designer_settings->setTracking($_POST['tracking'] ?? '');
        $pma__designer_settings->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__designer_settings->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__designer_settings, $id)) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        } else {
            $this->redirect(URL_BASE . '/pma__designer_settingss/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__designer_settingss');
    }
}