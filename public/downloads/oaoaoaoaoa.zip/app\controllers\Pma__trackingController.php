<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__tracking;
use appepositories\Pma__trackingRepository;

class Pma__trackingController extends Controller {
    private Pma__trackingRepository $repository;

    public function __construct() {
        $this->repository = new Pma__trackingRepository();
    }

    public function index(): void {
        $data['pma__trackings'] = $this->repository->listarTodos();
        $this->view('pma__trackings/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__trackings/create');
    }

    public function salvar(): void {
        $pma__tracking = new Pma__tracking();
        $pma__tracking->setDbase($_POST['dbase'] ?? '');
        $pma__tracking->setUser($_POST['user'] ?? '');
        $pma__tracking->setLabel($_POST['label'] ?? '');
        $pma__tracking->setQuery($_POST['query'] ?? '');
        $pma__tracking->setCol_type($_POST['col_type'] ?? '');
        $pma__tracking->setCol_length($_POST['col_length'] ?? '');
        $pma__tracking->setCol_collation($_POST['col_collation'] ?? '');
        $pma__tracking->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__tracking->setCol_extra($_POST['col_extra'] ?? '');
        $pma__tracking->setCol_default($_POST['col_default'] ?? '');
        $pma__tracking->setTable_name($_POST['table_name'] ?? '');
        $pma__tracking->setColumn_name($_POST['column_name'] ?? '');
        $pma__tracking->setComment($_POST['comment'] ?? '');
        $pma__tracking->setMimetype($_POST['mimetype'] ?? '');
        $pma__tracking->setTransformation($_POST['transformation'] ?? '');
        $pma__tracking->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__tracking->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__tracking->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__tracking->setSettings_data($_POST['settings_data'] ?? '');
        $pma__tracking->setExport_type($_POST['export_type'] ?? '');
        $pma__tracking->setTemplate_name($_POST['template_name'] ?? '');
        $pma__tracking->setTemplate_data($_POST['template_data'] ?? '');
        $pma__tracking->setTables($_POST['tables'] ?? '');
        $pma__tracking->setDb($_POST['db'] ?? '');
        $pma__tracking->setTable($_POST['table'] ?? '');
        $pma__tracking->setTimevalue($_POST['timevalue'] ?? '');
        $pma__tracking->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__tracking->setDb_name($_POST['db_name'] ?? '');
        $pma__tracking->setPage_descr($_POST['page_descr'] ?? '');
        $pma__tracking->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__tracking->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__tracking->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__tracking->setSearch_name($_POST['search_name'] ?? '');
        $pma__tracking->setSearch_data($_POST['search_data'] ?? '');
        $pma__tracking->setX($_POST['x'] ?? '');
        $pma__tracking->setY($_POST['y'] ?? '');
        $pma__tracking->setDisplay_field($_POST['display_field'] ?? '');
        $pma__tracking->setPrefs($_POST['prefs'] ?? '');
        $pma__tracking->setLast_update($_POST['last_update'] ?? '');
        $pma__tracking->setDate_created($_POST['date_created'] ?? '');
        $pma__tracking->setDate_updated($_POST['date_updated'] ?? '');
        $pma__tracking->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__tracking->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__tracking->setData_sql($_POST['data_sql'] ?? '');
        $pma__tracking->setTracking($_POST['tracking'] ?? '');
        $pma__tracking->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__tracking->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__tracking)) {
            $this->redirect(URL_BASE . '/pma__trackings');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__tracking.';
            $this->view('pma__trackings/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__trackings');
        }

        $id = (int) $_GET['id'];
        $data['pma__tracking'] = $this->repository->buscarPorId($id);

        if (!$data['pma__tracking']) {
            $this->redirect(URL_BASE . '/pma__trackings');
        }

        $this->view('pma__trackings/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__trackings');
        }

        $id = (int) $_POST['id'];
        $pma__tracking = new Pma__tracking();
        $pma__tracking->setDbase($_POST['dbase'] ?? '');
        $pma__tracking->setUser($_POST['user'] ?? '');
        $pma__tracking->setLabel($_POST['label'] ?? '');
        $pma__tracking->setQuery($_POST['query'] ?? '');
        $pma__tracking->setCol_type($_POST['col_type'] ?? '');
        $pma__tracking->setCol_length($_POST['col_length'] ?? '');
        $pma__tracking->setCol_collation($_POST['col_collation'] ?? '');
        $pma__tracking->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__tracking->setCol_extra($_POST['col_extra'] ?? '');
        $pma__tracking->setCol_default($_POST['col_default'] ?? '');
        $pma__tracking->setTable_name($_POST['table_name'] ?? '');
        $pma__tracking->setColumn_name($_POST['column_name'] ?? '');
        $pma__tracking->setComment($_POST['comment'] ?? '');
        $pma__tracking->setMimetype($_POST['mimetype'] ?? '');
        $pma__tracking->setTransformation($_POST['transformation'] ?? '');
        $pma__tracking->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__tracking->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__tracking->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__tracking->setSettings_data($_POST['settings_data'] ?? '');
        $pma__tracking->setExport_type($_POST['export_type'] ?? '');
        $pma__tracking->setTemplate_name($_POST['template_name'] ?? '');
        $pma__tracking->setTemplate_data($_POST['template_data'] ?? '');
        $pma__tracking->setTables($_POST['tables'] ?? '');
        $pma__tracking->setDb($_POST['db'] ?? '');
        $pma__tracking->setTable($_POST['table'] ?? '');
        $pma__tracking->setTimevalue($_POST['timevalue'] ?? '');
        $pma__tracking->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__tracking->setDb_name($_POST['db_name'] ?? '');
        $pma__tracking->setPage_descr($_POST['page_descr'] ?? '');
        $pma__tracking->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__tracking->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__tracking->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__tracking->setSearch_name($_POST['search_name'] ?? '');
        $pma__tracking->setSearch_data($_POST['search_data'] ?? '');
        $pma__tracking->setX($_POST['x'] ?? '');
        $pma__tracking->setY($_POST['y'] ?? '');
        $pma__tracking->setDisplay_field($_POST['display_field'] ?? '');
        $pma__tracking->setPrefs($_POST['prefs'] ?? '');
        $pma__tracking->setLast_update($_POST['last_update'] ?? '');
        $pma__tracking->setDate_created($_POST['date_created'] ?? '');
        $pma__tracking->setDate_updated($_POST['date_updated'] ?? '');
        $pma__tracking->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__tracking->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__tracking->setData_sql($_POST['data_sql'] ?? '');
        $pma__tracking->setTracking($_POST['tracking'] ?? '');
        $pma__tracking->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__tracking->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__tracking, $id)) {
            $this->redirect(URL_BASE . '/pma__trackings');
        } else {
            $this->redirect(URL_BASE . '/pma__trackings/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__trackings');
    }
}