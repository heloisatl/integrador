<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__history</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__historys/cadastrar" class="btn btn-primary">
            Novo Pma__history
        </a>
    </div>
</div>

<?php if (empty($pma__historys)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__historys/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__history
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__historys as $pma__history): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__history['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__historys/editar?id=<?= $pma__history['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__historys/excluir?id=<?= $pma__history['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>