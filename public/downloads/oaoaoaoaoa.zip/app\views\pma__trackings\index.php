<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__tracking</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__trackings/cadastrar" class="btn btn-primary">
            Novo Pma__tracking
        </a>
    </div>
</div>

<?php if (empty($pma__trackings)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__trackings/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__tracking
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__trackings as $pma__tracking): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__tracking['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__trackings/editar?id=<?= $pma__tracking['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__trackings/excluir?id=<?= $pma__tracking['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>