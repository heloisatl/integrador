<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__favorite;
use appepositories\Pma__favoriteRepository;

class Pma__favoriteController extends Controller {
    private Pma__favoriteRepository $repository;

    public function __construct() {
        $this->repository = new Pma__favoriteRepository();
    }

    public function index(): void {
        $data['pma__favorites'] = $this->repository->listarTodos();
        $this->view('pma__favorites/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__favorites/create');
    }

    public function salvar(): void {
        $pma__favorite = new Pma__favorite();
        $pma__favorite->setDbase($_POST['dbase'] ?? '');
        $pma__favorite->setUser($_POST['user'] ?? '');
        $pma__favorite->setLabel($_POST['label'] ?? '');
        $pma__favorite->setQuery($_POST['query'] ?? '');
        $pma__favorite->setCol_type($_POST['col_type'] ?? '');
        $pma__favorite->setCol_length($_POST['col_length'] ?? '');
        $pma__favorite->setCol_collation($_POST['col_collation'] ?? '');
        $pma__favorite->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__favorite->setCol_extra($_POST['col_extra'] ?? '');
        $pma__favorite->setCol_default($_POST['col_default'] ?? '');
        $pma__favorite->setTable_name($_POST['table_name'] ?? '');
        $pma__favorite->setColumn_name($_POST['column_name'] ?? '');
        $pma__favorite->setComment($_POST['comment'] ?? '');
        $pma__favorite->setMimetype($_POST['mimetype'] ?? '');
        $pma__favorite->setTransformation($_POST['transformation'] ?? '');
        $pma__favorite->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__favorite->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__favorite->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__favorite->setSettings_data($_POST['settings_data'] ?? '');
        $pma__favorite->setExport_type($_POST['export_type'] ?? '');
        $pma__favorite->setTemplate_name($_POST['template_name'] ?? '');
        $pma__favorite->setTemplate_data($_POST['template_data'] ?? '');
        $pma__favorite->setTables($_POST['tables'] ?? '');
        $pma__favorite->setDb($_POST['db'] ?? '');
        $pma__favorite->setTable($_POST['table'] ?? '');
        $pma__favorite->setTimevalue($_POST['timevalue'] ?? '');
        $pma__favorite->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__favorite->setDb_name($_POST['db_name'] ?? '');
        $pma__favorite->setPage_descr($_POST['page_descr'] ?? '');
        $pma__favorite->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__favorite->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__favorite->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__favorite->setSearch_name($_POST['search_name'] ?? '');
        $pma__favorite->setSearch_data($_POST['search_data'] ?? '');
        $pma__favorite->setX($_POST['x'] ?? '');
        $pma__favorite->setY($_POST['y'] ?? '');
        $pma__favorite->setDisplay_field($_POST['display_field'] ?? '');
        $pma__favorite->setPrefs($_POST['prefs'] ?? '');
        $pma__favorite->setLast_update($_POST['last_update'] ?? '');
        $pma__favorite->setDate_created($_POST['date_created'] ?? '');
        $pma__favorite->setDate_updated($_POST['date_updated'] ?? '');
        $pma__favorite->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__favorite->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__favorite->setData_sql($_POST['data_sql'] ?? '');
        $pma__favorite->setTracking($_POST['tracking'] ?? '');
        $pma__favorite->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__favorite->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__favorite)) {
            $this->redirect(URL_BASE . '/pma__favorites');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__favorite.';
            $this->view('pma__favorites/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__favorites');
        }

        $id = (int) $_GET['id'];
        $data['pma__favorite'] = $this->repository->buscarPorId($id);

        if (!$data['pma__favorite']) {
            $this->redirect(URL_BASE . '/pma__favorites');
        }

        $this->view('pma__favorites/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__favorites');
        }

        $id = (int) $_POST['id'];
        $pma__favorite = new Pma__favorite();
        $pma__favorite->setDbase($_POST['dbase'] ?? '');
        $pma__favorite->setUser($_POST['user'] ?? '');
        $pma__favorite->setLabel($_POST['label'] ?? '');
        $pma__favorite->setQuery($_POST['query'] ?? '');
        $pma__favorite->setCol_type($_POST['col_type'] ?? '');
        $pma__favorite->setCol_length($_POST['col_length'] ?? '');
        $pma__favorite->setCol_collation($_POST['col_collation'] ?? '');
        $pma__favorite->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__favorite->setCol_extra($_POST['col_extra'] ?? '');
        $pma__favorite->setCol_default($_POST['col_default'] ?? '');
        $pma__favorite->setTable_name($_POST['table_name'] ?? '');
        $pma__favorite->setColumn_name($_POST['column_name'] ?? '');
        $pma__favorite->setComment($_POST['comment'] ?? '');
        $pma__favorite->setMimetype($_POST['mimetype'] ?? '');
        $pma__favorite->setTransformation($_POST['transformation'] ?? '');
        $pma__favorite->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__favorite->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__favorite->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__favorite->setSettings_data($_POST['settings_data'] ?? '');
        $pma__favorite->setExport_type($_POST['export_type'] ?? '');
        $pma__favorite->setTemplate_name($_POST['template_name'] ?? '');
        $pma__favorite->setTemplate_data($_POST['template_data'] ?? '');
        $pma__favorite->setTables($_POST['tables'] ?? '');
        $pma__favorite->setDb($_POST['db'] ?? '');
        $pma__favorite->setTable($_POST['table'] ?? '');
        $pma__favorite->setTimevalue($_POST['timevalue'] ?? '');
        $pma__favorite->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__favorite->setDb_name($_POST['db_name'] ?? '');
        $pma__favorite->setPage_descr($_POST['page_descr'] ?? '');
        $pma__favorite->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__favorite->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__favorite->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__favorite->setSearch_name($_POST['search_name'] ?? '');
        $pma__favorite->setSearch_data($_POST['search_data'] ?? '');
        $pma__favorite->setX($_POST['x'] ?? '');
        $pma__favorite->setY($_POST['y'] ?? '');
        $pma__favorite->setDisplay_field($_POST['display_field'] ?? '');
        $pma__favorite->setPrefs($_POST['prefs'] ?? '');
        $pma__favorite->setLast_update($_POST['last_update'] ?? '');
        $pma__favorite->setDate_created($_POST['date_created'] ?? '');
        $pma__favorite->setDate_updated($_POST['date_updated'] ?? '');
        $pma__favorite->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__favorite->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__favorite->setData_sql($_POST['data_sql'] ?? '');
        $pma__favorite->setTracking($_POST['tracking'] ?? '');
        $pma__favorite->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__favorite->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__favorite, $id)) {
            $this->redirect(URL_BASE . '/pma__favorites');
        } else {
            $this->redirect(URL_BASE . '/pma__favorites/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__favorites');
    }
}