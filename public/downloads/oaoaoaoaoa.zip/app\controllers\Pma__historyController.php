<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__history;
use appepositories\Pma__historyRepository;

class Pma__historyController extends Controller {
    private Pma__historyRepository $repository;

    public function __construct() {
        $this->repository = new Pma__historyRepository();
    }

    public function index(): void {
        $data['pma__historys'] = $this->repository->listarTodos();
        $this->view('pma__historys/index', $data);
    }

    public function cadastrar(): void {
        $this->view('pma__historys/create');
    }

    public function salvar(): void {
        $pma__history = new Pma__history();
        $pma__history->setDbase($_POST['dbase'] ?? '');
        $pma__history->setUser($_POST['user'] ?? '');
        $pma__history->setLabel($_POST['label'] ?? '');
        $pma__history->setQuery($_POST['query'] ?? '');
        $pma__history->setCol_type($_POST['col_type'] ?? '');
        $pma__history->setCol_length($_POST['col_length'] ?? '');
        $pma__history->setCol_collation($_POST['col_collation'] ?? '');
        $pma__history->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__history->setCol_extra($_POST['col_extra'] ?? '');
        $pma__history->setCol_default($_POST['col_default'] ?? '');
        $pma__history->setTable_name($_POST['table_name'] ?? '');
        $pma__history->setColumn_name($_POST['column_name'] ?? '');
        $pma__history->setComment($_POST['comment'] ?? '');
        $pma__history->setMimetype($_POST['mimetype'] ?? '');
        $pma__history->setTransformation($_POST['transformation'] ?? '');
        $pma__history->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__history->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__history->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__history->setSettings_data($_POST['settings_data'] ?? '');
        $pma__history->setExport_type($_POST['export_type'] ?? '');
        $pma__history->setTemplate_name($_POST['template_name'] ?? '');
        $pma__history->setTemplate_data($_POST['template_data'] ?? '');
        $pma__history->setTables($_POST['tables'] ?? '');
        $pma__history->setDb($_POST['db'] ?? '');
        $pma__history->setTable($_POST['table'] ?? '');
        $pma__history->setTimevalue($_POST['timevalue'] ?? '');
        $pma__history->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__history->setDb_name($_POST['db_name'] ?? '');
        $pma__history->setPage_descr($_POST['page_descr'] ?? '');
        $pma__history->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__history->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__history->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__history->setSearch_name($_POST['search_name'] ?? '');
        $pma__history->setSearch_data($_POST['search_data'] ?? '');
        $pma__history->setX($_POST['x'] ?? '');
        $pma__history->setY($_POST['y'] ?? '');
        $pma__history->setDisplay_field($_POST['display_field'] ?? '');
        $pma__history->setPrefs($_POST['prefs'] ?? '');
        $pma__history->setLast_update($_POST['last_update'] ?? '');
        $pma__history->setDate_created($_POST['date_created'] ?? '');
        $pma__history->setDate_updated($_POST['date_updated'] ?? '');
        $pma__history->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__history->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__history->setData_sql($_POST['data_sql'] ?? '');
        $pma__history->setTracking($_POST['tracking'] ?? '');
        $pma__history->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__history->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__history)) {
            $this->redirect(URL_BASE . '/pma__historys');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__history.';
            $this->view('pma__historys/create', $data);
        }
    }

    public function editar(): void {
        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/pma__historys');
        }

        $id = (int) $_GET['id'];
        $data['pma__history'] = $this->repository->buscarPorId($id);

        if (!$data['pma__history']) {
            $this->redirect(URL_BASE . '/pma__historys');
        }

        $this->view('pma__historys/edit', $data);
    }

    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__historys');
        }

        $id = (int) $_POST['id'];
        $pma__history = new Pma__history();
        $pma__history->setDbase($_POST['dbase'] ?? '');
        $pma__history->setUser($_POST['user'] ?? '');
        $pma__history->setLabel($_POST['label'] ?? '');
        $pma__history->setQuery($_POST['query'] ?? '');
        $pma__history->setCol_type($_POST['col_type'] ?? '');
        $pma__history->setCol_length($_POST['col_length'] ?? '');
        $pma__history->setCol_collation($_POST['col_collation'] ?? '');
        $pma__history->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__history->setCol_extra($_POST['col_extra'] ?? '');
        $pma__history->setCol_default($_POST['col_default'] ?? '');
        $pma__history->setTable_name($_POST['table_name'] ?? '');
        $pma__history->setColumn_name($_POST['column_name'] ?? '');
        $pma__history->setComment($_POST['comment'] ?? '');
        $pma__history->setMimetype($_POST['mimetype'] ?? '');
        $pma__history->setTransformation($_POST['transformation'] ?? '');
        $pma__history->setTransformation_options($_POST['transformation_options'] ?? '');
        $pma__history->setInput_transformation($_POST['input_transformation'] ?? '');
        $pma__history->setInput_transformation_options($_POST['input_transformation_options'] ?? '');
        $pma__history->setSettings_data($_POST['settings_data'] ?? '');
        $pma__history->setExport_type($_POST['export_type'] ?? '');
        $pma__history->setTemplate_name($_POST['template_name'] ?? '');
        $pma__history->setTemplate_data($_POST['template_data'] ?? '');
        $pma__history->setTables($_POST['tables'] ?? '');
        $pma__history->setDb($_POST['db'] ?? '');
        $pma__history->setTable($_POST['table'] ?? '');
        $pma__history->setTimevalue($_POST['timevalue'] ?? '');
        $pma__history->setSqlquery($_POST['sqlquery'] ?? '');
        $pma__history->setDb_name($_POST['db_name'] ?? '');
        $pma__history->setPage_descr($_POST['page_descr'] ?? '');
        $pma__history->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__history->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__history->setForeign_field($_POST['foreign_field'] ?? '');
        $pma__history->setSearch_name($_POST['search_name'] ?? '');
        $pma__history->setSearch_data($_POST['search_data'] ?? '');
        $pma__history->setX($_POST['x'] ?? '');
        $pma__history->setY($_POST['y'] ?? '');
        $pma__history->setDisplay_field($_POST['display_field'] ?? '');
        $pma__history->setPrefs($_POST['prefs'] ?? '');
        $pma__history->setLast_update($_POST['last_update'] ?? '');
        $pma__history->setDate_created($_POST['date_created'] ?? '');
        $pma__history->setDate_updated($_POST['date_updated'] ?? '');
        $pma__history->setSchema_snapshot($_POST['schema_snapshot'] ?? '');
        $pma__history->setSchema_sql($_POST['schema_sql'] ?? '');
        $pma__history->setData_sql($_POST['data_sql'] ?? '');
        $pma__history->setTracking($_POST['tracking'] ?? '');
        $pma__history->setTracking_active($_POST['tracking_active'] ?? '');
        $pma__history->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__history, $id)) {
            $this->redirect(URL_BASE . '/pma__historys');
        } else {
            $this->redirect(URL_BASE . '/pma__historys/editar?id=' . $id);
        }
    }

    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__historys');
    }
}