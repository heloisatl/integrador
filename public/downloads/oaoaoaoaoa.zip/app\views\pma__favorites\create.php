<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__favorite</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__favorites" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__favorites/salvar" method="POST">
<input type='text' name='dbase' id='dbase' value='<?= $obj?$obj['dbase']:''?>'><br>
<input type='text' name='user' id='user' value='<?= $obj?$obj['user']:''?>'><br>
<input type='text' name='label' id='label' value='<?= $obj?$obj['label']:''?>'><br>
<input type='text' name='query' id='query' value='<?= $obj?$obj['query']:''?>'><br>
<input type='text' name='col_type' id='col_type' value='<?= $obj?$obj['col_type']:''?>'><br>
<input type='text' name='col_length' id='col_length' value='<?= $obj?$obj['col_length']:''?>'><br>
<input type='text' name='col_collation' id='col_collation' value='<?= $obj?$obj['col_collation']:''?>'><br>
<p><b>Erro:o tipo de atributo tinyint(1) não foi reconhecido.</b></p><input type='text' name='col_extra' id='col_extra' value='<?= $obj?$obj['col_extra']:''?>'><br>
<input type='text' name='col_default' id='col_default' value='<?= $obj?$obj['col_default']:''?>'><br>
<input type='text' name='table_name' id='table_name' value='<?= $obj?$obj['table_name']:''?>'><br>
<input type='text' name='column_name' id='column_name' value='<?= $obj?$obj['column_name']:''?>'><br>
<input type='text' name='comment' id='comment' value='<?= $obj?$obj['comment']:''?>'><br>
<input type='text' name='mimetype' id='mimetype' value='<?= $obj?$obj['mimetype']:''?>'><br>
<input type='text' name='transformation' id='transformation' value='<?= $obj?$obj['transformation']:''?>'><br>
<input type='text' name='transformation_options' id='transformation_options' value='<?= $obj?$obj['transformation_options']:''?>'><br>
<input type='text' name='input_transformation' id='input_transformation' value='<?= $obj?$obj['input_transformation']:''?>'><br>
<input type='text' name='input_transformation_options' id='input_transformation_options' value='<?= $obj?$obj['input_transformation_options']:''?>'><br>
<input type='text' name='settings_data' id='settings_data' value='<?= $obj?$obj['settings_data']:''?>'><br>
<input type='text' name='export_type' id='export_type' value='<?= $obj?$obj['export_type']:''?>'><br>
<input type='text' name='template_name' id='template_name' value='<?= $obj?$obj['template_name']:''?>'><br>
<input type='text' name='template_data' id='template_data' value='<?= $obj?$obj['template_data']:''?>'><br>
<input type='text' name='tables' id='tables' value='<?= $obj?$obj['tables']:''?>'><br>
<input type='text' name='db' id='db' value='<?= $obj?$obj['db']:''?>'><br>
<input type='text' name='table' id='table' value='<?= $obj?$obj['table']:''?>'><br>
<p><b>Erro:o tipo de atributo timestamp não foi reconhecido.</b></p><input type='text' name='sqlquery' id='sqlquery' value='<?= $obj?$obj['sqlquery']:''?>'><br>
<input type='text' name='db_name' id='db_name' value='<?= $obj?$obj['db_name']:''?>'><br>
<input type='text' name='page_descr' id='page_descr' value='<?= $obj?$obj['page_descr']:''?>'><br>
<input type='text' name='foreign_db' id='foreign_db' value='<?= $obj?$obj['foreign_db']:''?>'><br>
<input type='text' name='foreign_table' id='foreign_table' value='<?= $obj?$obj['foreign_table']:''?>'><br>
<input type='text' name='foreign_field' id='foreign_field' value='<?= $obj?$obj['foreign_field']:''?>'><br>
<input type='text' name='search_name' id='search_name' value='<?= $obj?$obj['search_name']:''?>'><br>
<input type='text' name='search_data' id='search_data' value='<?= $obj?$obj['search_data']:''?>'><br>
<p><b>Erro:o tipo de atributo float unsigned não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo float unsigned não foi reconhecido.</b></p><input type='text' name='display_field' id='display_field' value='<?= $obj?$obj['display_field']:''?>'><br>
<input type='text' name='prefs' id='prefs' value='<?= $obj?$obj['prefs']:''?>'><br>
<p><b>Erro:o tipo de atributo timestamp não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo datetime não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo datetime não foi reconhecido.</b></p><input type='text' name='schema_snapshot' id='schema_snapshot' value='<?= $obj?$obj['schema_snapshot']:''?>'><br>
<input type='text' name='schema_sql' id='schema_sql' value='<?= $obj?$obj['schema_sql']:''?>'><br>
<p><b>Erro:o tipo de atributo longtext não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') não foi reconhecido.</b></p><input type='number' name='tracking_active' id='tracking_active' value='<?= $obj?$obj['tracking_active']:''?>'><br>
<input type='text' name='config_data' id='config_data' value='<?= $obj?$obj['config_data']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>