<?php

namespace app\models;

class Pma__usergroups {
    private $id;
    private $dbase;
    private $user;
    private $label;
    private $query;
    private $db_name;
    private $col_name;
    private $col_type;
    private $col_length;
    private $col_collation;
    private $col_isNull;
    private $col_extra;
    private $col_default;
    private $id;
    private $table_name;
    private $column_name;
    private $comment;
    private $mimetype;
    private $transformation;
    private $transformation_options;
    private $input_transformation;
    private $input_transformation_options;
    private $username;
    private $settings_data;
    private $id;
    private $export_type;
    private $template_name;
    private $template_data;
    private $username;
    private $tables;
    private $id;
    private $db;
    private $table;
    private $timevalue;
    private $sqlquery;
    private $username;
    private $item_name;
    private $item_type;
    private $db_name;
    private $page_nr;
    private $page_descr;
    private $username;
    private $master_db;
    private $master_table;
    private $master_field;
    private $foreign_db;
    private $foreign_table;
    private $foreign_field;
    private $id;
    private $search_name;
    private $search_data;
    private $db_name;
    private $pdf_page_number;
    private $x;
    private $y;
    private $db_name;
    private $display_field;
    private $username;
    private $prefs;
    private $last_update;
    private $db_name;
    private $version;
    private $date_created;
    private $date_updated;
    private $schema_snapshot;
    private $schema_sql;
    private $data_sql;
    private $tracking;
    private $tracking_active;
    private $username;
    private $config_data;
    private $usergroup;
    private $tab;
    private $allowed;
    private $username;

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getDbase() {
        return $this->dbase;
    }

    public function setDbase($dbase) {
        $this->dbase = $dbase;
    }

    public function getUser() {
        return $this->user;
    }

    public function setUser($user) {
        $this->user = $user;
    }

    public function getLabel() {
        return $this->label;
    }

    public function setLabel($label) {
        $this->label = $label;
    }

    public function getQuery() {
        return $this->query;
    }

    public function setQuery($query) {
        $this->query = $query;
    }

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getCol_name() {
        return $this->col_name;
    }

    public function setCol_name($col_name) {
        $this->col_name = $col_name;
    }

    public function getCol_type() {
        return $this->col_type;
    }

    public function setCol_type($col_type) {
        $this->col_type = $col_type;
    }

    public function getCol_length() {
        return $this->col_length;
    }

    public function setCol_length($col_length) {
        $this->col_length = $col_length;
    }

    public function getCol_collation() {
        return $this->col_collation;
    }

    public function setCol_collation($col_collation) {
        $this->col_collation = $col_collation;
    }

    public function getCol_isNull() {
        return $this->col_isNull;
    }

    public function setCol_isNull($col_isNull) {
        $this->col_isNull = $col_isNull;
    }

    public function getCol_extra() {
        return $this->col_extra;
    }

    public function setCol_extra($col_extra) {
        $this->col_extra = $col_extra;
    }

    public function getCol_default() {
        return $this->col_default;
    }

    public function setCol_default($col_default) {
        $this->col_default = $col_default;
    }

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getTable_name() {
        return $this->table_name;
    }

    public function setTable_name($table_name) {
        $this->table_name = $table_name;
    }

    public function getColumn_name() {
        return $this->column_name;
    }

    public function setColumn_name($column_name) {
        $this->column_name = $column_name;
    }

    public function getComment() {
        return $this->comment;
    }

    public function setComment($comment) {
        $this->comment = $comment;
    }

    public function getMimetype() {
        return $this->mimetype;
    }

    public function setMimetype($mimetype) {
        $this->mimetype = $mimetype;
    }

    public function getTransformation() {
        return $this->transformation;
    }

    public function setTransformation($transformation) {
        $this->transformation = $transformation;
    }

    public function getTransformation_options() {
        return $this->transformation_options;
    }

    public function setTransformation_options($transformation_options) {
        $this->transformation_options = $transformation_options;
    }

    public function getInput_transformation() {
        return $this->input_transformation;
    }

    public function setInput_transformation($input_transformation) {
        $this->input_transformation = $input_transformation;
    }

    public function getInput_transformation_options() {
        return $this->input_transformation_options;
    }

    public function setInput_transformation_options($input_transformation_options) {
        $this->input_transformation_options = $input_transformation_options;
    }

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getSettings_data() {
        return $this->settings_data;
    }

    public function setSettings_data($settings_data) {
        $this->settings_data = $settings_data;
    }

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getExport_type() {
        return $this->export_type;
    }

    public function setExport_type($export_type) {
        $this->export_type = $export_type;
    }

    public function getTemplate_name() {
        return $this->template_name;
    }

    public function setTemplate_name($template_name) {
        $this->template_name = $template_name;
    }

    public function getTemplate_data() {
        return $this->template_data;
    }

    public function setTemplate_data($template_data) {
        $this->template_data = $template_data;
    }

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getTables() {
        return $this->tables;
    }

    public function setTables($tables) {
        $this->tables = $tables;
    }

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getDb() {
        return $this->db;
    }

    public function setDb($db) {
        $this->db = $db;
    }

    public function getTable() {
        return $this->table;
    }

    public function setTable($table) {
        $this->table = $table;
    }

    public function getTimevalue() {
        return $this->timevalue;
    }

    public function setTimevalue($timevalue) {
        $this->timevalue = $timevalue;
    }

    public function getSqlquery() {
        return $this->sqlquery;
    }

    public function setSqlquery($sqlquery) {
        $this->sqlquery = $sqlquery;
    }

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getItem_name() {
        return $this->item_name;
    }

    public function setItem_name($item_name) {
        $this->item_name = $item_name;
    }

    public function getItem_type() {
        return $this->item_type;
    }

    public function setItem_type($item_type) {
        $this->item_type = $item_type;
    }

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getPage_nr() {
        return $this->page_nr;
    }

    public function setPage_nr($page_nr) {
        $this->page_nr = $page_nr;
    }

    public function getPage_descr() {
        return $this->page_descr;
    }

    public function setPage_descr($page_descr) {
        $this->page_descr = $page_descr;
    }

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getMaster_db() {
        return $this->master_db;
    }

    public function setMaster_db($master_db) {
        $this->master_db = $master_db;
    }

    public function getMaster_table() {
        return $this->master_table;
    }

    public function setMaster_table($master_table) {
        $this->master_table = $master_table;
    }

    public function getMaster_field() {
        return $this->master_field;
    }

    public function setMaster_field($master_field) {
        $this->master_field = $master_field;
    }

    public function getForeign_db() {
        return $this->foreign_db;
    }

    public function setForeign_db($foreign_db) {
        $this->foreign_db = $foreign_db;
    }

    public function getForeign_table() {
        return $this->foreign_table;
    }

    public function setForeign_table($foreign_table) {
        $this->foreign_table = $foreign_table;
    }

    public function getForeign_field() {
        return $this->foreign_field;
    }

    public function setForeign_field($foreign_field) {
        $this->foreign_field = $foreign_field;
    }

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getSearch_name() {
        return $this->search_name;
    }

    public function setSearch_name($search_name) {
        $this->search_name = $search_name;
    }

    public function getSearch_data() {
        return $this->search_data;
    }

    public function setSearch_data($search_data) {
        $this->search_data = $search_data;
    }

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getPdf_page_number() {
        return $this->pdf_page_number;
    }

    public function setPdf_page_number($pdf_page_number) {
        $this->pdf_page_number = $pdf_page_number;
    }

    public function getX() {
        return $this->x;
    }

    public function setX($x) {
        $this->x = $x;
    }

    public function getY() {
        return $this->y;
    }

    public function setY($y) {
        $this->y = $y;
    }

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getDisplay_field() {
        return $this->display_field;
    }

    public function setDisplay_field($display_field) {
        $this->display_field = $display_field;
    }

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getPrefs() {
        return $this->prefs;
    }

    public function setPrefs($prefs) {
        $this->prefs = $prefs;
    }

    public function getLast_update() {
        return $this->last_update;
    }

    public function setLast_update($last_update) {
        $this->last_update = $last_update;
    }

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getVersion() {
        return $this->version;
    }

    public function setVersion($version) {
        $this->version = $version;
    }

    public function getDate_created() {
        return $this->date_created;
    }

    public function setDate_created($date_created) {
        $this->date_created = $date_created;
    }

    public function getDate_updated() {
        return $this->date_updated;
    }

    public function setDate_updated($date_updated) {
        $this->date_updated = $date_updated;
    }

    public function getSchema_snapshot() {
        return $this->schema_snapshot;
    }

    public function setSchema_snapshot($schema_snapshot) {
        $this->schema_snapshot = $schema_snapshot;
    }

    public function getSchema_sql() {
        return $this->schema_sql;
    }

    public function setSchema_sql($schema_sql) {
        $this->schema_sql = $schema_sql;
    }

    public function getData_sql() {
        return $this->data_sql;
    }

    public function setData_sql($data_sql) {
        $this->data_sql = $data_sql;
    }

    public function getTracking() {
        return $this->tracking;
    }

    public function setTracking($tracking) {
        $this->tracking = $tracking;
    }

    public function getTracking_active() {
        return $this->tracking_active;
    }

    public function setTracking_active($tracking_active) {
        $this->tracking_active = $tracking_active;
    }

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getConfig_data() {
        return $this->config_data;
    }

    public function setConfig_data($config_data) {
        $this->config_data = $config_data;
    }

    public function getUsergroup() {
        return $this->usergroup;
    }

    public function setUsergroup($usergroup) {
        $this->usergroup = $usergroup;
    }

    public function getTab() {
        return $this->tab;
    }

    public function setTab($tab) {
        $this->tab = $tab;
    }

    public function getAllowed() {
        return $this->allowed;
    }

    public function setAllowed($allowed) {
        $this->allowed = $allowed;
    }

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

}