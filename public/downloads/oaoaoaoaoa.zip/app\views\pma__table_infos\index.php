<?php require_once __DIR__ . '/../include/head.php'; ?>
<?php require_once __DIR__ . '/../include/navigation.php'; ?>

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__table_info</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__table_infos/cadastrar" class="btn btn-primary">
            Novo Pma__table_info
        </a>
    </div>
</div>

<?php if (empty($pma__table_infos)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__table_infos/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__table_info
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Dbase</th>
                    <th>User</th>
                    <th>Label</th>
                    <th>Query</th>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Id</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Id</th>
                    <th>Export_type</th>
                    <th>Template_name</th>
                    <th>Template_data</th>
                    <th>Username</th>
                    <th>Tables</th>
                    <th>Id</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Username</th>
                    <th>Master_db</th>
                    <th>Master_table</th>
                    <th>Master_field</th>
                    <th>Foreign_db</th>
                    <th>Foreign_table</th>
                    <th>Foreign_field</th>
                    <th>Id</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Db_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Db_name</th>
                    <th>Display_field</th>
                    <th>Username</th>
                    <th>Prefs</th>
                    <th>Last_update</th>
                    <th>Db_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Username</th>
                    <th>Config_data</th>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Username</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__table_infos as $pma__table_info): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__table_info['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['dbase'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['user'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['label'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['query'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['col_default'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['input_transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['settings_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['export_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['template_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['template_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['tables'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['sqlquery'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['page_descr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['master_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['master_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['master_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['foreign_db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['foreign_table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['foreign_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['search_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['y'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['display_field'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['prefs'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['last_update'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['tracking_active'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['config_data'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['allowed'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['username'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__table_infos/editar?id=<?= $pma__table_info['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__table_infos/excluir?id=<?= $pma__table_info['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>